# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainAzvnlV.ui'
##
## Created by: Qt User Interface Compiler version 6.0.3
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import *
from PySide6.QtGui import *
from PySide6.QtWidgets import *

from . resources_rc import *

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1950, 1078)
        MainWindow.setMinimumSize(QSize(940, 560))
        self.styleSheet = QWidget(MainWindow)
        self.styleSheet.setObjectName(u"styleSheet")
        font = QFont()
        font.setFamily(u"Segoe UI")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        self.styleSheet.setFont(font)
        self.styleSheet.setStyleSheet(u"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"\n"
"SET APP STYLESHEET - FULL STYLES HERE\n"
"DARK THEME - DRACULA COLOR BASED\n"
"\n"
"///////////////////////////////////////////////////////////////////////////////////////////////// */\n"
"\n"
"QWidget{\n"
"	color: rgb(221, 221, 221);\n"
"	font: 10pt \"Segoe UI\";\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"Tooltip */\n"
"QToolTip {\n"
"	color: #ffffff;\n"
"	background-color: rgba(33, 37, 43, 180);\n"
"	border: 1px solid rgb(44, 49, 58);\n"
"	background-image: none;\n"
"	background-position: left center;\n"
"    background-repeat: no-repeat;\n"
"	border: none;\n"
"	border-left: 2px solid rgb(255, 121, 198);\n"
"	text-align: left;\n"
"	padding-left: 8px;\n"
"	margin: 0px;\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"Bg App */\n"
"#bgApp {	\n"
"	background"
                        "-color: rgb(40, 44, 52);\n"
"	border: 1px solid rgb(44, 49, 58);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"Left Menu */\n"
"#leftMenuBg {	\n"
"	background-color: rgb(33, 37, 43);\n"
"}\n"
"#topLogo {\n"
"	background-color: rgb(33, 37, 43);\n"
"	background-image: url(:/images/images/images/Amkort.png);\n"
"	background-position: centered;\n"
"	background-repeat: no-repeat;\n"
"}\n"
"#titleLeftApp { font: 63 12pt \"Segoe UI Semibold\"; }\n"
"#titleLeftDescription { font: 8pt \"Segoe UI\"; color: rgb(189, 147, 249); }\n"
"\n"
"/* MENUS */\n"
"#topMenu .QPushButton {	\n"
"	background-position: left center;\n"
"    background-repeat: no-repeat;\n"
"	border: none;\n"
"	border-left: 22px solid transparent;\n"
"	background-color: transparent;\n"
"	text-align: left;\n"
"	padding-left: 44px;\n"
"}\n"
"#topMenu .QPushButton:hover {\n"
"	background-color: rgb(40, 44, 52);\n"
"}\n"
"#topMenu .QPushButton:pressed {	\n"
"	background-color: rgb(189, "
                        "147, 249);\n"
"	color: rgb(255, 255, 255);\n"
"}\n"
"#bottomMenu .QPushButton {	\n"
"	background-position: left center;\n"
"    background-repeat: no-repeat;\n"
"	border: none;\n"
"	border-left: 20px solid transparent;\n"
"	background-color:transparent;\n"
"	text-align: left;\n"
"	padding-left: 44px;\n"
"}\n"
"#bottomMenu .QPushButton:hover {\n"
"	background-color: rgb(40, 44, 52);\n"
"}\n"
"#bottomMenu .QPushButton:pressed {	\n"
"	background-color: rgb(189, 147, 249);\n"
"	color: rgb(255, 255, 255);\n"
"}\n"
"#leftMenuFrame{\n"
"	border-top: 3px solid rgb(44, 49, 58);\n"
"}\n"
"\n"
"/* Toggle Button */\n"
"#toggleButton {\n"
"	background-position: left center;\n"
"    background-repeat: no-repeat;\n"
"	border: none;\n"
"	border-left: 20px solid transparent;\n"
"	background-color: rgb(37, 41, 48);\n"
"	text-align: left;\n"
"	padding-left: 44px;\n"
"	color: rgb(113, 126, 149);\n"
"}\n"
"#toggleButton:hover {\n"
"	background-color: rgb(40, 44, 52);\n"
"}\n"
"#toggleButton:pressed {\n"
"	background-color: rgb(189"
                        ", 147, 249);\n"
"}\n"
"\n"
"/* Title Menu */\n"
"#titleRightInfo { padding-left: 10px; }\n"
"\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"Extra Tab */\n"
"#extraLeftBox {	\n"
"	background-color: rgb(44, 49, 58);\n"
"}\n"
"#extraTopBg{	\n"
"	background-color: rgb(189, 147, 249)\n"
"}\n"
"\n"
"/* Icon */\n"
"#extraIcon {\n"
"	background-position: center;\n"
"	background-repeat: no-repeat;\n"
"	background-image: url(:/icons/images/icons/icon_settings.png);\n"
"}\n"
"\n"
"/* Label */\n"
"#extraLabel { color: rgb(255, 255, 255); }\n"
"\n"
"/* Btn Close */\n"
"#extraCloseColumnBtn { background-color: rgba(255, 255, 255, 0); border: none;  border-radius: 5px; }\n"
"#extraCloseColumnBtn:hover { background-color: rgb(196, 161, 249); border-style: solid; border-radius: 4px; }\n"
"#extraCloseColumnBtn:pressed { background-color: rgb(180, 141, 238); border-style: solid; border-radius: 4px; }\n"
"\n"
"/* Extra Content */\n"
"#extraContent{\n"
"	border-to"
                        "p: 3px solid rgb(40, 44, 52);\n"
"}\n"
"\n"
"/* Extra Top Menus */\n"
"#extraTopMenu .QPushButton {\n"
"background-position: left center;\n"
"    background-repeat: no-repeat;\n"
"	border: none;\n"
"	border-left: 22px solid transparent;\n"
"	background-color:transparent;\n"
"	text-align: left;\n"
"	padding-left: 44px;\n"
"}\n"
"#extraTopMenu .QPushButton:hover {\n"
"	background-color: rgb(40, 44, 52);\n"
"}\n"
"#extraTopMenu .QPushButton:pressed {	\n"
"	background-color: rgb(189, 147, 249);\n"
"	color: rgb(255, 255, 255);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"Content App */\n"
"#contentTopBg{	\n"
"	background-color: rgb(33, 37, 43);\n"
"}\n"
"#contentBottom{\n"
"	border-top: 3px solid rgb(44, 49, 58);\n"
"}\n"
"\n"
"/* Top Buttons */\n"
"#rightButtons .QPushButton { background-color: rgba(255, 255, 255, 0); border: none;  border-radius: 5px; }\n"
"#rightButtons .QPushButton:hover { background-color: rgb(44, 49, 57); border-style:"
                        " solid; border-radius: 4px; }\n"
"#rightButtons .QPushButton:pressed { background-color: rgb(23, 26, 30); border-style: solid; border-radius: 4px; }\n"
"\n"
"/* Theme Settings */\n"
"#extraRightBox { background-color: rgb(44, 49, 58); }\n"
"#themeSettingsTopDetail { background-color: rgb(189, 147, 249); }\n"
"\n"
"/* Bottom Bar */\n"
"#bottomBar { background-color: rgb(44, 49, 58); }\n"
"#bottomBar QLabel { font-size: 11px; color: rgb(113, 126, 149); padding-left: 10px; padding-right: 10px; padding-bottom: 2px; }\n"
"\n"
"/* CONTENT SETTINGS */\n"
"/* MENUS */\n"
"#contentSettings .QPushButton {	\n"
"	background-position: left center;\n"
"    background-repeat: no-repeat;\n"
"	border: none;\n"
"	border-left: 22px solid transparent;\n"
"	background-color:transparent;\n"
"	text-align: left;\n"
"	padding-left: 44px;\n"
"}\n"
"#contentSettings .QPushButton:hover {\n"
"	background-color: rgb(40, 44, 52);\n"
"}\n"
"#contentSettings .QPushButton:pressed {	\n"
"	background-color: rgb(189, 147, 249);\n"
"	color: rgb(25"
                        "5, 255, 255);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"QTableWidget */\n"
"\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"LineEdit */\n"
"QLineEdit {\n"
"	background-color: rgb(33, 37, 43);\n"
"	border-radius: 5px;\n"
"	border: 2px solid rgb(33, 37, 43);\n"
"	padding-left: 10px;\n"
"	selection-color: rgb(255, 255, 255);\n"
"	selection-background-color: rgb(255, 121, 198);\n"
"}\n"
"QLineEdit:hover {\n"
"	border: 2px solid rgb(64, 71, 88);\n"
"}\n"
"QLineEdit:focus {\n"
"	border: 2px solid rgb(91, 101, 124);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"PlainTextEdit */\n"
"QPlainTextEdit {\n"
"	background-color: rgb(27, 29, 35);\n"
"	border-radius: 5px;\n"
"	padding: 10px;\n"
"	selection-color: rgb(255, 255, 255);\n"
"	selection-background-color: rgb(255, 121, 198);\n"
"}\n"
"QPlainTextEdit  Q"
                        "ScrollBar:vertical {\n"
"    width: 8px;\n"
" }\n"
"QPlainTextEdit  QScrollBar:horizontal {\n"
"    height: 8px;\n"
" }\n"
"QPlainTextEdit:hover {\n"
"	border: 2px solid rgb(64, 71, 88);\n"
"}\n"
"QPlainTextEdit:focus {\n"
"	border: 2px solid rgb(91, 101, 124);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"ScrollBars */\n"
"QScrollBar:horizontal {\n"
"    border: none;\n"
"    background: rgb(52, 59, 72);\n"
"    height: 8px;\n"
"    margin: 0px 21px 0 21px;\n"
"	border-radius: 0px;\n"
"}\n"
"QScrollBar::handle:horizontal {\n"
"    background: rgb(189, 147, 249);\n"
"    min-width: 25px;\n"
"	border-radius: 4px\n"
"}\n"
"QScrollBar::add-line:horizontal {\n"
"    border: none;\n"
"    background: rgb(55, 63, 77);\n"
"    width: 20px;\n"
"	border-top-right-radius: 4px;\n"
"    border-bottom-right-radius: 4px;\n"
"    subcontrol-position: right;\n"
"    subcontrol-origin: margin;\n"
"}\n"
"QScrollBar::sub-line:horizontal {\n"
"    border: n"
                        "one;\n"
"    background: rgb(55, 63, 77);\n"
"    width: 20px;\n"
"	border-top-left-radius: 4px;\n"
"    border-bottom-left-radius: 4px;\n"
"    subcontrol-position: left;\n"
"    subcontrol-origin: margin;\n"
"}\n"
"QScrollBar::up-arrow:horizontal, QScrollBar::down-arrow:horizontal\n"
"{\n"
"     background: none;\n"
"}\n"
"QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal\n"
"{\n"
"     background: none;\n"
"}\n"
" QScrollBar:vertical {\n"
"	border: none;\n"
"    background: rgb(52, 59, 72);\n"
"    width: 8px;\n"
"    margin: 21px 0 21px 0;\n"
"	border-radius: 0px;\n"
" }\n"
" QScrollBar::handle:vertical {	\n"
"	background: rgb(189, 147, 249);\n"
"    min-height: 25px;\n"
"	border-radius: 4px\n"
" }\n"
" QScrollBar::add-line:vertical {\n"
"     border: none;\n"
"    background: rgb(55, 63, 77);\n"
"     height: 20px;\n"
"	border-bottom-left-radius: 4px;\n"
"    border-bottom-right-radius: 4px;\n"
"     subcontrol-position: bottom;\n"
"     subcontrol-origin: margin;\n"
" }\n"
" QScrollBar::su"
                        "b-line:vertical {\n"
"	border: none;\n"
"    background: rgb(55, 63, 77);\n"
"     height: 20px;\n"
"	border-top-left-radius: 4px;\n"
"    border-top-right-radius: 4px;\n"
"     subcontrol-position: top;\n"
"     subcontrol-origin: margin;\n"
" }\n"
" QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical {\n"
"     background: none;\n"
" }\n"
"\n"
" QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {\n"
"     background: none;\n"
" }\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"CheckBox */\n"
"QCheckBox::indicator {\n"
"    border: 3px solid rgb(52, 59, 72);\n"
"	width: 15px;\n"
"	height: 15px;\n"
"	border-radius: 10px;\n"
"    background: rgb(44, 49, 60);\n"
"}\n"
"QCheckBox::indicator:hover {\n"
"    border: 3px solid rgb(58, 66, 81);\n"
"}\n"
"QCheckBox::indicator:checked {\n"
"    background: 3px solid rgb(52, 59, 72);\n"
"	border: 3px solid rgb(52, 59, 72);	\n"
"	background-image: url(:/icons/images/icons/cil-check-al"
                        "t.png);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"RadioButton */\n"
"QRadioButton::indicator {\n"
"    border: 3px solid rgb(52, 59, 72);\n"
"	width: 15px;\n"
"	height: 15px;\n"
"	border-radius: 10px;\n"
"    background: rgb(44, 49, 60);\n"
"}\n"
"QRadioButton::indicator:hover {\n"
"    border: 3px solid rgb(58, 66, 81);\n"
"}\n"
"QRadioButton::indicator:checked {\n"
"    background: 3px solid rgb(94, 106, 130);\n"
"	border: 3px solid rgb(52, 59, 72);	\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"ComboBox */\n"
"QComboBox{\n"
"	background-color: rgb(27, 29, 35);\n"
"	border-radius: 5px;\n"
"	border: 2px solid rgb(33, 37, 43);\n"
"	padding: 5px;\n"
"	padding-left: 10px;\n"
"}\n"
"QComboBox:hover{\n"
"	border: 2px solid rgb(64, 71, 88);\n"
"}\n"
"QComboBox::drop-down {\n"
"	subcontrol-origin: padding;\n"
"	subcontrol-position: top right;\n"
"	width: 25px; \n"
"	"
                        "border-left-width: 3px;\n"
"	border-left-color: rgba(39, 44, 54, 150);\n"
"	border-left-style: solid;\n"
"	border-top-right-radius: 3px;\n"
"	border-bottom-right-radius: 3px;	\n"
"	background-image: url(:/icons/images/icons/cil-arrow-bottom.png);\n"
"	background-position: center;\n"
"	background-repeat: no-reperat;\n"
" }\n"
"QComboBox QAbstractItemView {\n"
"	color: rgb(255, 121, 198);	\n"
"	background-color: rgb(33, 37, 43);\n"
"	padding: 10px;\n"
"	selection-background-color: rgb(39, 44, 54);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"Sliders */\n"
"QSlider::groove:horizontal {\n"
"    border-radius: 5px;\n"
"    height: 10px;\n"
"	margin: 0px;\n"
"	background-color: rgb(52, 59, 72);\n"
"}\n"
"QSlider::groove:horizontal:hover {\n"
"	background-color: rgb(55, 62, 76);\n"
"}\n"
"QSlider::handle:horizontal {\n"
"    background-color: rgb(189, 147, 249);\n"
"    border: none;\n"
"    height: 10px;\n"
"    width: 10px;\n"
"    margin: 0"
                        "px;\n"
"	border-radius: 5px;\n"
"}\n"
"QSlider::handle:horizontal:hover {\n"
"    background-color: rgb(195, 155, 255);\n"
"}\n"
"QSlider::handle:horizontal:pressed {\n"
"    background-color: rgb(255, 121, 198);\n"
"}\n"
"\n"
"QSlider::groove:vertical {\n"
"    border-radius: 5px;\n"
"    width: 10px;\n"
"    margin: 0px;\n"
"	background-color: rgb(52, 59, 72);\n"
"}\n"
"QSlider::groove:vertical:hover {\n"
"	background-color: rgb(55, 62, 76);\n"
"}\n"
"QSlider::handle:vertical {\n"
"    background-color: rgb(189, 147, 249);\n"
"	border: none;\n"
"    height: 10px;\n"
"    width: 10px;\n"
"    margin: 0px;\n"
"	border-radius: 5px;\n"
"}\n"
"QSlider::handle:vertical:hover {\n"
"    background-color: rgb(195, 155, 255);\n"
"}\n"
"QSlider::handle:vertical:pressed {\n"
"    background-color: rgb(255, 121, 198);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"CommandLinkButton */\n"
"QCommandLinkButton {	\n"
"	color: rgb(255, 121, 198);\n"
"	bo"
                        "rder-radius: 5px;\n"
"	padding: 5px;\n"
"	color: rgb(255, 170, 255);\n"
"}\n"
"QCommandLinkButton:hover {	\n"
"	color: rgb(255, 170, 255);\n"
"	background-color: rgb(44, 49, 60);\n"
"}\n"
"QCommandLinkButton:pressed {	\n"
"	color: rgb(189, 147, 249);\n"
"	background-color: rgb(52, 58, 71);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"Button */\n"
"#pagesContainer QPushButton {\n"
"	border: 2px solid rgb(52, 59, 72);\n"
"	border-radius: 5px;	\n"
"	background-color: rgb(52, 59, 72);\n"
"}\n"
"#pagesContainer QPushButton:hover {\n"
"	background-color: rgb(57, 65, 80);\n"
"	border: 2px solid rgb(61, 70, 86);\n"
"}\n"
"#pagesContainer QPushButton:pressed {	\n"
"	background-color: rgb(35, 40, 49);\n"
"	border: 2px solid rgb(43, 50, 61);\n"
"}\n"
"\n"
"")
        self.appMargins = QVBoxLayout(self.styleSheet)
        self.appMargins.setSpacing(0)
        self.appMargins.setObjectName(u"appMargins")
        self.appMargins.setContentsMargins(10, 10, 10, 10)
        self.bgApp = QFrame(self.styleSheet)
        self.bgApp.setObjectName(u"bgApp")
        self.bgApp.setStyleSheet(u"")
        self.bgApp.setFrameShape(QFrame.NoFrame)
        self.bgApp.setFrameShadow(QFrame.Raised)
        self.appLayout = QHBoxLayout(self.bgApp)
        self.appLayout.setSpacing(0)
        self.appLayout.setObjectName(u"appLayout")
        self.appLayout.setContentsMargins(0, 0, 0, 0)
        self.leftMenuBg = QFrame(self.bgApp)
        self.leftMenuBg.setObjectName(u"leftMenuBg")
        self.leftMenuBg.setMinimumSize(QSize(60, 0))
        self.leftMenuBg.setMaximumSize(QSize(60, 16777215))
        self.leftMenuBg.setFrameShape(QFrame.NoFrame)
        self.leftMenuBg.setFrameShadow(QFrame.Raised)
        self.verticalLayout_3 = QVBoxLayout(self.leftMenuBg)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.topLogoInfo = QFrame(self.leftMenuBg)
        self.topLogoInfo.setObjectName(u"topLogoInfo")
        self.topLogoInfo.setMinimumSize(QSize(0, 50))
        self.topLogoInfo.setMaximumSize(QSize(16777215, 50))
        self.topLogoInfo.setFrameShape(QFrame.NoFrame)
        self.topLogoInfo.setFrameShadow(QFrame.Raised)
        self.topLogo = QFrame(self.topLogoInfo)
        self.topLogo.setObjectName(u"topLogo")
        self.topLogo.setGeometry(QRect(10, 8, 42, 42))
        self.topLogo.setMinimumSize(QSize(42, 42))
        self.topLogo.setMaximumSize(QSize(42, 42))
        self.topLogo.setCursor(QCursor(Qt.ArrowCursor))
        self.topLogo.setFrameShape(QFrame.NoFrame)
        self.topLogo.setFrameShadow(QFrame.Raised)
        self.titleLeftApp = QLabel(self.topLogoInfo)
        self.titleLeftApp.setObjectName(u"titleLeftApp")
        self.titleLeftApp.setGeometry(QRect(70, 8, 160, 20))
        font1 = QFont()
        font1.setFamily(u"Segoe UI Semibold")
        font1.setPointSize(12)
        font1.setBold(False)
        font1.setItalic(False)
        self.titleLeftApp.setFont(font1)
        self.titleLeftApp.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignTop)
        self.titleLeftDescription = QLabel(self.topLogoInfo)
        self.titleLeftDescription.setObjectName(u"titleLeftDescription")
        self.titleLeftDescription.setGeometry(QRect(70, 27, 160, 16))
        self.titleLeftDescription.setMaximumSize(QSize(16777215, 16))
        font2 = QFont()
        font2.setFamily(u"Segoe UI")
        font2.setPointSize(8)
        font2.setBold(False)
        font2.setItalic(False)
        self.titleLeftDescription.setFont(font2)
        self.titleLeftDescription.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignTop)

        self.verticalLayout_3.addWidget(self.topLogoInfo)

        self.leftMenuFrame = QFrame(self.leftMenuBg)
        self.leftMenuFrame.setObjectName(u"leftMenuFrame")
        self.leftMenuFrame.setFrameShape(QFrame.NoFrame)
        self.leftMenuFrame.setFrameShadow(QFrame.Raised)
        self.verticalMenuLayout = QVBoxLayout(self.leftMenuFrame)
        self.verticalMenuLayout.setSpacing(0)
        self.verticalMenuLayout.setObjectName(u"verticalMenuLayout")
        self.verticalMenuLayout.setContentsMargins(0, 0, 0, 0)
        self.toggleBox = QFrame(self.leftMenuFrame)
        self.toggleBox.setObjectName(u"toggleBox")
        self.toggleBox.setMaximumSize(QSize(16777215, 45))
        self.toggleBox.setFrameShape(QFrame.NoFrame)
        self.toggleBox.setFrameShadow(QFrame.Raised)
        self.verticalLayout_4 = QVBoxLayout(self.toggleBox)
        self.verticalLayout_4.setSpacing(0)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.toggleButton = QPushButton(self.toggleBox)
        self.toggleButton.setObjectName(u"toggleButton")
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toggleButton.sizePolicy().hasHeightForWidth())
        self.toggleButton.setSizePolicy(sizePolicy)
        self.toggleButton.setMinimumSize(QSize(0, 45))
        self.toggleButton.setFont(font)
        self.toggleButton.setCursor(QCursor(Qt.PointingHandCursor))
        self.toggleButton.setLayoutDirection(Qt.LeftToRight)
        self.toggleButton.setStyleSheet(u"background-image: url(:/icons/images/icons/icon_menu.png);")

        self.verticalLayout_4.addWidget(self.toggleButton)


        self.verticalMenuLayout.addWidget(self.toggleBox)

        self.topMenu = QFrame(self.leftMenuFrame)
        self.topMenu.setObjectName(u"topMenu")
        self.topMenu.setFrameShape(QFrame.NoFrame)
        self.topMenu.setFrameShadow(QFrame.Raised)
        self.verticalLayout_8 = QVBoxLayout(self.topMenu)
        self.verticalLayout_8.setSpacing(0)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalLayout_8.setContentsMargins(0, 0, 0, 0)
        self.btn_home = QPushButton(self.topMenu)
        self.btn_home.setObjectName(u"btn_home")
        sizePolicy.setHeightForWidth(self.btn_home.sizePolicy().hasHeightForWidth())
        self.btn_home.setSizePolicy(sizePolicy)
        self.btn_home.setMinimumSize(QSize(0, 45))
        self.btn_home.setFont(font)
        self.btn_home.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_home.setLayoutDirection(Qt.LeftToRight)
        self.btn_home.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-home.png);")

        self.verticalLayout_8.addWidget(self.btn_home)

        self.btn_new = QPushButton(self.topMenu)
        self.btn_new.setObjectName(u"btn_new")
        sizePolicy.setHeightForWidth(self.btn_new.sizePolicy().hasHeightForWidth())
        self.btn_new.setSizePolicy(sizePolicy)
        self.btn_new.setMinimumSize(QSize(0, 45))
        self.btn_new.setFont(font)
        self.btn_new.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_new.setLayoutDirection(Qt.LeftToRight)
        self.btn_new.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-screen-desktop);")

        self.verticalLayout_8.addWidget(self.btn_new)

        self.btn_brower = QPushButton(self.topMenu)
        self.btn_brower.setObjectName(u"btn_brower")
        sizePolicy.setHeightForWidth(self.btn_brower.sizePolicy().hasHeightForWidth())
        self.btn_brower.setSizePolicy(sizePolicy)
        self.btn_brower.setMinimumSize(QSize(0, 45))
        self.btn_brower.setFont(font)
        self.btn_brower.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_brower.setLayoutDirection(Qt.LeftToRight)
        self.btn_brower.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-browser.png);")

        self.verticalLayout_8.addWidget(self.btn_brower)

        self.btn_save = QPushButton(self.topMenu)
        self.btn_save.setObjectName(u"btn_save")
        sizePolicy.setHeightForWidth(self.btn_save.sizePolicy().hasHeightForWidth())
        self.btn_save.setSizePolicy(sizePolicy)
        self.btn_save.setMinimumSize(QSize(0, 45))
        self.btn_save.setFont(font)
        self.btn_save.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_save.setLayoutDirection(Qt.LeftToRight)
        self.btn_save.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-save.png)")

        self.verticalLayout_8.addWidget(self.btn_save)

        self.btn_widgets = QPushButton(self.topMenu)
        self.btn_widgets.setObjectName(u"btn_widgets")
        sizePolicy.setHeightForWidth(self.btn_widgets.sizePolicy().hasHeightForWidth())
        self.btn_widgets.setSizePolicy(sizePolicy)
        self.btn_widgets.setMinimumSize(QSize(0, 45))
        self.btn_widgets.setFont(font)
        self.btn_widgets.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_widgets.setLayoutDirection(Qt.LeftToRight)
        self.btn_widgets.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-gamepad.png);")

        self.verticalLayout_8.addWidget(self.btn_widgets)


        self.verticalMenuLayout.addWidget(self.topMenu, 0, Qt.AlignTop)

        self.bottomMenu = QFrame(self.leftMenuFrame)
        self.bottomMenu.setObjectName(u"bottomMenu")
        self.bottomMenu.setFrameShape(QFrame.NoFrame)
        self.bottomMenu.setFrameShadow(QFrame.Raised)
        self.verticalLayout_9 = QVBoxLayout(self.bottomMenu)
        self.verticalLayout_9.setSpacing(0)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.verticalLayout_9.setContentsMargins(0, 0, 0, 0)
        self.toggleLeftBox = QPushButton(self.bottomMenu)
        self.toggleLeftBox.setObjectName(u"toggleLeftBox")
        sizePolicy.setHeightForWidth(self.toggleLeftBox.sizePolicy().hasHeightForWidth())
        self.toggleLeftBox.setSizePolicy(sizePolicy)
        self.toggleLeftBox.setMinimumSize(QSize(0, 45))
        self.toggleLeftBox.setFont(font)
        self.toggleLeftBox.setCursor(QCursor(Qt.PointingHandCursor))
        self.toggleLeftBox.setLayoutDirection(Qt.LeftToRight)
        self.toggleLeftBox.setStyleSheet(u"background-image: url(:/icons/images/icons/icon_settings.png);")

        self.verticalLayout_9.addWidget(self.toggleLeftBox)


        self.verticalMenuLayout.addWidget(self.bottomMenu, 0, Qt.AlignBottom)


        self.verticalLayout_3.addWidget(self.leftMenuFrame)


        self.appLayout.addWidget(self.leftMenuBg)

        self.extraLeftBox = QFrame(self.bgApp)
        self.extraLeftBox.setObjectName(u"extraLeftBox")
        self.extraLeftBox.setMinimumSize(QSize(0, 0))
        self.extraLeftBox.setMaximumSize(QSize(0, 16777215))
        self.extraLeftBox.setFrameShape(QFrame.NoFrame)
        self.extraLeftBox.setFrameShadow(QFrame.Raised)
        self.extraColumLayout = QVBoxLayout(self.extraLeftBox)
        self.extraColumLayout.setSpacing(0)
        self.extraColumLayout.setObjectName(u"extraColumLayout")
        self.extraColumLayout.setContentsMargins(0, 0, 0, 0)
        self.extraTopBg = QFrame(self.extraLeftBox)
        self.extraTopBg.setObjectName(u"extraTopBg")
        self.extraTopBg.setMinimumSize(QSize(0, 50))
        self.extraTopBg.setMaximumSize(QSize(16777215, 50))
        self.extraTopBg.setFrameShape(QFrame.NoFrame)
        self.extraTopBg.setFrameShadow(QFrame.Raised)
        self.verticalLayout_5 = QVBoxLayout(self.extraTopBg)
        self.verticalLayout_5.setSpacing(0)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.extraTopLayout = QGridLayout()
        self.extraTopLayout.setObjectName(u"extraTopLayout")
        self.extraTopLayout.setHorizontalSpacing(10)
        self.extraTopLayout.setVerticalSpacing(0)
        self.extraTopLayout.setContentsMargins(10, -1, 10, -1)
        self.extraIcon = QFrame(self.extraTopBg)
        self.extraIcon.setObjectName(u"extraIcon")
        self.extraIcon.setMinimumSize(QSize(20, 0))
        self.extraIcon.setMaximumSize(QSize(20, 20))
        self.extraIcon.setFrameShape(QFrame.NoFrame)
        self.extraIcon.setFrameShadow(QFrame.Raised)

        self.extraTopLayout.addWidget(self.extraIcon, 0, 0, 1, 1)

        self.extraLabel = QLabel(self.extraTopBg)
        self.extraLabel.setObjectName(u"extraLabel")
        self.extraLabel.setMinimumSize(QSize(150, 0))

        self.extraTopLayout.addWidget(self.extraLabel, 0, 1, 1, 1)

        self.extraCloseColumnBtn = QPushButton(self.extraTopBg)
        self.extraCloseColumnBtn.setObjectName(u"extraCloseColumnBtn")
        self.extraCloseColumnBtn.setMinimumSize(QSize(28, 28))
        self.extraCloseColumnBtn.setMaximumSize(QSize(28, 28))
        self.extraCloseColumnBtn.setCursor(QCursor(Qt.PointingHandCursor))
        icon = QIcon()
        icon.addFile(u":/icons/images/icons/icon_close.png", QSize(), QIcon.Normal, QIcon.Off)
        self.extraCloseColumnBtn.setIcon(icon)
        self.extraCloseColumnBtn.setIconSize(QSize(20, 20))

        self.extraTopLayout.addWidget(self.extraCloseColumnBtn, 0, 2, 1, 1)


        self.verticalLayout_5.addLayout(self.extraTopLayout)


        self.extraColumLayout.addWidget(self.extraTopBg)

        self.extraContent = QFrame(self.extraLeftBox)
        self.extraContent.setObjectName(u"extraContent")
        self.extraContent.setFrameShape(QFrame.NoFrame)
        self.extraContent.setFrameShadow(QFrame.Raised)
        self.verticalLayout_12 = QVBoxLayout(self.extraContent)
        self.verticalLayout_12.setSpacing(0)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.verticalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.extraTopMenu = QFrame(self.extraContent)
        self.extraTopMenu.setObjectName(u"extraTopMenu")
        self.extraTopMenu.setFrameShape(QFrame.NoFrame)
        self.extraTopMenu.setFrameShadow(QFrame.Raised)
        self.verticalLayout_11 = QVBoxLayout(self.extraTopMenu)
        self.verticalLayout_11.setSpacing(0)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalLayout_11.setContentsMargins(0, 0, 0, 0)
        self.btn_share = QPushButton(self.extraTopMenu)
        self.btn_share.setObjectName(u"btn_share")
        sizePolicy.setHeightForWidth(self.btn_share.sizePolicy().hasHeightForWidth())
        self.btn_share.setSizePolicy(sizePolicy)
        self.btn_share.setMinimumSize(QSize(0, 45))
        self.btn_share.setFont(font)
        self.btn_share.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_share.setLayoutDirection(Qt.LeftToRight)
        self.btn_share.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-share-boxed.png);")

        self.verticalLayout_11.addWidget(self.btn_share)

        self.btn_more = QPushButton(self.extraTopMenu)
        self.btn_more.setObjectName(u"btn_more")
        sizePolicy.setHeightForWidth(self.btn_more.sizePolicy().hasHeightForWidth())
        self.btn_more.setSizePolicy(sizePolicy)
        self.btn_more.setMinimumSize(QSize(0, 45))
        self.btn_more.setFont(font)
        self.btn_more.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_more.setLayoutDirection(Qt.LeftToRight)
        self.btn_more.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-layers.png);")

        self.verticalLayout_11.addWidget(self.btn_more)

        self.btn_adjustment = QPushButton(self.extraTopMenu)
        self.btn_adjustment.setObjectName(u"btn_adjustment")
        sizePolicy.setHeightForWidth(self.btn_adjustment.sizePolicy().hasHeightForWidth())
        self.btn_adjustment.setSizePolicy(sizePolicy)
        self.btn_adjustment.setMinimumSize(QSize(0, 45))
        self.btn_adjustment.setFont(font)
        self.btn_adjustment.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_adjustment.setLayoutDirection(Qt.LeftToRight)
        self.btn_adjustment.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-equalizer.png);")

        self.verticalLayout_11.addWidget(self.btn_adjustment)


        self.verticalLayout_12.addWidget(self.extraTopMenu, 0, Qt.AlignTop)

        self.extraCenter = QFrame(self.extraContent)
        self.extraCenter.setObjectName(u"extraCenter")
        self.extraCenter.setFrameShape(QFrame.NoFrame)
        self.extraCenter.setFrameShadow(QFrame.Raised)
        self.verticalLayout_10 = QVBoxLayout(self.extraCenter)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.textEdit = QTextEdit(self.extraCenter)
        self.textEdit.setObjectName(u"textEdit")
        self.textEdit.setMinimumSize(QSize(222, 0))
        self.textEdit.setStyleSheet(u"background: transparent;")
        self.textEdit.setFrameShape(QFrame.NoFrame)
        self.textEdit.setReadOnly(True)

        self.verticalLayout_10.addWidget(self.textEdit)


        self.verticalLayout_12.addWidget(self.extraCenter)

        self.extraBottom = QFrame(self.extraContent)
        self.extraBottom.setObjectName(u"extraBottom")
        self.extraBottom.setFrameShape(QFrame.NoFrame)
        self.extraBottom.setFrameShadow(QFrame.Raised)

        self.verticalLayout_12.addWidget(self.extraBottom)


        self.extraColumLayout.addWidget(self.extraContent)


        self.appLayout.addWidget(self.extraLeftBox)

        self.contentBox = QFrame(self.bgApp)
        self.contentBox.setObjectName(u"contentBox")
        self.contentBox.setFrameShape(QFrame.NoFrame)
        self.contentBox.setFrameShadow(QFrame.Raised)
        self.verticalLayout_2 = QVBoxLayout(self.contentBox)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.contentTopBg = QFrame(self.contentBox)
        self.contentTopBg.setObjectName(u"contentTopBg")
        self.contentTopBg.setMinimumSize(QSize(0, 50))
        self.contentTopBg.setMaximumSize(QSize(16777215, 50))
        self.contentTopBg.setFrameShape(QFrame.NoFrame)
        self.contentTopBg.setFrameShadow(QFrame.Raised)
        self.horizontalLayout = QHBoxLayout(self.contentTopBg)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 10, 0)
        self.leftBox = QFrame(self.contentTopBg)
        self.leftBox.setObjectName(u"leftBox")
        sizePolicy1 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.leftBox.sizePolicy().hasHeightForWidth())
        self.leftBox.setSizePolicy(sizePolicy1)
        self.leftBox.setFrameShape(QFrame.NoFrame)
        self.leftBox.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_3 = QHBoxLayout(self.leftBox)
        self.horizontalLayout_3.setSpacing(0)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.titleRightInfo = QLabel(self.leftBox)
        self.titleRightInfo.setObjectName(u"titleRightInfo")
        sizePolicy2 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.titleRightInfo.sizePolicy().hasHeightForWidth())
        self.titleRightInfo.setSizePolicy(sizePolicy2)
        self.titleRightInfo.setMaximumSize(QSize(16777215, 45))
        self.titleRightInfo.setFont(font)
        self.titleRightInfo.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.horizontalLayout_3.addWidget(self.titleRightInfo)


        self.horizontalLayout.addWidget(self.leftBox)

        self.rightButtons = QFrame(self.contentTopBg)
        self.rightButtons.setObjectName(u"rightButtons")
        self.rightButtons.setMinimumSize(QSize(0, 28))
        self.rightButtons.setFrameShape(QFrame.NoFrame)
        self.rightButtons.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.rightButtons)
        self.horizontalLayout_2.setSpacing(5)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.settingsTopBtn = QPushButton(self.rightButtons)
        self.settingsTopBtn.setObjectName(u"settingsTopBtn")
        self.settingsTopBtn.setMinimumSize(QSize(28, 28))
        self.settingsTopBtn.setMaximumSize(QSize(28, 28))
        self.settingsTopBtn.setCursor(QCursor(Qt.PointingHandCursor))
        icon1 = QIcon()
        icon1.addFile(u":/icons/images/icons/icon_settings.png", QSize(), QIcon.Normal, QIcon.Off)
        self.settingsTopBtn.setIcon(icon1)
        self.settingsTopBtn.setIconSize(QSize(20, 20))

        self.horizontalLayout_2.addWidget(self.settingsTopBtn)

        self.minimizeAppBtn = QPushButton(self.rightButtons)
        self.minimizeAppBtn.setObjectName(u"minimizeAppBtn")
        self.minimizeAppBtn.setMinimumSize(QSize(28, 28))
        self.minimizeAppBtn.setMaximumSize(QSize(28, 28))
        self.minimizeAppBtn.setCursor(QCursor(Qt.PointingHandCursor))
        icon2 = QIcon()
        icon2.addFile(u":/icons/images/icons/icon_minimize.png", QSize(), QIcon.Normal, QIcon.Off)
        self.minimizeAppBtn.setIcon(icon2)
        self.minimizeAppBtn.setIconSize(QSize(20, 20))

        self.horizontalLayout_2.addWidget(self.minimizeAppBtn)

        self.maximizeRestoreAppBtn = QPushButton(self.rightButtons)
        self.maximizeRestoreAppBtn.setObjectName(u"maximizeRestoreAppBtn")
        self.maximizeRestoreAppBtn.setMinimumSize(QSize(28, 28))
        self.maximizeRestoreAppBtn.setMaximumSize(QSize(28, 28))
        font3 = QFont()
        font3.setFamily(u"Segoe UI")
        font3.setPointSize(10)
        font3.setBold(False)
        font3.setItalic(False)
        font3.setStyleStrategy(QFont.PreferDefault)
        self.maximizeRestoreAppBtn.setFont(font3)
        self.maximizeRestoreAppBtn.setCursor(QCursor(Qt.PointingHandCursor))
        icon3 = QIcon()
        icon3.addFile(u":/icons/images/icons/icon_maximize.png", QSize(), QIcon.Normal, QIcon.Off)
        self.maximizeRestoreAppBtn.setIcon(icon3)
        self.maximizeRestoreAppBtn.setIconSize(QSize(20, 20))

        self.horizontalLayout_2.addWidget(self.maximizeRestoreAppBtn)

        self.closeAppBtn = QPushButton(self.rightButtons)
        self.closeAppBtn.setObjectName(u"closeAppBtn")
        self.closeAppBtn.setMinimumSize(QSize(28, 28))
        self.closeAppBtn.setMaximumSize(QSize(28, 28))
        self.closeAppBtn.setCursor(QCursor(Qt.PointingHandCursor))
        self.closeAppBtn.setIcon(icon)
        self.closeAppBtn.setIconSize(QSize(20, 20))

        self.horizontalLayout_2.addWidget(self.closeAppBtn)


        self.horizontalLayout.addWidget(self.rightButtons, 0, Qt.AlignRight)


        self.verticalLayout_2.addWidget(self.contentTopBg)

        self.contentBottom = QFrame(self.contentBox)
        self.contentBottom.setObjectName(u"contentBottom")
        self.contentBottom.setFrameShape(QFrame.NoFrame)
        self.contentBottom.setFrameShadow(QFrame.Raised)
        self.verticalLayout_6 = QVBoxLayout(self.contentBottom)
        self.verticalLayout_6.setSpacing(0)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.content = QFrame(self.contentBottom)
        self.content.setObjectName(u"content")
        self.content.setFrameShape(QFrame.NoFrame)
        self.content.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_4 = QHBoxLayout(self.content)
        self.horizontalLayout_4.setSpacing(0)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.pagesContainer = QFrame(self.content)
        self.pagesContainer.setObjectName(u"pagesContainer")
        self.pagesContainer.setStyleSheet(u"")
        self.pagesContainer.setFrameShape(QFrame.NoFrame)
        self.pagesContainer.setFrameShadow(QFrame.Raised)
        self.verticalLayout_15 = QVBoxLayout(self.pagesContainer)
        self.verticalLayout_15.setSpacing(0)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.verticalLayout_15.setContentsMargins(10, 10, 10, 10)
        self.stackedWidget = QStackedWidget(self.pagesContainer)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.stackedWidget.setStyleSheet(u"background: transparent;")
        self.home = QWidget()
        self.home.setObjectName(u"home")
        self.home.setStyleSheet(u"background-image: url(:/images/images/images/PyDracula_vertical.png);\n"
"background-position: center;\n"
"background-repeat: no-repeat;")
        self.stackedWidget.addWidget(self.home)
        self.widgets = QWidget()
        self.widgets.setObjectName(u"widgets")
        self.widgets.setStyleSheet(u"b")
        self.verticalLayout = QVBoxLayout(self.widgets)
        self.verticalLayout.setSpacing(10)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(10, 10, 10, 10)
        self.row_1 = QFrame(self.widgets)
        self.row_1.setObjectName(u"row_1")
        self.row_1.setFrameShape(QFrame.StyledPanel)
        self.row_1.setFrameShadow(QFrame.Raised)
        self.verticalLayout_16 = QVBoxLayout(self.row_1)
        self.verticalLayout_16.setSpacing(0)
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.verticalLayout_16.setContentsMargins(0, 0, 0, 0)
        self.frame_div_content_1 = QFrame(self.row_1)
        self.frame_div_content_1.setObjectName(u"frame_div_content_1")
        self.frame_div_content_1.setMinimumSize(QSize(0, 110))
        self.frame_div_content_1.setMaximumSize(QSize(16777215, 110))
        self.frame_div_content_1.setFrameShape(QFrame.NoFrame)
        self.frame_div_content_1.setFrameShadow(QFrame.Raised)
        self.verticalLayout_17 = QVBoxLayout(self.frame_div_content_1)
        self.verticalLayout_17.setSpacing(0)
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")
        self.verticalLayout_17.setContentsMargins(0, 0, 0, 0)
        self.frame_title_wid_1 = QFrame(self.frame_div_content_1)
        self.frame_title_wid_1.setObjectName(u"frame_title_wid_1")
        self.frame_title_wid_1.setMaximumSize(QSize(16777215, 35))
        self.frame_title_wid_1.setFrameShape(QFrame.StyledPanel)
        self.frame_title_wid_1.setFrameShadow(QFrame.Raised)
        self.verticalLayout_18 = QVBoxLayout(self.frame_title_wid_1)
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")
        self.labelBoxBlenderInstalation = QLabel(self.frame_title_wid_1)
        self.labelBoxBlenderInstalation.setObjectName(u"labelBoxBlenderInstalation")
        self.labelBoxBlenderInstalation.setFont(font)
        self.labelBoxBlenderInstalation.setStyleSheet(u"")

        self.verticalLayout_18.addWidget(self.labelBoxBlenderInstalation)


        self.verticalLayout_17.addWidget(self.frame_title_wid_1)

        self.frame_content_wid_1 = QFrame(self.frame_div_content_1)
        self.frame_content_wid_1.setObjectName(u"frame_content_wid_1")
        self.frame_content_wid_1.setFrameShape(QFrame.NoFrame)
        self.frame_content_wid_1.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_9 = QHBoxLayout(self.frame_content_wid_1)
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.gridLayout = QGridLayout()
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(-1, -1, -1, 0)
        self.lineEdit = QLineEdit(self.frame_content_wid_1)
        self.lineEdit.setObjectName(u"lineEdit")
        self.lineEdit.setMinimumSize(QSize(0, 30))
        self.lineEdit.setStyleSheet(u"background-color: rgb(33, 37, 43);")

        self.gridLayout.addWidget(self.lineEdit, 0, 0, 1, 1)

        self.pushButton = QPushButton(self.frame_content_wid_1)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setMinimumSize(QSize(150, 30))
        self.pushButton.setFont(font)
        self.pushButton.setCursor(QCursor(Qt.PointingHandCursor))
        self.pushButton.setStyleSheet(u"background-color: rgb(52, 59, 72);")
        icon4 = QIcon()
        icon4.addFile(u":/icons/images/icons/cil-folder-open.png", QSize(), QIcon.Normal, QIcon.Off)
        self.pushButton.setIcon(icon4)

        self.gridLayout.addWidget(self.pushButton, 0, 1, 1, 1)

        self.labelVersion_3 = QLabel(self.frame_content_wid_1)
        self.labelVersion_3.setObjectName(u"labelVersion_3")
        self.labelVersion_3.setStyleSheet(u"color: rgb(113, 126, 149);")
        self.labelVersion_3.setLineWidth(1)
        self.labelVersion_3.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.gridLayout.addWidget(self.labelVersion_3, 1, 0, 1, 2)


        self.horizontalLayout_9.addLayout(self.gridLayout)


        self.verticalLayout_17.addWidget(self.frame_content_wid_1)


        self.verticalLayout_16.addWidget(self.frame_div_content_1)


        self.verticalLayout.addWidget(self.row_1)

        self.row_2 = QFrame(self.widgets)
        self.row_2.setObjectName(u"row_2")
        self.row_2.setMinimumSize(QSize(0, 150))
        self.row_2.setFrameShape(QFrame.StyledPanel)
        self.row_2.setFrameShadow(QFrame.Raised)
        self.verticalLayout_19 = QVBoxLayout(self.row_2)
        self.verticalLayout_19.setObjectName(u"verticalLayout_19")
        self.gridLayout_2 = QGridLayout()
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.checkBox = QCheckBox(self.row_2)
        self.checkBox.setObjectName(u"checkBox")
        self.checkBox.setAutoFillBackground(False)
        self.checkBox.setStyleSheet(u"")

        self.gridLayout_2.addWidget(self.checkBox, 0, 0, 1, 1)

        self.radioButton = QRadioButton(self.row_2)
        self.radioButton.setObjectName(u"radioButton")
        self.radioButton.setStyleSheet(u"")

        self.gridLayout_2.addWidget(self.radioButton, 0, 1, 1, 1)

        self.verticalSlider = QSlider(self.row_2)
        self.verticalSlider.setObjectName(u"verticalSlider")
        self.verticalSlider.setStyleSheet(u"")
        self.verticalSlider.setOrientation(Qt.Vertical)

        self.gridLayout_2.addWidget(self.verticalSlider, 0, 2, 3, 1)

        self.verticalScrollBar = QScrollBar(self.row_2)
        self.verticalScrollBar.setObjectName(u"verticalScrollBar")
        self.verticalScrollBar.setStyleSheet(u" QScrollBar:vertical { background: rgb(52, 59, 72); }\n"
" QScrollBar:horizontal { background: rgb(52, 59, 72); }")
        self.verticalScrollBar.setOrientation(Qt.Vertical)

        self.gridLayout_2.addWidget(self.verticalScrollBar, 0, 4, 3, 1)

        self.scrollArea = QScrollArea(self.row_2)
        self.scrollArea.setObjectName(u"scrollArea")
        self.scrollArea.setStyleSheet(u" QScrollBar:vertical {\n"
"    background: rgb(52, 59, 72);\n"
" }\n"
" QScrollBar:horizontal {\n"
"    background: rgb(52, 59, 72);\n"
" }")
        self.scrollArea.setFrameShape(QFrame.NoFrame)
        self.scrollArea.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.scrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scrollArea.setWidgetResizable(True)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 218, 218))
        self.scrollAreaWidgetContents.setStyleSheet(u" QScrollBar:vertical {\n"
"	border: none;\n"
"    background: rgb(52, 59, 72);\n"
"    width: 14px;\n"
"    margin: 21px 0 21px 0;\n"
"	border-radius: 0px;\n"
" }")
        self.horizontalLayout_11 = QHBoxLayout(self.scrollAreaWidgetContents)
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.plainTextEdit = QPlainTextEdit(self.scrollAreaWidgetContents)
        self.plainTextEdit.setObjectName(u"plainTextEdit")
        self.plainTextEdit.setMinimumSize(QSize(200, 200))
        self.plainTextEdit.setStyleSheet(u"background-color: rgb(33, 37, 43);")

        self.horizontalLayout_11.addWidget(self.plainTextEdit)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)

        self.gridLayout_2.addWidget(self.scrollArea, 0, 5, 3, 1)

        self.comboBox = QComboBox(self.row_2)
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.setObjectName(u"comboBox")
        self.comboBox.setFont(font)
        self.comboBox.setAutoFillBackground(False)
        self.comboBox.setStyleSheet(u"background-color: rgb(33, 37, 43);")
        self.comboBox.setIconSize(QSize(16, 16))
        self.comboBox.setFrame(True)

        self.gridLayout_2.addWidget(self.comboBox, 1, 0, 1, 2)

        self.horizontalScrollBar = QScrollBar(self.row_2)
        self.horizontalScrollBar.setObjectName(u"horizontalScrollBar")
        sizePolicy.setHeightForWidth(self.horizontalScrollBar.sizePolicy().hasHeightForWidth())
        self.horizontalScrollBar.setSizePolicy(sizePolicy)
        self.horizontalScrollBar.setStyleSheet(u" QScrollBar:vertical { background: rgb(52, 59, 72); }\n"
" QScrollBar:horizontal { background: rgb(52, 59, 72); }")
        self.horizontalScrollBar.setOrientation(Qt.Horizontal)

        self.gridLayout_2.addWidget(self.horizontalScrollBar, 1, 3, 1, 1)

        self.commandLinkButton = QCommandLinkButton(self.row_2)
        self.commandLinkButton.setObjectName(u"commandLinkButton")
        self.commandLinkButton.setCursor(QCursor(Qt.PointingHandCursor))
        self.commandLinkButton.setStyleSheet(u"")
        icon5 = QIcon()
        icon5.addFile(u":/icons/images/icons/cil-link.png", QSize(), QIcon.Normal, QIcon.Off)
        self.commandLinkButton.setIcon(icon5)

        self.gridLayout_2.addWidget(self.commandLinkButton, 1, 6, 1, 1)

        self.horizontalSlider = QSlider(self.row_2)
        self.horizontalSlider.setObjectName(u"horizontalSlider")
        self.horizontalSlider.setStyleSheet(u"")
        self.horizontalSlider.setOrientation(Qt.Horizontal)

        self.gridLayout_2.addWidget(self.horizontalSlider, 2, 0, 1, 2)


        self.verticalLayout_19.addLayout(self.gridLayout_2)


        self.verticalLayout.addWidget(self.row_2)

        self.row_3 = QFrame(self.widgets)
        self.row_3.setObjectName(u"row_3")
        self.row_3.setMinimumSize(QSize(0, 150))
        self.row_3.setFrameShape(QFrame.StyledPanel)
        self.row_3.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_12 = QHBoxLayout(self.row_3)
        self.horizontalLayout_12.setSpacing(0)
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.horizontalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.tableWidget = QTableWidget(self.row_3)
        if (self.tableWidget.columnCount() < 4):
            self.tableWidget.setColumnCount(4)
        __qtablewidgetitem = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        if (self.tableWidget.rowCount() < 16):
            self.tableWidget.setRowCount(16)
        font4 = QFont()
        font4.setFamily(u"Segoe UI")
        __qtablewidgetitem4 = QTableWidgetItem()
        __qtablewidgetitem4.setFont(font4);
        self.tableWidget.setVerticalHeaderItem(0, __qtablewidgetitem4)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(1, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(2, __qtablewidgetitem6)
        __qtablewidgetitem7 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(3, __qtablewidgetitem7)
        __qtablewidgetitem8 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(4, __qtablewidgetitem8)
        __qtablewidgetitem9 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(5, __qtablewidgetitem9)
        __qtablewidgetitem10 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(6, __qtablewidgetitem10)
        __qtablewidgetitem11 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(7, __qtablewidgetitem11)
        __qtablewidgetitem12 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(8, __qtablewidgetitem12)
        __qtablewidgetitem13 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(9, __qtablewidgetitem13)
        __qtablewidgetitem14 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(10, __qtablewidgetitem14)
        __qtablewidgetitem15 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(11, __qtablewidgetitem15)
        __qtablewidgetitem16 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(12, __qtablewidgetitem16)
        __qtablewidgetitem17 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(13, __qtablewidgetitem17)
        __qtablewidgetitem18 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(14, __qtablewidgetitem18)
        __qtablewidgetitem19 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(15, __qtablewidgetitem19)
        __qtablewidgetitem20 = QTableWidgetItem()
        self.tableWidget.setItem(0, 0, __qtablewidgetitem20)
        __qtablewidgetitem21 = QTableWidgetItem()
        self.tableWidget.setItem(0, 1, __qtablewidgetitem21)
        __qtablewidgetitem22 = QTableWidgetItem()
        self.tableWidget.setItem(0, 2, __qtablewidgetitem22)
        __qtablewidgetitem23 = QTableWidgetItem()
        self.tableWidget.setItem(0, 3, __qtablewidgetitem23)
        self.tableWidget.setObjectName(u"tableWidget")
        sizePolicy3 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.tableWidget.sizePolicy().hasHeightForWidth())
        self.tableWidget.setSizePolicy(sizePolicy3)
        palette = QPalette()
        brush = QBrush(QColor(221, 221, 221, 255))
        brush.setStyle(Qt.SolidPattern)
        palette.setBrush(QPalette.Active, QPalette.WindowText, brush)
        brush1 = QBrush(QColor(0, 0, 0, 0))
        brush1.setStyle(Qt.SolidPattern)
        palette.setBrush(QPalette.Active, QPalette.Button, brush1)
        palette.setBrush(QPalette.Active, QPalette.Text, brush)
        palette.setBrush(QPalette.Active, QPalette.ButtonText, brush)
        brush2 = QBrush(QColor(0, 0, 0, 255))
        brush2.setStyle(Qt.NoBrush)
        palette.setBrush(QPalette.Active, QPalette.Base, brush2)
        palette.setBrush(QPalette.Active, QPalette.Window, brush1)
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette.Active, QPalette.PlaceholderText, brush)
#endif
        palette.setBrush(QPalette.Inactive, QPalette.WindowText, brush)
        palette.setBrush(QPalette.Inactive, QPalette.Button, brush1)
        palette.setBrush(QPalette.Inactive, QPalette.Text, brush)
        palette.setBrush(QPalette.Inactive, QPalette.ButtonText, brush)
        brush3 = QBrush(QColor(0, 0, 0, 255))
        brush3.setStyle(Qt.NoBrush)
        palette.setBrush(QPalette.Inactive, QPalette.Base, brush3)
        palette.setBrush(QPalette.Inactive, QPalette.Window, brush1)
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette.Inactive, QPalette.PlaceholderText, brush)
#endif
        palette.setBrush(QPalette.Disabled, QPalette.WindowText, brush)
        palette.setBrush(QPalette.Disabled, QPalette.Button, brush1)
        palette.setBrush(QPalette.Disabled, QPalette.Text, brush)
        palette.setBrush(QPalette.Disabled, QPalette.ButtonText, brush)
        brush4 = QBrush(QColor(0, 0, 0, 255))
        brush4.setStyle(Qt.NoBrush)
        palette.setBrush(QPalette.Disabled, QPalette.Base, brush4)
        palette.setBrush(QPalette.Disabled, QPalette.Window, brush1)
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette.Disabled, QPalette.PlaceholderText, brush)
#endif
        self.tableWidget.setPalette(palette)
        self.tableWidget.setStyleSheet(u"\n"
"QTableWidget::item{\n"
"	padding-left: 5px;\n"
"	padding-right: 5px;\n"
"}\n"
"QTableWidget::item:selected{\n"
"	background-color: rgb(85, 170, 255);\n"
"}\n"
"QHeaderView::section{\n"
"	Background-color: rgb(39, 44, 54);\n"
"	max-width: 30px;\n"
"	border: 1px solid rgb(44, 49, 60);\n"
"	border-style: none;\n"
"    border-bottom: 1px solid rgb(44, 49, 60);\n"
"    border-right: 1px solid rgb(44, 49, 60);\n"
"}\n"
"QTableWidget::horizontalHeader {	\n"
"	background-color: rgb(81, 255, 0);\n"
"}\n"
"QHeaderView::section:horizontal\n"
"{\n"
"    border: 1px solid rgb(32, 34, 42);\n"
"	background-color: rgb(27, 29, 35);\n"
"	padding: 3px;\n"
"	border-top-left-radius: 7px;\n"
"    border-top-right-radius: 7px;\n"
"	font: italic 18pt \"Segoe UI\";\n"
"}\n"
"QHeaderView::section:vertical\n"
"{\n"
"    border: 1px solid rgb(44, 49, 60);\n"
"	font: italic 18pt \"Segoe UI\";\n"
"}\n"
"")
        self.tableWidget.setFrameShape(QFrame.NoFrame)
        self.tableWidget.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.tableWidget.setSizeAdjustPolicy(QAbstractScrollArea.AdjustToContents)
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tableWidget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tableWidget.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableWidget.setShowGrid(True)
        self.tableWidget.setGridStyle(Qt.SolidLine)
        self.tableWidget.setSortingEnabled(False)
        self.tableWidget.horizontalHeader().setVisible(False)
        self.tableWidget.horizontalHeader().setCascadingSectionResizes(True)
        self.tableWidget.horizontalHeader().setDefaultSectionSize(200)
        self.tableWidget.horizontalHeader().setStretchLastSection(True)
        self.tableWidget.verticalHeader().setVisible(False)
        self.tableWidget.verticalHeader().setCascadingSectionResizes(False)
        self.tableWidget.verticalHeader().setHighlightSections(False)
        self.tableWidget.verticalHeader().setStretchLastSection(True)

        self.horizontalLayout_12.addWidget(self.tableWidget)


        self.verticalLayout.addWidget(self.row_3)

        self.stackedWidget.addWidget(self.widgets)
        self.new_page = QWidget()
        self.new_page.setObjectName(u"new_page")
        self.new_page.setContextMenuPolicy(Qt.DefaultContextMenu)
        self.tableWidget_3 = QTableWidget(self.new_page)
        if (self.tableWidget_3.columnCount() < 20):
            self.tableWidget_3.setColumnCount(20)
        __qtablewidgetitem24 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(0, __qtablewidgetitem24)
        __qtablewidgetitem25 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(1, __qtablewidgetitem25)
        __qtablewidgetitem26 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(2, __qtablewidgetitem26)
        __qtablewidgetitem27 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(3, __qtablewidgetitem27)
        __qtablewidgetitem28 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(4, __qtablewidgetitem28)
        __qtablewidgetitem29 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(5, __qtablewidgetitem29)
        __qtablewidgetitem30 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(6, __qtablewidgetitem30)
        __qtablewidgetitem31 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(7, __qtablewidgetitem31)
        __qtablewidgetitem32 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(8, __qtablewidgetitem32)
        __qtablewidgetitem33 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(9, __qtablewidgetitem33)
        __qtablewidgetitem34 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(10, __qtablewidgetitem34)
        __qtablewidgetitem35 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(11, __qtablewidgetitem35)
        __qtablewidgetitem36 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(12, __qtablewidgetitem36)
        __qtablewidgetitem37 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(13, __qtablewidgetitem37)
        __qtablewidgetitem38 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(14, __qtablewidgetitem38)
        __qtablewidgetitem39 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(15, __qtablewidgetitem39)
        __qtablewidgetitem40 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(16, __qtablewidgetitem40)
        __qtablewidgetitem41 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(17, __qtablewidgetitem41)
        __qtablewidgetitem42 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(18, __qtablewidgetitem42)
        __qtablewidgetitem43 = QTableWidgetItem()
        self.tableWidget_3.setHorizontalHeaderItem(19, __qtablewidgetitem43)
        if (self.tableWidget_3.rowCount() < 55):
            self.tableWidget_3.setRowCount(55)
        __qtablewidgetitem44 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(0, __qtablewidgetitem44)
        __qtablewidgetitem45 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(1, __qtablewidgetitem45)
        __qtablewidgetitem46 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(2, __qtablewidgetitem46)
        __qtablewidgetitem47 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(3, __qtablewidgetitem47)
        __qtablewidgetitem48 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(4, __qtablewidgetitem48)
        __qtablewidgetitem49 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(5, __qtablewidgetitem49)
        __qtablewidgetitem50 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(6, __qtablewidgetitem50)
        __qtablewidgetitem51 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(7, __qtablewidgetitem51)
        __qtablewidgetitem52 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(8, __qtablewidgetitem52)
        __qtablewidgetitem53 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(9, __qtablewidgetitem53)
        __qtablewidgetitem54 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(10, __qtablewidgetitem54)
        __qtablewidgetitem55 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(11, __qtablewidgetitem55)
        __qtablewidgetitem56 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(12, __qtablewidgetitem56)
        __qtablewidgetitem57 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(13, __qtablewidgetitem57)
        __qtablewidgetitem58 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(14, __qtablewidgetitem58)
        __qtablewidgetitem59 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(15, __qtablewidgetitem59)
        __qtablewidgetitem60 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(16, __qtablewidgetitem60)
        __qtablewidgetitem61 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(17, __qtablewidgetitem61)
        __qtablewidgetitem62 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(18, __qtablewidgetitem62)
        __qtablewidgetitem63 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(19, __qtablewidgetitem63)
        __qtablewidgetitem64 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(20, __qtablewidgetitem64)
        __qtablewidgetitem65 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(21, __qtablewidgetitem65)
        __qtablewidgetitem66 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(22, __qtablewidgetitem66)
        __qtablewidgetitem67 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(23, __qtablewidgetitem67)
        __qtablewidgetitem68 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(24, __qtablewidgetitem68)
        __qtablewidgetitem69 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(25, __qtablewidgetitem69)
        __qtablewidgetitem70 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(26, __qtablewidgetitem70)
        __qtablewidgetitem71 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(27, __qtablewidgetitem71)
        __qtablewidgetitem72 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(28, __qtablewidgetitem72)
        __qtablewidgetitem73 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(29, __qtablewidgetitem73)
        __qtablewidgetitem74 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(30, __qtablewidgetitem74)
        __qtablewidgetitem75 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(31, __qtablewidgetitem75)
        __qtablewidgetitem76 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(32, __qtablewidgetitem76)
        __qtablewidgetitem77 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(33, __qtablewidgetitem77)
        __qtablewidgetitem78 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(34, __qtablewidgetitem78)
        __qtablewidgetitem79 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(35, __qtablewidgetitem79)
        __qtablewidgetitem80 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(36, __qtablewidgetitem80)
        __qtablewidgetitem81 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(37, __qtablewidgetitem81)
        __qtablewidgetitem82 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(38, __qtablewidgetitem82)
        __qtablewidgetitem83 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(39, __qtablewidgetitem83)
        __qtablewidgetitem84 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(40, __qtablewidgetitem84)
        __qtablewidgetitem85 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(41, __qtablewidgetitem85)
        __qtablewidgetitem86 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(42, __qtablewidgetitem86)
        __qtablewidgetitem87 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(43, __qtablewidgetitem87)
        __qtablewidgetitem88 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(44, __qtablewidgetitem88)
        __qtablewidgetitem89 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(45, __qtablewidgetitem89)
        __qtablewidgetitem90 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(46, __qtablewidgetitem90)
        __qtablewidgetitem91 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(47, __qtablewidgetitem91)
        __qtablewidgetitem92 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(48, __qtablewidgetitem92)
        __qtablewidgetitem93 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(49, __qtablewidgetitem93)
        __qtablewidgetitem94 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(50, __qtablewidgetitem94)
        __qtablewidgetitem95 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(51, __qtablewidgetitem95)
        __qtablewidgetitem96 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(52, __qtablewidgetitem96)
        __qtablewidgetitem97 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(53, __qtablewidgetitem97)
        __qtablewidgetitem98 = QTableWidgetItem()
        self.tableWidget_3.setVerticalHeaderItem(54, __qtablewidgetitem98)
        font5 = QFont()
        font5.setBold(False)
        __qtablewidgetitem99 = QTableWidgetItem()
        __qtablewidgetitem99.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem99.setFont(font5);
        self.tableWidget_3.setItem(0, 0, __qtablewidgetitem99)
        __qtablewidgetitem100 = QTableWidgetItem()
        __qtablewidgetitem100.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem100.setFont(font5);
        self.tableWidget_3.setItem(0, 2, __qtablewidgetitem100)
        __qtablewidgetitem101 = QTableWidgetItem()
        __qtablewidgetitem101.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem101.setFont(font5);
        self.tableWidget_3.setItem(0, 3, __qtablewidgetitem101)
        __qtablewidgetitem102 = QTableWidgetItem()
        __qtablewidgetitem102.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem102.setFont(font5);
        self.tableWidget_3.setItem(0, 4, __qtablewidgetitem102)
        __qtablewidgetitem103 = QTableWidgetItem()
        __qtablewidgetitem103.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem103.setFont(font5);
        self.tableWidget_3.setItem(0, 5, __qtablewidgetitem103)
        __qtablewidgetitem104 = QTableWidgetItem()
        __qtablewidgetitem104.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem104.setFont(font5);
        self.tableWidget_3.setItem(0, 7, __qtablewidgetitem104)
        __qtablewidgetitem105 = QTableWidgetItem()
        __qtablewidgetitem105.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem105.setFont(font5);
        self.tableWidget_3.setItem(0, 8, __qtablewidgetitem105)
        __qtablewidgetitem106 = QTableWidgetItem()
        __qtablewidgetitem106.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem106.setFont(font5);
        self.tableWidget_3.setItem(0, 9, __qtablewidgetitem106)
        __qtablewidgetitem107 = QTableWidgetItem()
        __qtablewidgetitem107.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem107.setFont(font5);
        self.tableWidget_3.setItem(0, 10, __qtablewidgetitem107)
        __qtablewidgetitem108 = QTableWidgetItem()
        __qtablewidgetitem108.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem108.setFont(font5);
        self.tableWidget_3.setItem(0, 11, __qtablewidgetitem108)
        __qtablewidgetitem109 = QTableWidgetItem()
        __qtablewidgetitem109.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem109.setFont(font5);
        self.tableWidget_3.setItem(0, 12, __qtablewidgetitem109)
        __qtablewidgetitem110 = QTableWidgetItem()
        __qtablewidgetitem110.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem110.setFont(font5);
        self.tableWidget_3.setItem(0, 13, __qtablewidgetitem110)
        __qtablewidgetitem111 = QTableWidgetItem()
        __qtablewidgetitem111.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem111.setFont(font5);
        self.tableWidget_3.setItem(0, 14, __qtablewidgetitem111)
        __qtablewidgetitem112 = QTableWidgetItem()
        __qtablewidgetitem112.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem112.setFont(font5);
        self.tableWidget_3.setItem(0, 15, __qtablewidgetitem112)
        __qtablewidgetitem113 = QTableWidgetItem()
        __qtablewidgetitem113.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem113.setFont(font5);
        self.tableWidget_3.setItem(0, 16, __qtablewidgetitem113)
        __qtablewidgetitem114 = QTableWidgetItem()
        __qtablewidgetitem114.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem114.setFont(font5);
        self.tableWidget_3.setItem(0, 17, __qtablewidgetitem114)
        __qtablewidgetitem115 = QTableWidgetItem()
        __qtablewidgetitem115.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem115.setFont(font5);
        self.tableWidget_3.setItem(0, 18, __qtablewidgetitem115)
        __qtablewidgetitem116 = QTableWidgetItem()
        __qtablewidgetitem116.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem116.setFont(font5);
        self.tableWidget_3.setItem(0, 19, __qtablewidgetitem116)
        __qtablewidgetitem117 = QTableWidgetItem()
        self.tableWidget_3.setItem(1, 2, __qtablewidgetitem117)
        __qtablewidgetitem118 = QTableWidgetItem()
        self.tableWidget_3.setItem(2, 2, __qtablewidgetitem118)
        __qtablewidgetitem119 = QTableWidgetItem()
        self.tableWidget_3.setItem(3, 2, __qtablewidgetitem119)
        __qtablewidgetitem120 = QTableWidgetItem()
        self.tableWidget_3.setItem(3, 5, __qtablewidgetitem120)
        __qtablewidgetitem121 = QTableWidgetItem()
        self.tableWidget_3.setItem(4, 2, __qtablewidgetitem121)
        __qtablewidgetitem122 = QTableWidgetItem()
        self.tableWidget_3.setItem(5, 2, __qtablewidgetitem122)
        __qtablewidgetitem123 = QTableWidgetItem()
        self.tableWidget_3.setItem(6, 2, __qtablewidgetitem123)
        __qtablewidgetitem124 = QTableWidgetItem()
        self.tableWidget_3.setItem(7, 2, __qtablewidgetitem124)
        __qtablewidgetitem125 = QTableWidgetItem()
        self.tableWidget_3.setItem(8, 2, __qtablewidgetitem125)
        __qtablewidgetitem126 = QTableWidgetItem()
        self.tableWidget_3.setItem(9, 2, __qtablewidgetitem126)
        __qtablewidgetitem127 = QTableWidgetItem()
        self.tableWidget_3.setItem(10, 2, __qtablewidgetitem127)
        __qtablewidgetitem128 = QTableWidgetItem()
        self.tableWidget_3.setItem(11, 2, __qtablewidgetitem128)
        __qtablewidgetitem129 = QTableWidgetItem()
        self.tableWidget_3.setItem(12, 2, __qtablewidgetitem129)
        __qtablewidgetitem130 = QTableWidgetItem()
        self.tableWidget_3.setItem(13, 2, __qtablewidgetitem130)
        __qtablewidgetitem131 = QTableWidgetItem()
        self.tableWidget_3.setItem(14, 2, __qtablewidgetitem131)
        __qtablewidgetitem132 = QTableWidgetItem()
        self.tableWidget_3.setItem(15, 2, __qtablewidgetitem132)
        __qtablewidgetitem133 = QTableWidgetItem()
        self.tableWidget_3.setItem(16, 2, __qtablewidgetitem133)
        __qtablewidgetitem134 = QTableWidgetItem()
        self.tableWidget_3.setItem(17, 2, __qtablewidgetitem134)
        __qtablewidgetitem135 = QTableWidgetItem()
        self.tableWidget_3.setItem(18, 2, __qtablewidgetitem135)
        __qtablewidgetitem136 = QTableWidgetItem()
        self.tableWidget_3.setItem(19, 2, __qtablewidgetitem136)
        __qtablewidgetitem137 = QTableWidgetItem()
        self.tableWidget_3.setItem(20, 2, __qtablewidgetitem137)
        __qtablewidgetitem138 = QTableWidgetItem()
        self.tableWidget_3.setItem(21, 2, __qtablewidgetitem138)
        __qtablewidgetitem139 = QTableWidgetItem()
        self.tableWidget_3.setItem(22, 2, __qtablewidgetitem139)
        __qtablewidgetitem140 = QTableWidgetItem()
        self.tableWidget_3.setItem(23, 2, __qtablewidgetitem140)
        __qtablewidgetitem141 = QTableWidgetItem()
        self.tableWidget_3.setItem(24, 2, __qtablewidgetitem141)
        __qtablewidgetitem142 = QTableWidgetItem()
        self.tableWidget_3.setItem(25, 2, __qtablewidgetitem142)
        __qtablewidgetitem143 = QTableWidgetItem()
        self.tableWidget_3.setItem(26, 2, __qtablewidgetitem143)
        __qtablewidgetitem144 = QTableWidgetItem()
        self.tableWidget_3.setItem(27, 2, __qtablewidgetitem144)
        __qtablewidgetitem145 = QTableWidgetItem()
        self.tableWidget_3.setItem(28, 2, __qtablewidgetitem145)
        __qtablewidgetitem146 = QTableWidgetItem()
        self.tableWidget_3.setItem(29, 2, __qtablewidgetitem146)
        __qtablewidgetitem147 = QTableWidgetItem()
        self.tableWidget_3.setItem(30, 2, __qtablewidgetitem147)
        __qtablewidgetitem148 = QTableWidgetItem()
        self.tableWidget_3.setItem(31, 2, __qtablewidgetitem148)
        __qtablewidgetitem149 = QTableWidgetItem()
        self.tableWidget_3.setItem(32, 2, __qtablewidgetitem149)
        __qtablewidgetitem150 = QTableWidgetItem()
        self.tableWidget_3.setItem(33, 2, __qtablewidgetitem150)
        __qtablewidgetitem151 = QTableWidgetItem()
        self.tableWidget_3.setItem(34, 2, __qtablewidgetitem151)
        __qtablewidgetitem152 = QTableWidgetItem()
        self.tableWidget_3.setItem(35, 2, __qtablewidgetitem152)
        __qtablewidgetitem153 = QTableWidgetItem()
        self.tableWidget_3.setItem(36, 2, __qtablewidgetitem153)
        __qtablewidgetitem154 = QTableWidgetItem()
        self.tableWidget_3.setItem(37, 2, __qtablewidgetitem154)
        __qtablewidgetitem155 = QTableWidgetItem()
        self.tableWidget_3.setItem(38, 2, __qtablewidgetitem155)
        __qtablewidgetitem156 = QTableWidgetItem()
        self.tableWidget_3.setItem(39, 2, __qtablewidgetitem156)
        __qtablewidgetitem157 = QTableWidgetItem()
        self.tableWidget_3.setItem(40, 2, __qtablewidgetitem157)
        __qtablewidgetitem158 = QTableWidgetItem()
        self.tableWidget_3.setItem(41, 2, __qtablewidgetitem158)
        __qtablewidgetitem159 = QTableWidgetItem()
        self.tableWidget_3.setItem(42, 2, __qtablewidgetitem159)
        __qtablewidgetitem160 = QTableWidgetItem()
        self.tableWidget_3.setItem(43, 2, __qtablewidgetitem160)
        __qtablewidgetitem161 = QTableWidgetItem()
        self.tableWidget_3.setItem(44, 2, __qtablewidgetitem161)
        __qtablewidgetitem162 = QTableWidgetItem()
        self.tableWidget_3.setItem(45, 2, __qtablewidgetitem162)
        __qtablewidgetitem163 = QTableWidgetItem()
        self.tableWidget_3.setItem(46, 2, __qtablewidgetitem163)
        __qtablewidgetitem164 = QTableWidgetItem()
        self.tableWidget_3.setItem(47, 2, __qtablewidgetitem164)
        __qtablewidgetitem165 = QTableWidgetItem()
        self.tableWidget_3.setItem(48, 2, __qtablewidgetitem165)
        self.tableWidget_3.setObjectName(u"tableWidget_3")
        self.tableWidget_3.setGeometry(QRect(0, 10, 1831, 941))
        sizePolicy3.setHeightForWidth(self.tableWidget_3.sizePolicy().hasHeightForWidth())
        self.tableWidget_3.setSizePolicy(sizePolicy3)
        palette1 = QPalette()
        palette1.setBrush(QPalette.Active, QPalette.WindowText, brush)
        brush5 = QBrush(QColor(39, 44, 54, 255))
        brush5.setStyle(Qt.SolidPattern)
        palette1.setBrush(QPalette.Active, QPalette.Button, brush5)
        palette1.setBrush(QPalette.Active, QPalette.Text, brush)
        palette1.setBrush(QPalette.Active, QPalette.ButtonText, brush)
        palette1.setBrush(QPalette.Active, QPalette.Base, brush5)
        palette1.setBrush(QPalette.Active, QPalette.Window, brush5)
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette1.setBrush(QPalette.Active, QPalette.PlaceholderText, brush)
#endif
        palette1.setBrush(QPalette.Inactive, QPalette.WindowText, brush)
        palette1.setBrush(QPalette.Inactive, QPalette.Button, brush5)
        palette1.setBrush(QPalette.Inactive, QPalette.Text, brush)
        palette1.setBrush(QPalette.Inactive, QPalette.ButtonText, brush)
        palette1.setBrush(QPalette.Inactive, QPalette.Base, brush5)
        palette1.setBrush(QPalette.Inactive, QPalette.Window, brush5)
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette1.setBrush(QPalette.Inactive, QPalette.PlaceholderText, brush)
#endif
        palette1.setBrush(QPalette.Disabled, QPalette.WindowText, brush)
        palette1.setBrush(QPalette.Disabled, QPalette.Button, brush5)
        palette1.setBrush(QPalette.Disabled, QPalette.Text, brush)
        palette1.setBrush(QPalette.Disabled, QPalette.ButtonText, brush)
        palette1.setBrush(QPalette.Disabled, QPalette.Base, brush5)
        palette1.setBrush(QPalette.Disabled, QPalette.Window, brush5)
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette1.setBrush(QPalette.Disabled, QPalette.PlaceholderText, brush)
#endif
        self.tableWidget_3.setPalette(palette1)
        font6 = QFont()
        font6.setFamily(u"Segoe UI")
        font6.setPointSize(12)
        font6.setBold(False)
        font6.setItalic(True)
        font6.setUnderline(False)
        font6.setStrikeOut(False)
        font6.setKerning(True)
        font6.setStyleStrategy(QFont.PreferAntialias)
        self.tableWidget_3.setFont(font6)
        self.tableWidget_3.setContextMenuPolicy(Qt.DefaultContextMenu)
        self.tableWidget_3.setAutoFillBackground(False)
        self.tableWidget_3.setStyleSheet(u"QTableWidget {	\n"
"	background-color: rgb(39, 44, 54);\n"
"	padding: 10px;\n"
"	border-radius: 5px;\n"
"	gridline-color: rgb(44, 49, 60);\n"
"	border-bottom: 1px solid rgb(44, 49, 60);\n"
"	font: italic 12pt \"Segoe UI\";\n"
"}\n"
"QTableWidget::item:selected{\n"
"	background-color: rgb(85, 170, 255);\n"
"}\n"
"QScrollBar:horizontal {\n"
"    border: none;\n"
"    background: rgb(52, 59, 72);\n"
"    height: 14px;\n"
"    margin: 0px 21px 0 21px;\n"
"	border-radius: 0px;\n"
"}\n"
" QScrollBar:vertical {\n"
"	border: none;\n"
"    background: rgb(52, 59, 72);\n"
"    width: 14px;\n"
"    margin: 21px 0 21px 0;\n"
"	border-radius: 0px;\n"
" }\n"
"QHeaderView::section{\n"
"	Background-color: rgb(39, 44, 54);\n"
"	max-width: 30px;\n"
"	border: 1px solid rgb(44, 49, 60);\n"
"	border-style: none;\n"
"    border-bottom: 1px solid rgb(44, 49, 60);\n"
"    border-right: 1px solid rgb(44, 49, 60);\n"
"}\n"
"QTableWidget::horizontalHeader {	\n"
"	background-color: rgb(81, 255, 0);\n"
"}\n"
"QHeaderView::section:horizont"
                        "al\n"
"{\n"
"    border: 1px solid rgb(32, 34, 42);\n"
"	background-color: rgb(27, 29, 35);\n"
"	padding: 3px;\n"
"	border-top-left-radius: 7px;\n"
"    border-top-right-radius: 7px;\n"
"	font: italic 12pt \"Segoe UI\";\n"
"}\n"
"QHeaderView::section:vertical\n"
"{\n"
"    border: 1px solid rgb(44, 49, 60);\n"
"	font: italic 12pt \"Segoe UI\";\n"
"}\n"
"")
        self.tableWidget_3.setFrameShape(QFrame.NoFrame)
        self.tableWidget_3.setLineWidth(1)
        self.tableWidget_3.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.tableWidget_3.setSizeAdjustPolicy(QAbstractScrollArea.AdjustToContents)
        self.tableWidget_3.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tableWidget_3.setDragEnabled(False)
        self.tableWidget_3.setAlternatingRowColors(False)
        self.tableWidget_3.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tableWidget_3.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableWidget_3.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.tableWidget_3.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.tableWidget_3.setShowGrid(True)
        self.tableWidget_3.setGridStyle(Qt.SolidLine)
        self.tableWidget_3.setSortingEnabled(False)
        self.tableWidget_3.horizontalHeader().setVisible(False)
        self.tableWidget_3.horizontalHeader().setCascadingSectionResizes(True)
        self.tableWidget_3.horizontalHeader().setDefaultSectionSize(200)
        self.tableWidget_3.horizontalHeader().setProperty("showSortIndicator", True)
        self.tableWidget_3.horizontalHeader().setStretchLastSection(True)
        self.tableWidget_3.verticalHeader().setVisible(False)
        self.tableWidget_3.verticalHeader().setCascadingSectionResizes(True)
        self.tableWidget_3.verticalHeader().setHighlightSections(True)
        self.tableWidget_3.verticalHeader().setProperty("showSortIndicator", True)
        self.tableWidget_3.verticalHeader().setStretchLastSection(True)
        self.label = QLabel(self.new_page)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(10, 0, 171, 16))
        self.stackedWidget.addWidget(self.new_page)
        self.new_TV = QWidget()
        self.new_TV.setObjectName(u"new_TV")
        self.tableWidget_4 = QTableWidget(self.new_TV)
        if (self.tableWidget_4.columnCount() < 7):
            self.tableWidget_4.setColumnCount(7)
        __qtablewidgetitem166 = QTableWidgetItem()
        self.tableWidget_4.setHorizontalHeaderItem(0, __qtablewidgetitem166)
        __qtablewidgetitem167 = QTableWidgetItem()
        self.tableWidget_4.setHorizontalHeaderItem(1, __qtablewidgetitem167)
        __qtablewidgetitem168 = QTableWidgetItem()
        self.tableWidget_4.setHorizontalHeaderItem(2, __qtablewidgetitem168)
        __qtablewidgetitem169 = QTableWidgetItem()
        self.tableWidget_4.setHorizontalHeaderItem(3, __qtablewidgetitem169)
        __qtablewidgetitem170 = QTableWidgetItem()
        self.tableWidget_4.setHorizontalHeaderItem(4, __qtablewidgetitem170)
        __qtablewidgetitem171 = QTableWidgetItem()
        self.tableWidget_4.setHorizontalHeaderItem(5, __qtablewidgetitem171)
        __qtablewidgetitem172 = QTableWidgetItem()
        self.tableWidget_4.setHorizontalHeaderItem(6, __qtablewidgetitem172)
        if (self.tableWidget_4.rowCount() < 27):
            self.tableWidget_4.setRowCount(27)
        __qtablewidgetitem173 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(0, __qtablewidgetitem173)
        __qtablewidgetitem174 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(1, __qtablewidgetitem174)
        __qtablewidgetitem175 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(2, __qtablewidgetitem175)
        __qtablewidgetitem176 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(3, __qtablewidgetitem176)
        __qtablewidgetitem177 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(4, __qtablewidgetitem177)
        __qtablewidgetitem178 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(5, __qtablewidgetitem178)
        __qtablewidgetitem179 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(6, __qtablewidgetitem179)
        __qtablewidgetitem180 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(7, __qtablewidgetitem180)
        __qtablewidgetitem181 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(8, __qtablewidgetitem181)
        __qtablewidgetitem182 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(9, __qtablewidgetitem182)
        __qtablewidgetitem183 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(10, __qtablewidgetitem183)
        __qtablewidgetitem184 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(11, __qtablewidgetitem184)
        __qtablewidgetitem185 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(12, __qtablewidgetitem185)
        __qtablewidgetitem186 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(13, __qtablewidgetitem186)
        __qtablewidgetitem187 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(14, __qtablewidgetitem187)
        __qtablewidgetitem188 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(15, __qtablewidgetitem188)
        __qtablewidgetitem189 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(16, __qtablewidgetitem189)
        __qtablewidgetitem190 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(17, __qtablewidgetitem190)
        __qtablewidgetitem191 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(18, __qtablewidgetitem191)
        __qtablewidgetitem192 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(19, __qtablewidgetitem192)
        __qtablewidgetitem193 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(20, __qtablewidgetitem193)
        __qtablewidgetitem194 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(21, __qtablewidgetitem194)
        __qtablewidgetitem195 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(22, __qtablewidgetitem195)
        __qtablewidgetitem196 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(23, __qtablewidgetitem196)
        __qtablewidgetitem197 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(24, __qtablewidgetitem197)
        __qtablewidgetitem198 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(25, __qtablewidgetitem198)
        __qtablewidgetitem199 = QTableWidgetItem()
        self.tableWidget_4.setVerticalHeaderItem(26, __qtablewidgetitem199)
        __qtablewidgetitem200 = QTableWidgetItem()
        __qtablewidgetitem200.setFont(font5);
        self.tableWidget_4.setItem(0, 0, __qtablewidgetitem200)
        __qtablewidgetitem201 = QTableWidgetItem()
        __qtablewidgetitem201.setFont(font5);
        self.tableWidget_4.setItem(0, 1, __qtablewidgetitem201)
        __qtablewidgetitem202 = QTableWidgetItem()
        __qtablewidgetitem202.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem202.setFont(font5);
        self.tableWidget_4.setItem(0, 2, __qtablewidgetitem202)
        __qtablewidgetitem203 = QTableWidgetItem()
        __qtablewidgetitem203.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem203.setFont(font5);
        self.tableWidget_4.setItem(0, 3, __qtablewidgetitem203)
        __qtablewidgetitem204 = QTableWidgetItem()
        __qtablewidgetitem204.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem204.setFont(font5);
        self.tableWidget_4.setItem(0, 4, __qtablewidgetitem204)
        __qtablewidgetitem205 = QTableWidgetItem()
        __qtablewidgetitem205.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem205.setFont(font5);
        self.tableWidget_4.setItem(0, 5, __qtablewidgetitem205)
        __qtablewidgetitem206 = QTableWidgetItem()
        __qtablewidgetitem206.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem206.setFont(font5);
        self.tableWidget_4.setItem(0, 6, __qtablewidgetitem206)
        __qtablewidgetitem207 = QTableWidgetItem()
        __qtablewidgetitem207.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(1, 2, __qtablewidgetitem207)
        __qtablewidgetitem208 = QTableWidgetItem()
        __qtablewidgetitem208.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(1, 3, __qtablewidgetitem208)
        __qtablewidgetitem209 = QTableWidgetItem()
        __qtablewidgetitem209.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(1, 4, __qtablewidgetitem209)
        __qtablewidgetitem210 = QTableWidgetItem()
        __qtablewidgetitem210.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(1, 5, __qtablewidgetitem210)
        __qtablewidgetitem211 = QTableWidgetItem()
        __qtablewidgetitem211.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(1, 6, __qtablewidgetitem211)
        __qtablewidgetitem212 = QTableWidgetItem()
        __qtablewidgetitem212.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(2, 2, __qtablewidgetitem212)
        __qtablewidgetitem213 = QTableWidgetItem()
        __qtablewidgetitem213.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(2, 3, __qtablewidgetitem213)
        __qtablewidgetitem214 = QTableWidgetItem()
        __qtablewidgetitem214.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(2, 4, __qtablewidgetitem214)
        __qtablewidgetitem215 = QTableWidgetItem()
        __qtablewidgetitem215.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(2, 5, __qtablewidgetitem215)
        __qtablewidgetitem216 = QTableWidgetItem()
        __qtablewidgetitem216.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(2, 6, __qtablewidgetitem216)
        __qtablewidgetitem217 = QTableWidgetItem()
        __qtablewidgetitem217.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(3, 2, __qtablewidgetitem217)
        __qtablewidgetitem218 = QTableWidgetItem()
        __qtablewidgetitem218.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(3, 3, __qtablewidgetitem218)
        __qtablewidgetitem219 = QTableWidgetItem()
        __qtablewidgetitem219.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(3, 4, __qtablewidgetitem219)
        __qtablewidgetitem220 = QTableWidgetItem()
        __qtablewidgetitem220.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(3, 5, __qtablewidgetitem220)
        __qtablewidgetitem221 = QTableWidgetItem()
        __qtablewidgetitem221.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(3, 6, __qtablewidgetitem221)
        __qtablewidgetitem222 = QTableWidgetItem()
        __qtablewidgetitem222.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(4, 2, __qtablewidgetitem222)
        __qtablewidgetitem223 = QTableWidgetItem()
        __qtablewidgetitem223.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(4, 3, __qtablewidgetitem223)
        __qtablewidgetitem224 = QTableWidgetItem()
        __qtablewidgetitem224.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(4, 4, __qtablewidgetitem224)
        __qtablewidgetitem225 = QTableWidgetItem()
        __qtablewidgetitem225.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(4, 5, __qtablewidgetitem225)
        __qtablewidgetitem226 = QTableWidgetItem()
        __qtablewidgetitem226.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(4, 6, __qtablewidgetitem226)
        __qtablewidgetitem227 = QTableWidgetItem()
        __qtablewidgetitem227.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(5, 2, __qtablewidgetitem227)
        __qtablewidgetitem228 = QTableWidgetItem()
        __qtablewidgetitem228.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(5, 3, __qtablewidgetitem228)
        __qtablewidgetitem229 = QTableWidgetItem()
        __qtablewidgetitem229.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(5, 4, __qtablewidgetitem229)
        __qtablewidgetitem230 = QTableWidgetItem()
        __qtablewidgetitem230.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(5, 5, __qtablewidgetitem230)
        __qtablewidgetitem231 = QTableWidgetItem()
        __qtablewidgetitem231.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(5, 6, __qtablewidgetitem231)
        __qtablewidgetitem232 = QTableWidgetItem()
        __qtablewidgetitem232.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(6, 2, __qtablewidgetitem232)
        __qtablewidgetitem233 = QTableWidgetItem()
        __qtablewidgetitem233.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(6, 3, __qtablewidgetitem233)
        __qtablewidgetitem234 = QTableWidgetItem()
        __qtablewidgetitem234.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(6, 4, __qtablewidgetitem234)
        __qtablewidgetitem235 = QTableWidgetItem()
        __qtablewidgetitem235.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(6, 5, __qtablewidgetitem235)
        __qtablewidgetitem236 = QTableWidgetItem()
        __qtablewidgetitem236.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(6, 6, __qtablewidgetitem236)
        __qtablewidgetitem237 = QTableWidgetItem()
        __qtablewidgetitem237.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(7, 2, __qtablewidgetitem237)
        __qtablewidgetitem238 = QTableWidgetItem()
        __qtablewidgetitem238.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(7, 3, __qtablewidgetitem238)
        __qtablewidgetitem239 = QTableWidgetItem()
        __qtablewidgetitem239.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(7, 4, __qtablewidgetitem239)
        __qtablewidgetitem240 = QTableWidgetItem()
        __qtablewidgetitem240.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(7, 5, __qtablewidgetitem240)
        __qtablewidgetitem241 = QTableWidgetItem()
        __qtablewidgetitem241.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(7, 6, __qtablewidgetitem241)
        __qtablewidgetitem242 = QTableWidgetItem()
        __qtablewidgetitem242.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(8, 2, __qtablewidgetitem242)
        __qtablewidgetitem243 = QTableWidgetItem()
        __qtablewidgetitem243.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(8, 3, __qtablewidgetitem243)
        __qtablewidgetitem244 = QTableWidgetItem()
        __qtablewidgetitem244.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(8, 4, __qtablewidgetitem244)
        __qtablewidgetitem245 = QTableWidgetItem()
        __qtablewidgetitem245.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(8, 5, __qtablewidgetitem245)
        __qtablewidgetitem246 = QTableWidgetItem()
        __qtablewidgetitem246.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(8, 6, __qtablewidgetitem246)
        __qtablewidgetitem247 = QTableWidgetItem()
        __qtablewidgetitem247.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(9, 2, __qtablewidgetitem247)
        __qtablewidgetitem248 = QTableWidgetItem()
        __qtablewidgetitem248.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(9, 3, __qtablewidgetitem248)
        __qtablewidgetitem249 = QTableWidgetItem()
        __qtablewidgetitem249.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(9, 4, __qtablewidgetitem249)
        __qtablewidgetitem250 = QTableWidgetItem()
        __qtablewidgetitem250.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(9, 5, __qtablewidgetitem250)
        __qtablewidgetitem251 = QTableWidgetItem()
        __qtablewidgetitem251.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(9, 6, __qtablewidgetitem251)
        __qtablewidgetitem252 = QTableWidgetItem()
        __qtablewidgetitem252.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(10, 2, __qtablewidgetitem252)
        __qtablewidgetitem253 = QTableWidgetItem()
        __qtablewidgetitem253.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(10, 3, __qtablewidgetitem253)
        __qtablewidgetitem254 = QTableWidgetItem()
        __qtablewidgetitem254.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(10, 4, __qtablewidgetitem254)
        __qtablewidgetitem255 = QTableWidgetItem()
        __qtablewidgetitem255.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(10, 5, __qtablewidgetitem255)
        __qtablewidgetitem256 = QTableWidgetItem()
        __qtablewidgetitem256.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(10, 6, __qtablewidgetitem256)
        __qtablewidgetitem257 = QTableWidgetItem()
        __qtablewidgetitem257.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(11, 2, __qtablewidgetitem257)
        __qtablewidgetitem258 = QTableWidgetItem()
        __qtablewidgetitem258.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(11, 3, __qtablewidgetitem258)
        __qtablewidgetitem259 = QTableWidgetItem()
        __qtablewidgetitem259.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(11, 4, __qtablewidgetitem259)
        __qtablewidgetitem260 = QTableWidgetItem()
        __qtablewidgetitem260.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(11, 5, __qtablewidgetitem260)
        __qtablewidgetitem261 = QTableWidgetItem()
        __qtablewidgetitem261.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(11, 6, __qtablewidgetitem261)
        __qtablewidgetitem262 = QTableWidgetItem()
        __qtablewidgetitem262.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(12, 2, __qtablewidgetitem262)
        __qtablewidgetitem263 = QTableWidgetItem()
        __qtablewidgetitem263.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(12, 3, __qtablewidgetitem263)
        __qtablewidgetitem264 = QTableWidgetItem()
        __qtablewidgetitem264.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(12, 4, __qtablewidgetitem264)
        __qtablewidgetitem265 = QTableWidgetItem()
        __qtablewidgetitem265.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(12, 5, __qtablewidgetitem265)
        __qtablewidgetitem266 = QTableWidgetItem()
        __qtablewidgetitem266.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(12, 6, __qtablewidgetitem266)
        __qtablewidgetitem267 = QTableWidgetItem()
        __qtablewidgetitem267.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(13, 2, __qtablewidgetitem267)
        __qtablewidgetitem268 = QTableWidgetItem()
        __qtablewidgetitem268.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(13, 3, __qtablewidgetitem268)
        __qtablewidgetitem269 = QTableWidgetItem()
        __qtablewidgetitem269.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(13, 4, __qtablewidgetitem269)
        __qtablewidgetitem270 = QTableWidgetItem()
        __qtablewidgetitem270.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(13, 5, __qtablewidgetitem270)
        __qtablewidgetitem271 = QTableWidgetItem()
        __qtablewidgetitem271.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(13, 6, __qtablewidgetitem271)
        __qtablewidgetitem272 = QTableWidgetItem()
        __qtablewidgetitem272.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(14, 2, __qtablewidgetitem272)
        __qtablewidgetitem273 = QTableWidgetItem()
        __qtablewidgetitem273.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(14, 3, __qtablewidgetitem273)
        __qtablewidgetitem274 = QTableWidgetItem()
        __qtablewidgetitem274.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(14, 4, __qtablewidgetitem274)
        __qtablewidgetitem275 = QTableWidgetItem()
        __qtablewidgetitem275.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(14, 5, __qtablewidgetitem275)
        __qtablewidgetitem276 = QTableWidgetItem()
        __qtablewidgetitem276.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(14, 6, __qtablewidgetitem276)
        __qtablewidgetitem277 = QTableWidgetItem()
        __qtablewidgetitem277.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(15, 2, __qtablewidgetitem277)
        __qtablewidgetitem278 = QTableWidgetItem()
        __qtablewidgetitem278.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(15, 3, __qtablewidgetitem278)
        __qtablewidgetitem279 = QTableWidgetItem()
        __qtablewidgetitem279.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(15, 4, __qtablewidgetitem279)
        __qtablewidgetitem280 = QTableWidgetItem()
        __qtablewidgetitem280.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(15, 5, __qtablewidgetitem280)
        __qtablewidgetitem281 = QTableWidgetItem()
        __qtablewidgetitem281.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(15, 6, __qtablewidgetitem281)
        __qtablewidgetitem282 = QTableWidgetItem()
        __qtablewidgetitem282.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(16, 2, __qtablewidgetitem282)
        __qtablewidgetitem283 = QTableWidgetItem()
        __qtablewidgetitem283.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(16, 3, __qtablewidgetitem283)
        __qtablewidgetitem284 = QTableWidgetItem()
        __qtablewidgetitem284.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(16, 4, __qtablewidgetitem284)
        __qtablewidgetitem285 = QTableWidgetItem()
        __qtablewidgetitem285.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(16, 5, __qtablewidgetitem285)
        __qtablewidgetitem286 = QTableWidgetItem()
        __qtablewidgetitem286.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(16, 6, __qtablewidgetitem286)
        __qtablewidgetitem287 = QTableWidgetItem()
        __qtablewidgetitem287.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(17, 2, __qtablewidgetitem287)
        __qtablewidgetitem288 = QTableWidgetItem()
        __qtablewidgetitem288.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(17, 3, __qtablewidgetitem288)
        __qtablewidgetitem289 = QTableWidgetItem()
        __qtablewidgetitem289.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(17, 4, __qtablewidgetitem289)
        __qtablewidgetitem290 = QTableWidgetItem()
        __qtablewidgetitem290.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(17, 5, __qtablewidgetitem290)
        __qtablewidgetitem291 = QTableWidgetItem()
        __qtablewidgetitem291.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(17, 6, __qtablewidgetitem291)
        __qtablewidgetitem292 = QTableWidgetItem()
        __qtablewidgetitem292.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(18, 2, __qtablewidgetitem292)
        __qtablewidgetitem293 = QTableWidgetItem()
        __qtablewidgetitem293.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(18, 3, __qtablewidgetitem293)
        __qtablewidgetitem294 = QTableWidgetItem()
        __qtablewidgetitem294.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(18, 4, __qtablewidgetitem294)
        __qtablewidgetitem295 = QTableWidgetItem()
        __qtablewidgetitem295.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(18, 5, __qtablewidgetitem295)
        __qtablewidgetitem296 = QTableWidgetItem()
        __qtablewidgetitem296.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(18, 6, __qtablewidgetitem296)
        __qtablewidgetitem297 = QTableWidgetItem()
        __qtablewidgetitem297.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(19, 2, __qtablewidgetitem297)
        __qtablewidgetitem298 = QTableWidgetItem()
        __qtablewidgetitem298.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(19, 3, __qtablewidgetitem298)
        __qtablewidgetitem299 = QTableWidgetItem()
        __qtablewidgetitem299.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(19, 4, __qtablewidgetitem299)
        __qtablewidgetitem300 = QTableWidgetItem()
        __qtablewidgetitem300.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(19, 5, __qtablewidgetitem300)
        __qtablewidgetitem301 = QTableWidgetItem()
        __qtablewidgetitem301.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(19, 6, __qtablewidgetitem301)
        __qtablewidgetitem302 = QTableWidgetItem()
        __qtablewidgetitem302.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(20, 2, __qtablewidgetitem302)
        __qtablewidgetitem303 = QTableWidgetItem()
        __qtablewidgetitem303.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(20, 3, __qtablewidgetitem303)
        __qtablewidgetitem304 = QTableWidgetItem()
        __qtablewidgetitem304.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(20, 4, __qtablewidgetitem304)
        __qtablewidgetitem305 = QTableWidgetItem()
        __qtablewidgetitem305.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(20, 5, __qtablewidgetitem305)
        __qtablewidgetitem306 = QTableWidgetItem()
        __qtablewidgetitem306.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(20, 6, __qtablewidgetitem306)
        __qtablewidgetitem307 = QTableWidgetItem()
        __qtablewidgetitem307.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(21, 2, __qtablewidgetitem307)
        __qtablewidgetitem308 = QTableWidgetItem()
        __qtablewidgetitem308.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(21, 3, __qtablewidgetitem308)
        __qtablewidgetitem309 = QTableWidgetItem()
        __qtablewidgetitem309.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(21, 4, __qtablewidgetitem309)
        __qtablewidgetitem310 = QTableWidgetItem()
        __qtablewidgetitem310.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(21, 5, __qtablewidgetitem310)
        __qtablewidgetitem311 = QTableWidgetItem()
        __qtablewidgetitem311.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(21, 6, __qtablewidgetitem311)
        __qtablewidgetitem312 = QTableWidgetItem()
        __qtablewidgetitem312.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(22, 2, __qtablewidgetitem312)
        __qtablewidgetitem313 = QTableWidgetItem()
        __qtablewidgetitem313.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(22, 3, __qtablewidgetitem313)
        __qtablewidgetitem314 = QTableWidgetItem()
        __qtablewidgetitem314.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(22, 4, __qtablewidgetitem314)
        __qtablewidgetitem315 = QTableWidgetItem()
        __qtablewidgetitem315.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(22, 5, __qtablewidgetitem315)
        __qtablewidgetitem316 = QTableWidgetItem()
        __qtablewidgetitem316.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(22, 6, __qtablewidgetitem316)
        __qtablewidgetitem317 = QTableWidgetItem()
        __qtablewidgetitem317.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(23, 2, __qtablewidgetitem317)
        __qtablewidgetitem318 = QTableWidgetItem()
        __qtablewidgetitem318.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(23, 3, __qtablewidgetitem318)
        __qtablewidgetitem319 = QTableWidgetItem()
        __qtablewidgetitem319.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(23, 4, __qtablewidgetitem319)
        __qtablewidgetitem320 = QTableWidgetItem()
        __qtablewidgetitem320.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(23, 5, __qtablewidgetitem320)
        __qtablewidgetitem321 = QTableWidgetItem()
        __qtablewidgetitem321.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(23, 6, __qtablewidgetitem321)
        __qtablewidgetitem322 = QTableWidgetItem()
        __qtablewidgetitem322.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(24, 2, __qtablewidgetitem322)
        __qtablewidgetitem323 = QTableWidgetItem()
        __qtablewidgetitem323.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(24, 3, __qtablewidgetitem323)
        __qtablewidgetitem324 = QTableWidgetItem()
        __qtablewidgetitem324.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(24, 4, __qtablewidgetitem324)
        __qtablewidgetitem325 = QTableWidgetItem()
        __qtablewidgetitem325.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(24, 5, __qtablewidgetitem325)
        __qtablewidgetitem326 = QTableWidgetItem()
        __qtablewidgetitem326.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(24, 6, __qtablewidgetitem326)
        __qtablewidgetitem327 = QTableWidgetItem()
        __qtablewidgetitem327.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(25, 2, __qtablewidgetitem327)
        __qtablewidgetitem328 = QTableWidgetItem()
        __qtablewidgetitem328.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(25, 3, __qtablewidgetitem328)
        __qtablewidgetitem329 = QTableWidgetItem()
        __qtablewidgetitem329.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(25, 4, __qtablewidgetitem329)
        __qtablewidgetitem330 = QTableWidgetItem()
        __qtablewidgetitem330.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(25, 5, __qtablewidgetitem330)
        __qtablewidgetitem331 = QTableWidgetItem()
        __qtablewidgetitem331.setTextAlignment(Qt.AlignCenter);
        self.tableWidget_4.setItem(25, 6, __qtablewidgetitem331)
        self.tableWidget_4.setObjectName(u"tableWidget_4")
        self.tableWidget_4.setGeometry(QRect(0, 10, 901, 951))
        sizePolicy3.setHeightForWidth(self.tableWidget_4.sizePolicy().hasHeightForWidth())
        self.tableWidget_4.setSizePolicy(sizePolicy3)
        palette2 = QPalette()
        palette2.setBrush(QPalette.Active, QPalette.WindowText, brush)
        palette2.setBrush(QPalette.Active, QPalette.Button, brush5)
        palette2.setBrush(QPalette.Active, QPalette.Text, brush)
        palette2.setBrush(QPalette.Active, QPalette.ButtonText, brush)
        palette2.setBrush(QPalette.Active, QPalette.Base, brush5)
        palette2.setBrush(QPalette.Active, QPalette.Window, brush5)
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette2.setBrush(QPalette.Active, QPalette.PlaceholderText, brush)
#endif
        palette2.setBrush(QPalette.Inactive, QPalette.WindowText, brush)
        palette2.setBrush(QPalette.Inactive, QPalette.Button, brush5)
        palette2.setBrush(QPalette.Inactive, QPalette.Text, brush)
        palette2.setBrush(QPalette.Inactive, QPalette.ButtonText, brush)
        palette2.setBrush(QPalette.Inactive, QPalette.Base, brush5)
        palette2.setBrush(QPalette.Inactive, QPalette.Window, brush5)
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette2.setBrush(QPalette.Inactive, QPalette.PlaceholderText, brush)
#endif
        palette2.setBrush(QPalette.Disabled, QPalette.WindowText, brush)
        palette2.setBrush(QPalette.Disabled, QPalette.Button, brush5)
        palette2.setBrush(QPalette.Disabled, QPalette.Text, brush)
        palette2.setBrush(QPalette.Disabled, QPalette.ButtonText, brush)
        palette2.setBrush(QPalette.Disabled, QPalette.Base, brush5)
        palette2.setBrush(QPalette.Disabled, QPalette.Window, brush5)
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette2.setBrush(QPalette.Disabled, QPalette.PlaceholderText, brush)
#endif
        self.tableWidget_4.setPalette(palette2)
        font7 = QFont()
        font7.setFamily(u"Segoe UI")
        font7.setPointSize(18)
        font7.setBold(False)
        font7.setItalic(True)
        font7.setUnderline(False)
        font7.setStrikeOut(False)
        font7.setKerning(True)
        font7.setStyleStrategy(QFont.PreferAntialias)
        self.tableWidget_4.setFont(font7)
        self.tableWidget_4.setContextMenuPolicy(Qt.DefaultContextMenu)
        self.tableWidget_4.setAutoFillBackground(False)
        self.tableWidget_4.setStyleSheet(u"QTableWidget {	\n"
"	background-color: rgb(39, 44, 54);\n"
"	padding: 10px;\n"
"	border-radius: 5px;\n"
"	gridline-color: gray;\n"
"	border-bottom: 1px solid rgb(44, 49, 60);\n"
"	font: italic 18pt \"Segoe UI\";\n"
"	border-style: none;\n"
"	padding-left: 1px;\n"
"	padding-right: 1px;\n"
"	alignment: center;\n"
"}\n"
"QTableWidget::item{\n"
"	padding-left: 5px;\n"
"	padding-right: 5px;\n"
"}\n"
"QTableWidget::item:selected{\n"
"	background-color: rgb(85, 170, 255);\n"
"	text-align: center;\n"
"}\n"
"QHeaderView::section{\n"
"	Background-color: rgb(39, 44, 54);\n"
"	max-width: 30px;\n"
"	border: 1px solid rgb(44, 49, 60);\n"
"	border-style: none;\n"
"    border-bottom: 1px solid rgb(44, 49, 60);\n"
"    border-right: 1px solid rgb(44, 49, 60);\n"
"}\n"
"QTableWidget::horizontalHeader {	\n"
"	background-color: rgb(81, 255, 0);\n"
"}\n"
"QHeaderView::section:horizontal\n"
"{\n"
"    border: 1px solid rgb(32, 34, 42);\n"
"	background-color: rgb(27, 29, 35);\n"
"	padding: 3px;\n"
"	border-top-left-radius: 7px;\n"
""
                        "    border-top-right-radius: 7px;\n"
"	font: italic 18pt \"Segoe UI\";\n"
"}\n"
"QHeaderView::section:vertical\n"
"{\n"
"    border: 1px solid rgb(32, 34, 42);\n"
"	background-color: rgb(27, 29, 35);\n"
"	padding: 3px;\n"
"	border-top-left-radius: 7px;\n"
"    border-bottom-left-radius: 7px;\n"
"	font: italic 18pt \"Segoe UI\";\n"
"}")
        self.tableWidget_4.setFrameShape(QFrame.NoFrame)
        self.tableWidget_4.setLineWidth(1)
        self.tableWidget_4.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.tableWidget_4.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.tableWidget_4.setSizeAdjustPolicy(QAbstractScrollArea.AdjustIgnored)
        self.tableWidget_4.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tableWidget_4.setDragEnabled(False)
        self.tableWidget_4.setAlternatingRowColors(False)
        self.tableWidget_4.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tableWidget_4.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableWidget_4.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.tableWidget_4.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.tableWidget_4.setShowGrid(True)
        self.tableWidget_4.setGridStyle(Qt.SolidLine)
        self.tableWidget_4.setSortingEnabled(False)
        self.tableWidget_4.setRowCount(27)
        self.tableWidget_4.horizontalHeader().setVisible(False)
        self.tableWidget_4.horizontalHeader().setCascadingSectionResizes(True)
        self.tableWidget_4.horizontalHeader().setDefaultSectionSize(200)
        self.tableWidget_4.horizontalHeader().setProperty("showSortIndicator", False)
        self.tableWidget_4.horizontalHeader().setStretchLastSection(True)
        self.tableWidget_4.verticalHeader().setVisible(False)
        self.tableWidget_4.verticalHeader().setCascadingSectionResizes(True)
        self.tableWidget_4.verticalHeader().setMinimumSectionSize(25)
        self.tableWidget_4.verticalHeader().setDefaultSectionSize(34)
        self.tableWidget_4.verticalHeader().setHighlightSections(True)
        self.tableWidget_4.verticalHeader().setProperty("showSortIndicator", True)
        self.tableWidget_4.verticalHeader().setStretchLastSection(True)
        self.tableWidget_5 = QTableWidget(self.new_TV)
        if (self.tableWidget_5.columnCount() < 7):
            self.tableWidget_5.setColumnCount(7)
        __qtablewidgetitem332 = QTableWidgetItem()
        self.tableWidget_5.setHorizontalHeaderItem(0, __qtablewidgetitem332)
        __qtablewidgetitem333 = QTableWidgetItem()
        self.tableWidget_5.setHorizontalHeaderItem(1, __qtablewidgetitem333)
        __qtablewidgetitem334 = QTableWidgetItem()
        self.tableWidget_5.setHorizontalHeaderItem(2, __qtablewidgetitem334)
        __qtablewidgetitem335 = QTableWidgetItem()
        self.tableWidget_5.setHorizontalHeaderItem(3, __qtablewidgetitem335)
        __qtablewidgetitem336 = QTableWidgetItem()
        self.tableWidget_5.setHorizontalHeaderItem(4, __qtablewidgetitem336)
        __qtablewidgetitem337 = QTableWidgetItem()
        self.tableWidget_5.setHorizontalHeaderItem(5, __qtablewidgetitem337)
        __qtablewidgetitem338 = QTableWidgetItem()
        self.tableWidget_5.setHorizontalHeaderItem(6, __qtablewidgetitem338)
        if (self.tableWidget_5.rowCount() < 32):
            self.tableWidget_5.setRowCount(32)
        __qtablewidgetitem339 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(0, __qtablewidgetitem339)
        __qtablewidgetitem340 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(1, __qtablewidgetitem340)
        __qtablewidgetitem341 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(2, __qtablewidgetitem341)
        __qtablewidgetitem342 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(3, __qtablewidgetitem342)
        __qtablewidgetitem343 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(4, __qtablewidgetitem343)
        __qtablewidgetitem344 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(5, __qtablewidgetitem344)
        __qtablewidgetitem345 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(6, __qtablewidgetitem345)
        __qtablewidgetitem346 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(7, __qtablewidgetitem346)
        __qtablewidgetitem347 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(8, __qtablewidgetitem347)
        __qtablewidgetitem348 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(9, __qtablewidgetitem348)
        __qtablewidgetitem349 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(10, __qtablewidgetitem349)
        __qtablewidgetitem350 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(11, __qtablewidgetitem350)
        __qtablewidgetitem351 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(12, __qtablewidgetitem351)
        __qtablewidgetitem352 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(13, __qtablewidgetitem352)
        __qtablewidgetitem353 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(14, __qtablewidgetitem353)
        __qtablewidgetitem354 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(15, __qtablewidgetitem354)
        __qtablewidgetitem355 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(16, __qtablewidgetitem355)
        __qtablewidgetitem356 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(17, __qtablewidgetitem356)
        __qtablewidgetitem357 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(18, __qtablewidgetitem357)
        __qtablewidgetitem358 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(19, __qtablewidgetitem358)
        __qtablewidgetitem359 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(20, __qtablewidgetitem359)
        __qtablewidgetitem360 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(21, __qtablewidgetitem360)
        __qtablewidgetitem361 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(22, __qtablewidgetitem361)
        __qtablewidgetitem362 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(23, __qtablewidgetitem362)
        __qtablewidgetitem363 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(24, __qtablewidgetitem363)
        __qtablewidgetitem364 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(25, __qtablewidgetitem364)
        __qtablewidgetitem365 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(26, __qtablewidgetitem365)
        __qtablewidgetitem366 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(27, __qtablewidgetitem366)
        __qtablewidgetitem367 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(28, __qtablewidgetitem367)
        __qtablewidgetitem368 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(29, __qtablewidgetitem368)
        __qtablewidgetitem369 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(30, __qtablewidgetitem369)
        __qtablewidgetitem370 = QTableWidgetItem()
        self.tableWidget_5.setVerticalHeaderItem(31, __qtablewidgetitem370)
        __qtablewidgetitem371 = QTableWidgetItem()
        __qtablewidgetitem371.setFont(font5);
        self.tableWidget_5.setItem(0, 0, __qtablewidgetitem371)
        __qtablewidgetitem372 = QTableWidgetItem()
        __qtablewidgetitem372.setFont(font5);
        self.tableWidget_5.setItem(0, 1, __qtablewidgetitem372)
        __qtablewidgetitem373 = QTableWidgetItem()
        __qtablewidgetitem373.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem373.setFont(font5);
        self.tableWidget_5.setItem(0, 2, __qtablewidgetitem373)
        __qtablewidgetitem374 = QTableWidgetItem()
        __qtablewidgetitem374.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem374.setFont(font5);
        self.tableWidget_5.setItem(0, 3, __qtablewidgetitem374)
        __qtablewidgetitem375 = QTableWidgetItem()
        __qtablewidgetitem375.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem375.setFont(font5);
        self.tableWidget_5.setItem(0, 4, __qtablewidgetitem375)
        __qtablewidgetitem376 = QTableWidgetItem()
        __qtablewidgetitem376.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem376.setFont(font5);
        self.tableWidget_5.setItem(0, 5, __qtablewidgetitem376)
        __qtablewidgetitem377 = QTableWidgetItem()
        __qtablewidgetitem377.setTextAlignment(Qt.AlignCenter);
        __qtablewidgetitem377.setFont(font5);
        self.tableWidget_5.setItem(0, 6, __qtablewidgetitem377)
        self.tableWidget_5.setObjectName(u"tableWidget_5")
        self.tableWidget_5.setGeometry(QRect(930, 10, 901, 951))
        sizePolicy3.setHeightForWidth(self.tableWidget_5.sizePolicy().hasHeightForWidth())
        self.tableWidget_5.setSizePolicy(sizePolicy3)
        palette3 = QPalette()
        palette3.setBrush(QPalette.Active, QPalette.WindowText, brush)
        palette3.setBrush(QPalette.Active, QPalette.Button, brush5)
        palette3.setBrush(QPalette.Active, QPalette.Text, brush)
        palette3.setBrush(QPalette.Active, QPalette.ButtonText, brush)
        palette3.setBrush(QPalette.Active, QPalette.Base, brush5)
        palette3.setBrush(QPalette.Active, QPalette.Window, brush5)
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette3.setBrush(QPalette.Active, QPalette.PlaceholderText, brush)
#endif
        palette3.setBrush(QPalette.Inactive, QPalette.WindowText, brush)
        palette3.setBrush(QPalette.Inactive, QPalette.Button, brush5)
        palette3.setBrush(QPalette.Inactive, QPalette.Text, brush)
        palette3.setBrush(QPalette.Inactive, QPalette.ButtonText, brush)
        palette3.setBrush(QPalette.Inactive, QPalette.Base, brush5)
        palette3.setBrush(QPalette.Inactive, QPalette.Window, brush5)
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette3.setBrush(QPalette.Inactive, QPalette.PlaceholderText, brush)
#endif
        palette3.setBrush(QPalette.Disabled, QPalette.WindowText, brush)
        palette3.setBrush(QPalette.Disabled, QPalette.Button, brush5)
        palette3.setBrush(QPalette.Disabled, QPalette.Text, brush)
        palette3.setBrush(QPalette.Disabled, QPalette.ButtonText, brush)
        palette3.setBrush(QPalette.Disabled, QPalette.Base, brush5)
        palette3.setBrush(QPalette.Disabled, QPalette.Window, brush5)
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette3.setBrush(QPalette.Disabled, QPalette.PlaceholderText, brush)
#endif
        self.tableWidget_5.setPalette(palette3)
        self.tableWidget_5.setFont(font7)
        self.tableWidget_5.setContextMenuPolicy(Qt.DefaultContextMenu)
        self.tableWidget_5.setAutoFillBackground(False)
        self.tableWidget_5.setStyleSheet(u"QTableWidget {	\n"
"	background-color: rgb(39, 44, 54);\n"
"	padding: 10px;\n"
"	border-radius: 5px;\n"
"	gridline-color: gray;\n"
"	border-bottom: 1px solid rgb(44, 49, 60);\n"
"	font: italic 18pt \"Segoe UI\";\n"
"	padding-left: 1px;\n"
"	padding-right: 1px;\n"
"}\n"
"QTableWidget::item{\n"
"	padding-left: 5px;\n"
"	padding-right: 5px;\n"
"}\n"
"QTableWidget::item:selected{\n"
"	background-color: rgb(85, 170, 255);\n"
"}\n"
"QHeaderView::section{\n"
"	Background-color: rgb(39, 44, 54);\n"
"	max-width: 30px;\n"
"	border: 1px solid rgb(44, 49, 60);\n"
"	border-style: none;\n"
"    border-bottom: 1px solid rgb(44, 49, 60);\n"
"    border-right: 1px solid rgb(44, 49, 60);\n"
"}\n"
"QTableWidget::horizontalHeader {	\n"
"	background-color: rgb(81, 255, 0);\n"
"}\n"
"QHeaderView::section:horizontal\n"
"{\n"
"    border: 1px solid rgb(32, 34, 42);\n"
"	background-color: rgb(27, 29, 35);\n"
"	padding: 3px;\n"
"	border-top-left-radius: 7px;\n"
"    border-top-right-radius: 7px;\n"
"	font: italic 18pt \"Segoe UI\";\n"
""
                        "}\n"
"QHeaderView::section:vertical\n"
"{\n"
"    border: 1px solid rgb(32, 34, 42);\n"
"	background-color: rgb(27, 29, 35);\n"
"	padding: 3px;\n"
"	border-top-left-radius: 7px;\n"
"    border-bottom-left-radius: 7px;\n"
"	font: italic 18pt \"Segoe UI\";\n"
"}\n"
"")
        self.tableWidget_5.setFrameShape(QFrame.NoFrame)
        self.tableWidget_5.setLineWidth(1)
        self.tableWidget_5.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.tableWidget_5.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.tableWidget_5.setSizeAdjustPolicy(QAbstractScrollArea.AdjustIgnored)
        self.tableWidget_5.setAutoScroll(True)
        self.tableWidget_5.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tableWidget_5.setDragEnabled(False)
        self.tableWidget_5.setAlternatingRowColors(False)
        self.tableWidget_5.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tableWidget_5.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableWidget_5.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.tableWidget_5.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.tableWidget_5.setShowGrid(True)
        self.tableWidget_5.setGridStyle(Qt.SolidLine)
        self.tableWidget_5.setSortingEnabled(False)
        self.tableWidget_5.setRowCount(32)
        self.tableWidget_5.horizontalHeader().setVisible(False)
        self.tableWidget_5.horizontalHeader().setCascadingSectionResizes(True)
        self.tableWidget_5.horizontalHeader().setDefaultSectionSize(200)
        self.tableWidget_5.horizontalHeader().setProperty("showSortIndicator", False)
        self.tableWidget_5.horizontalHeader().setStretchLastSection(True)
        self.tableWidget_5.verticalHeader().setVisible(False)
        self.tableWidget_5.verticalHeader().setCascadingSectionResizes(True)
        self.tableWidget_5.verticalHeader().setMinimumSectionSize(25)
        self.tableWidget_5.verticalHeader().setDefaultSectionSize(34)
        self.tableWidget_5.verticalHeader().setHighlightSections(True)
        self.tableWidget_5.verticalHeader().setProperty("showSortIndicator", True)
        self.tableWidget_5.verticalHeader().setStretchLastSection(True)
        self.label_2 = QLabel(self.new_TV)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(10, 0, 171, 16))
        self.stackedWidget.addWidget(self.new_TV)

        self.verticalLayout_15.addWidget(self.stackedWidget)


        self.horizontalLayout_4.addWidget(self.pagesContainer)

        self.extraRightBox = QFrame(self.content)
        self.extraRightBox.setObjectName(u"extraRightBox")
        self.extraRightBox.setMinimumSize(QSize(0, 0))
        self.extraRightBox.setMaximumSize(QSize(0, 16777215))
        self.extraRightBox.setFrameShape(QFrame.NoFrame)
        self.extraRightBox.setFrameShadow(QFrame.Raised)
        self.verticalLayout_7 = QVBoxLayout(self.extraRightBox)
        self.verticalLayout_7.setSpacing(0)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.themeSettingsTopDetail = QFrame(self.extraRightBox)
        self.themeSettingsTopDetail.setObjectName(u"themeSettingsTopDetail")
        self.themeSettingsTopDetail.setMaximumSize(QSize(16777215, 3))
        self.themeSettingsTopDetail.setFrameShape(QFrame.NoFrame)
        self.themeSettingsTopDetail.setFrameShadow(QFrame.Raised)

        self.verticalLayout_7.addWidget(self.themeSettingsTopDetail)

        self.contentSettings = QFrame(self.extraRightBox)
        self.contentSettings.setObjectName(u"contentSettings")
        self.contentSettings.setFrameShape(QFrame.NoFrame)
        self.contentSettings.setFrameShadow(QFrame.Raised)
        self.verticalLayout_13 = QVBoxLayout(self.contentSettings)
        self.verticalLayout_13.setSpacing(0)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.verticalLayout_13.setContentsMargins(0, 0, 0, 0)
        self.topMenus = QFrame(self.contentSettings)
        self.topMenus.setObjectName(u"topMenus")
        self.topMenus.setFrameShape(QFrame.NoFrame)
        self.topMenus.setFrameShadow(QFrame.Raised)
        self.verticalLayout_14 = QVBoxLayout(self.topMenus)
        self.verticalLayout_14.setSpacing(0)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.verticalLayout_14.setContentsMargins(0, 0, 0, 0)
        self.btn_message = QPushButton(self.topMenus)
        self.btn_message.setObjectName(u"btn_message")
        sizePolicy.setHeightForWidth(self.btn_message.sizePolicy().hasHeightForWidth())
        self.btn_message.setSizePolicy(sizePolicy)
        self.btn_message.setMinimumSize(QSize(0, 45))
        self.btn_message.setFont(font)
        self.btn_message.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_message.setLayoutDirection(Qt.LeftToRight)
        self.btn_message.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-envelope-open.png);")

        self.verticalLayout_14.addWidget(self.btn_message)

        self.btn_print = QPushButton(self.topMenus)
        self.btn_print.setObjectName(u"btn_print")
        sizePolicy.setHeightForWidth(self.btn_print.sizePolicy().hasHeightForWidth())
        self.btn_print.setSizePolicy(sizePolicy)
        self.btn_print.setMinimumSize(QSize(0, 45))
        self.btn_print.setFont(font)
        self.btn_print.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_print.setLayoutDirection(Qt.LeftToRight)
        self.btn_print.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-print.png);")

        self.verticalLayout_14.addWidget(self.btn_print)

        self.btn_logout = QPushButton(self.topMenus)
        self.btn_logout.setObjectName(u"btn_logout")
        sizePolicy.setHeightForWidth(self.btn_logout.sizePolicy().hasHeightForWidth())
        self.btn_logout.setSizePolicy(sizePolicy)
        self.btn_logout.setMinimumSize(QSize(0, 45))
        self.btn_logout.setFont(font)
        self.btn_logout.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_logout.setLayoutDirection(Qt.LeftToRight)
        self.btn_logout.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-account-logout.png);")

        self.verticalLayout_14.addWidget(self.btn_logout)


        self.verticalLayout_13.addWidget(self.topMenus, 0, Qt.AlignTop)


        self.verticalLayout_7.addWidget(self.contentSettings)


        self.horizontalLayout_4.addWidget(self.extraRightBox)


        self.verticalLayout_6.addWidget(self.content)

        self.bottomBar = QFrame(self.contentBottom)
        self.bottomBar.setObjectName(u"bottomBar")
        self.bottomBar.setMinimumSize(QSize(0, 22))
        self.bottomBar.setMaximumSize(QSize(16777215, 22))
        self.bottomBar.setFrameShape(QFrame.NoFrame)
        self.bottomBar.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_5 = QHBoxLayout(self.bottomBar)
        self.horizontalLayout_5.setSpacing(0)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.creditsLabel = QLabel(self.bottomBar)
        self.creditsLabel.setObjectName(u"creditsLabel")
        self.creditsLabel.setMaximumSize(QSize(16777215, 16))
        font8 = QFont()
        font8.setFamily(u"Segoe UI")
        font8.setBold(False)
        font8.setItalic(False)
        self.creditsLabel.setFont(font8)
        self.creditsLabel.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.horizontalLayout_5.addWidget(self.creditsLabel)

        self.version = QLabel(self.bottomBar)
        self.version.setObjectName(u"version")
        self.version.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.horizontalLayout_5.addWidget(self.version)

        self.frame_size_grip = QFrame(self.bottomBar)
        self.frame_size_grip.setObjectName(u"frame_size_grip")
        self.frame_size_grip.setMinimumSize(QSize(20, 0))
        self.frame_size_grip.setMaximumSize(QSize(20, 16777215))
        self.frame_size_grip.setFrameShape(QFrame.NoFrame)
        self.frame_size_grip.setFrameShadow(QFrame.Raised)

        self.horizontalLayout_5.addWidget(self.frame_size_grip)


        self.verticalLayout_6.addWidget(self.bottomBar)


        self.verticalLayout_2.addWidget(self.contentBottom)


        self.appLayout.addWidget(self.contentBox)


        self.appMargins.addWidget(self.bgApp)

        MainWindow.setCentralWidget(self.styleSheet)

        self.retranslateUi(MainWindow)

        self.stackedWidget.setCurrentIndex(2)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.titleLeftApp.setText(QCoreApplication.translate("MainWindow", u"CIMple", None))
        self.titleLeftDescription.setText(QCoreApplication.translate("MainWindow", u"Real Time / Easy Accessibility", None))
        self.toggleButton.setText(QCoreApplication.translate("MainWindow", u"Hide", None))
        self.btn_home.setText(QCoreApplication.translate("MainWindow", u"Home", None))
        self.btn_new.setText(QCoreApplication.translate("MainWindow", u"PnP) Realtime Status", None))
        self.btn_brower.setText(QCoreApplication.translate("MainWindow", u"Exit", None))
        self.btn_save.setText(QCoreApplication.translate("MainWindow", u"Save", None))
        self.btn_widgets.setText(QCoreApplication.translate("MainWindow", u"Widgets", None))
        self.toggleLeftBox.setText(QCoreApplication.translate("MainWindow", u"Left Box", None))
        self.extraLabel.setText(QCoreApplication.translate("MainWindow", u"Convert to TV", None))
#if QT_CONFIG(tooltip)
        self.extraCloseColumnBtn.setToolTip(QCoreApplication.translate("MainWindow", u"Close left box", None))
#endif // QT_CONFIG(tooltip)
        self.extraCloseColumnBtn.setText("")
        self.btn_share.setText(QCoreApplication.translate("MainWindow", u"Share for all sections", None))
        self.btn_more.setText(QCoreApplication.translate("MainWindow", u"More", None))
        self.btn_adjustment.setText(QCoreApplication.translate("MainWindow", u"Adjustments", None))
        self.textEdit.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-weight:600; color:#ff79c6;\">Purpose of CIMple</span></p>\n"
"<p align=\"center\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#ffffff;\">To control K5DPS's machine status/condition for performance with maximum throughput</span></p>\n"
"<p align=\"center\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\""
                        " color:#ffffff;\">ATK5 DPS License</span></p>\n"
"<p align=\"center\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#bd93f9;\">Created by: Jeongsug Gwag &amp; Sungkuk Song</span></p>\n"
"<p align=\"center\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-weight:600; color:#ff79c6;\">Convert UI</span></p>\n"
"<p align=\"center\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt; color:#ffffff;\">pyside6-uic main.ui &gt; ui_main.py</span></p>\n"
"<p align=\"center\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-weight:600; color:#ff79c6;\">Convert QRC</span></p>\n"
"<p align=\"center\" style=\" margin-top:12"
                        "px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt; color:#ffffff;\">pyside6-rcc resources.qrc -o resources_rc.py</span></p></body></html>", None))
        self.titleRightInfo.setText(QCoreApplication.translate("MainWindow", u"CIMple - Computer Integrated Manufacturing + Line Eagleview", None))
#if QT_CONFIG(tooltip)
        self.settingsTopBtn.setToolTip(QCoreApplication.translate("MainWindow", u"Settings", None))
#endif // QT_CONFIG(tooltip)
        self.settingsTopBtn.setText("")
#if QT_CONFIG(tooltip)
        self.minimizeAppBtn.setToolTip(QCoreApplication.translate("MainWindow", u"Minimize", None))
#endif // QT_CONFIG(tooltip)
        self.minimizeAppBtn.setText("")
#if QT_CONFIG(tooltip)
        self.maximizeRestoreAppBtn.setToolTip(QCoreApplication.translate("MainWindow", u"Maximize", None))
#endif // QT_CONFIG(tooltip)
        self.maximizeRestoreAppBtn.setText("")
#if QT_CONFIG(tooltip)
        self.closeAppBtn.setToolTip(QCoreApplication.translate("MainWindow", u"Close", None))
#endif // QT_CONFIG(tooltip)
        self.closeAppBtn.setText("")
        self.labelBoxBlenderInstalation.setText(QCoreApplication.translate("MainWindow", u"FILE BOX", None))
        self.lineEdit.setText("")
        self.lineEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Type here", None))
        self.pushButton.setText(QCoreApplication.translate("MainWindow", u"Open", None))
        self.labelVersion_3.setText(QCoreApplication.translate("MainWindow", u"Label description", None))
        self.checkBox.setText(QCoreApplication.translate("MainWindow", u"CheckBox", None))
        self.radioButton.setText(QCoreApplication.translate("MainWindow", u"RadioButton", None))
        self.comboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"Test 1", None))
        self.comboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"Test 2", None))
        self.comboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"Test 3", None))

        self.commandLinkButton.setText(QCoreApplication.translate("MainWindow", u"Link Button", None))
        self.commandLinkButton.setDescription(QCoreApplication.translate("MainWindow", u"Link description", None))
        ___qtablewidgetitem = self.tableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", u"0", None));
        ___qtablewidgetitem1 = self.tableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", u"1", None));
        ___qtablewidgetitem2 = self.tableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("MainWindow", u"2", None));
        ___qtablewidgetitem3 = self.tableWidget.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("MainWindow", u"3", None));
        ___qtablewidgetitem4 = self.tableWidget.verticalHeaderItem(0)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("MainWindow", u"New Row", None));
        ___qtablewidgetitem5 = self.tableWidget.verticalHeaderItem(1)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("MainWindow", u"New Row", None));
        ___qtablewidgetitem6 = self.tableWidget.verticalHeaderItem(2)
        ___qtablewidgetitem6.setText(QCoreApplication.translate("MainWindow", u"New Row", None));
        ___qtablewidgetitem7 = self.tableWidget.verticalHeaderItem(3)
        ___qtablewidgetitem7.setText(QCoreApplication.translate("MainWindow", u"New Row", None));
        ___qtablewidgetitem8 = self.tableWidget.verticalHeaderItem(4)
        ___qtablewidgetitem8.setText(QCoreApplication.translate("MainWindow", u"New Row", None));
        ___qtablewidgetitem9 = self.tableWidget.verticalHeaderItem(5)
        ___qtablewidgetitem9.setText(QCoreApplication.translate("MainWindow", u"New Row", None));
        ___qtablewidgetitem10 = self.tableWidget.verticalHeaderItem(6)
        ___qtablewidgetitem10.setText(QCoreApplication.translate("MainWindow", u"New Row", None));
        ___qtablewidgetitem11 = self.tableWidget.verticalHeaderItem(7)
        ___qtablewidgetitem11.setText(QCoreApplication.translate("MainWindow", u"New Row", None));
        ___qtablewidgetitem12 = self.tableWidget.verticalHeaderItem(8)
        ___qtablewidgetitem12.setText(QCoreApplication.translate("MainWindow", u"New Row", None));
        ___qtablewidgetitem13 = self.tableWidget.verticalHeaderItem(9)
        ___qtablewidgetitem13.setText(QCoreApplication.translate("MainWindow", u"New Row", None));
        ___qtablewidgetitem14 = self.tableWidget.verticalHeaderItem(10)
        ___qtablewidgetitem14.setText(QCoreApplication.translate("MainWindow", u"New Row", None));
        ___qtablewidgetitem15 = self.tableWidget.verticalHeaderItem(11)
        ___qtablewidgetitem15.setText(QCoreApplication.translate("MainWindow", u"New Row", None));
        ___qtablewidgetitem16 = self.tableWidget.verticalHeaderItem(12)
        ___qtablewidgetitem16.setText(QCoreApplication.translate("MainWindow", u"New Row", None));
        ___qtablewidgetitem17 = self.tableWidget.verticalHeaderItem(13)
        ___qtablewidgetitem17.setText(QCoreApplication.translate("MainWindow", u"New Row", None));
        ___qtablewidgetitem18 = self.tableWidget.verticalHeaderItem(14)
        ___qtablewidgetitem18.setText(QCoreApplication.translate("MainWindow", u"New Row", None));
        ___qtablewidgetitem19 = self.tableWidget.verticalHeaderItem(15)
        ___qtablewidgetitem19.setText(QCoreApplication.translate("MainWindow", u"New Row", None));

        __sortingEnabled = self.tableWidget.isSortingEnabled()
        self.tableWidget.setSortingEnabled(False)
        ___qtablewidgetitem20 = self.tableWidget.item(0, 0)
        ___qtablewidgetitem20.setText(QCoreApplication.translate("MainWindow", u"Test", None));
        ___qtablewidgetitem21 = self.tableWidget.item(0, 1)
        ___qtablewidgetitem21.setText(QCoreApplication.translate("MainWindow", u"Text", None));
        ___qtablewidgetitem22 = self.tableWidget.item(0, 2)
        ___qtablewidgetitem22.setText(QCoreApplication.translate("MainWindow", u"Cell", None));
        ___qtablewidgetitem23 = self.tableWidget.item(0, 3)
        ___qtablewidgetitem23.setText(QCoreApplication.translate("MainWindow", u"Line", None));
        self.tableWidget.setSortingEnabled(__sortingEnabled)

        ___qtablewidgetitem24 = self.tableWidget_3.horizontalHeaderItem(0)
        ___qtablewidgetitem24.setText(QCoreApplication.translate("MainWindow", u"Status", None));
        ___qtablewidgetitem25 = self.tableWidget_3.horizontalHeaderItem(1)
        ___qtablewidgetitem25.setText(QCoreApplication.translate("MainWindow", u"Code", None));
        ___qtablewidgetitem26 = self.tableWidget_3.horizontalHeaderItem(2)
        ___qtablewidgetitem26.setText(QCoreApplication.translate("MainWindow", u"Customer", None));
        ___qtablewidgetitem27 = self.tableWidget_3.horizontalHeaderItem(3)
        ___qtablewidgetitem27.setText(QCoreApplication.translate("MainWindow", u"Target Device", None));
        ___qtablewidgetitem28 = self.tableWidget_3.horizontalHeaderItem(4)
        ___qtablewidgetitem28.setText(QCoreApplication.translate("MainWindow", u"Lot# / DCC", None));
        ___qtablewidgetitem29 = self.tableWidget_3.horizontalHeaderItem(5)
        ___qtablewidgetitem29.setText(QCoreApplication.translate("MainWindow", u"SM", None));
        ___qtablewidgetitem30 = self.tableWidget_3.horizontalHeaderItem(6)
        ___qtablewidgetitem30.setText(QCoreApplication.translate("MainWindow", u"NPI / HVM", None));
        ___qtablewidgetitem31 = self.tableWidget_3.horizontalHeaderItem(7)
        ___qtablewidgetitem31.setText(QCoreApplication.translate("MainWindow", u"UPH", None));
        ___qtablewidgetitem32 = self.tableWidget_3.horizontalHeaderItem(8)
        ___qtablewidgetitem32.setText(QCoreApplication.translate("MainWindow", u"Flipper", None));
        ___qtablewidgetitem33 = self.tableWidget_3.horizontalHeaderItem(9)
        ___qtablewidgetitem33.setText(QCoreApplication.translate("MainWindow", u"Picker", None));
        ___qtablewidgetitem34 = self.tableWidget_3.horizontalHeaderItem(10)
        ___qtablewidgetitem34.setText(QCoreApplication.translate("MainWindow", u"Wafer Yield", None));
        ___qtablewidgetitem35 = self.tableWidget_3.horizontalHeaderItem(11)
        ___qtablewidgetitem35.setText(QCoreApplication.translate("MainWindow", u"Lot Yield", None));
        ___qtablewidgetitem36 = self.tableWidget_3.horizontalHeaderItem(12)
        ___qtablewidgetitem36.setText(QCoreApplication.translate("MainWindow", u"Reject q'ty", None));
        ___qtablewidgetitem37 = self.tableWidget_3.horizontalHeaderItem(13)
        ___qtablewidgetitem37.setText(QCoreApplication.translate("MainWindow", u"Wafer ID", None));
        ___qtablewidgetitem38 = self.tableWidget_3.horizontalHeaderItem(14)
        ___qtablewidgetitem38.setText(QCoreApplication.translate("MainWindow", u"Curr' Bin", None));
        ___qtablewidgetitem39 = self.tableWidget_3.horizontalHeaderItem(15)
        ___qtablewidgetitem39.setText(QCoreApplication.translate("MainWindow", u"Tape q'ty", None));
        ___qtablewidgetitem40 = self.tableWidget_3.horizontalHeaderItem(16)
        ___qtablewidgetitem40.setText(QCoreApplication.translate("MainWindow", u"Curr' Frame", None));
        ___qtablewidgetitem41 = self.tableWidget_3.horizontalHeaderItem(17)
        ___qtablewidgetitem41.setText(QCoreApplication.translate("MainWindow", u"Auto Suction", None));
        ___qtablewidgetitem42 = self.tableWidget_3.horizontalHeaderItem(18)
        ___qtablewidgetitem42.setText(QCoreApplication.translate("MainWindow", u"Bypass Vision", None));
        ___qtablewidgetitem43 = self.tableWidget_3.horizontalHeaderItem(19)
        ___qtablewidgetitem43.setText(QCoreApplication.translate("MainWindow", u"Bypass Door", None));
        ___qtablewidgetitem44 = self.tableWidget_3.verticalHeaderItem(0)
        ___qtablewidgetitem44.setText(QCoreApplication.translate("MainWindow", u"\"\"", None));
        ___qtablewidgetitem45 = self.tableWidget_3.verticalHeaderItem(1)
        ___qtablewidgetitem45.setText(QCoreApplication.translate("MainWindow", u"#01_MI30", None));
        ___qtablewidgetitem46 = self.tableWidget_3.verticalHeaderItem(2)
        ___qtablewidgetitem46.setText(QCoreApplication.translate("MainWindow", u"#02_MI30", None));
        ___qtablewidgetitem47 = self.tableWidget_3.verticalHeaderItem(3)
        ___qtablewidgetitem47.setText(QCoreApplication.translate("MainWindow", u"#03_MI40_N", None));
        ___qtablewidgetitem48 = self.tableWidget_3.verticalHeaderItem(4)
        ___qtablewidgetitem48.setText(QCoreApplication.translate("MainWindow", u"#04_MI30", None));
        ___qtablewidgetitem49 = self.tableWidget_3.verticalHeaderItem(5)
        ___qtablewidgetitem49.setText(QCoreApplication.translate("MainWindow", u"#05_MI30", None));
        ___qtablewidgetitem50 = self.tableWidget_3.verticalHeaderItem(6)
        ___qtablewidgetitem50.setText(QCoreApplication.translate("MainWindow", u"#06_MI30", None));
        ___qtablewidgetitem51 = self.tableWidget_3.verticalHeaderItem(7)
        ___qtablewidgetitem51.setText(QCoreApplication.translate("MainWindow", u"#07_MI30", None));
        ___qtablewidgetitem52 = self.tableWidget_3.verticalHeaderItem(8)
        ___qtablewidgetitem52.setText(QCoreApplication.translate("MainWindow", u"#08_MI30", None));
        ___qtablewidgetitem53 = self.tableWidget_3.verticalHeaderItem(9)
        ___qtablewidgetitem53.setText(QCoreApplication.translate("MainWindow", u"#09_MI30", None));
        ___qtablewidgetitem54 = self.tableWidget_3.verticalHeaderItem(10)
        ___qtablewidgetitem54.setText(QCoreApplication.translate("MainWindow", u"#10_MI40_N", None));
        ___qtablewidgetitem55 = self.tableWidget_3.verticalHeaderItem(11)
        ___qtablewidgetitem55.setText(QCoreApplication.translate("MainWindow", u"#11_MI30", None));
        ___qtablewidgetitem56 = self.tableWidget_3.verticalHeaderItem(12)
        ___qtablewidgetitem56.setText(QCoreApplication.translate("MainWindow", u"#12_MI30", None));
        ___qtablewidgetitem57 = self.tableWidget_3.verticalHeaderItem(13)
        ___qtablewidgetitem57.setText(QCoreApplication.translate("MainWindow", u"#13_MI30", None));
        ___qtablewidgetitem58 = self.tableWidget_3.verticalHeaderItem(14)
        ___qtablewidgetitem58.setText(QCoreApplication.translate("MainWindow", u"#14_MI30", None));
        ___qtablewidgetitem59 = self.tableWidget_3.verticalHeaderItem(15)
        ___qtablewidgetitem59.setText(QCoreApplication.translate("MainWindow", u"#15_MI30", None));
        ___qtablewidgetitem60 = self.tableWidget_3.verticalHeaderItem(16)
        ___qtablewidgetitem60.setText(QCoreApplication.translate("MainWindow", u"#16_MI30", None));
        ___qtablewidgetitem61 = self.tableWidget_3.verticalHeaderItem(17)
        ___qtablewidgetitem61.setText(QCoreApplication.translate("MainWindow", u"#17_MI30", None));
        ___qtablewidgetitem62 = self.tableWidget_3.verticalHeaderItem(18)
        ___qtablewidgetitem62.setText(QCoreApplication.translate("MainWindow", u"#18_MI30", None));
        ___qtablewidgetitem63 = self.tableWidget_3.verticalHeaderItem(19)
        ___qtablewidgetitem63.setText(QCoreApplication.translate("MainWindow", u"#19_MI30", None));
        ___qtablewidgetitem64 = self.tableWidget_3.verticalHeaderItem(20)
        ___qtablewidgetitem64.setText(QCoreApplication.translate("MainWindow", u"#20_MI30", None));
        ___qtablewidgetitem65 = self.tableWidget_3.verticalHeaderItem(21)
        ___qtablewidgetitem65.setText(QCoreApplication.translate("MainWindow", u"#21_MI30", None));
        ___qtablewidgetitem66 = self.tableWidget_3.verticalHeaderItem(22)
        ___qtablewidgetitem66.setText(QCoreApplication.translate("MainWindow", u"#22_MI30", None));
        ___qtablewidgetitem67 = self.tableWidget_3.verticalHeaderItem(23)
        ___qtablewidgetitem67.setText(QCoreApplication.translate("MainWindow", u"#23_MI30", None));
        ___qtablewidgetitem68 = self.tableWidget_3.verticalHeaderItem(24)
        ___qtablewidgetitem68.setText(QCoreApplication.translate("MainWindow", u"#24_MI30", None));
        ___qtablewidgetitem69 = self.tableWidget_3.verticalHeaderItem(25)
        ___qtablewidgetitem69.setText(QCoreApplication.translate("MainWindow", u"#25_MI30", None));
        ___qtablewidgetitem70 = self.tableWidget_3.verticalHeaderItem(26)
        ___qtablewidgetitem70.setText(QCoreApplication.translate("MainWindow", u"#26_MI30", None));
        ___qtablewidgetitem71 = self.tableWidget_3.verticalHeaderItem(27)
        ___qtablewidgetitem71.setText(QCoreApplication.translate("MainWindow", u"#27_MI30", None));
        ___qtablewidgetitem72 = self.tableWidget_3.verticalHeaderItem(28)
        ___qtablewidgetitem72.setText(QCoreApplication.translate("MainWindow", u"#28_MI30", None));
        ___qtablewidgetitem73 = self.tableWidget_3.verticalHeaderItem(29)
        ___qtablewidgetitem73.setText(QCoreApplication.translate("MainWindow", u"#29_MI30", None));
        ___qtablewidgetitem74 = self.tableWidget_3.verticalHeaderItem(30)
        ___qtablewidgetitem74.setText(QCoreApplication.translate("MainWindow", u"#30_MI30", None));
        ___qtablewidgetitem75 = self.tableWidget_3.verticalHeaderItem(31)
        ___qtablewidgetitem75.setText(QCoreApplication.translate("MainWindow", u"#31_MI30", None));
        ___qtablewidgetitem76 = self.tableWidget_3.verticalHeaderItem(32)
        ___qtablewidgetitem76.setText(QCoreApplication.translate("MainWindow", u"#32_MI30", None));
        ___qtablewidgetitem77 = self.tableWidget_3.verticalHeaderItem(33)
        ___qtablewidgetitem77.setText(QCoreApplication.translate("MainWindow", u"#33_MI30", None));
        ___qtablewidgetitem78 = self.tableWidget_3.verticalHeaderItem(34)
        ___qtablewidgetitem78.setText(QCoreApplication.translate("MainWindow", u"#34_MI30", None));
        ___qtablewidgetitem79 = self.tableWidget_3.verticalHeaderItem(35)
        ___qtablewidgetitem79.setText(QCoreApplication.translate("MainWindow", u"#35_MI30", None));
        ___qtablewidgetitem80 = self.tableWidget_3.verticalHeaderItem(36)
        ___qtablewidgetitem80.setText(QCoreApplication.translate("MainWindow", u"#36_MI30", None));
        ___qtablewidgetitem81 = self.tableWidget_3.verticalHeaderItem(37)
        ___qtablewidgetitem81.setText(QCoreApplication.translate("MainWindow", u"#37_MI40_N", None));
        ___qtablewidgetitem82 = self.tableWidget_3.verticalHeaderItem(38)
        ___qtablewidgetitem82.setText(QCoreApplication.translate("MainWindow", u"#38_MI40_N", None));
        ___qtablewidgetitem83 = self.tableWidget_3.verticalHeaderItem(39)
        ___qtablewidgetitem83.setText(QCoreApplication.translate("MainWindow", u"#39_MI40_N", None));
        ___qtablewidgetitem84 = self.tableWidget_3.verticalHeaderItem(40)
        ___qtablewidgetitem84.setText(QCoreApplication.translate("MainWindow", u"#40_MI40_N", None));
        ___qtablewidgetitem85 = self.tableWidget_3.verticalHeaderItem(41)
        ___qtablewidgetitem85.setText(QCoreApplication.translate("MainWindow", u"#41_MI40_N", None));
        ___qtablewidgetitem86 = self.tableWidget_3.verticalHeaderItem(42)
        ___qtablewidgetitem86.setText(QCoreApplication.translate("MainWindow", u"#42_MI40_N", None));
        ___qtablewidgetitem87 = self.tableWidget_3.verticalHeaderItem(43)
        ___qtablewidgetitem87.setText(QCoreApplication.translate("MainWindow", u"#43_MI40_N", None));
        ___qtablewidgetitem88 = self.tableWidget_3.verticalHeaderItem(44)
        ___qtablewidgetitem88.setText(QCoreApplication.translate("MainWindow", u"#44_MI40_N", None));
        ___qtablewidgetitem89 = self.tableWidget_3.verticalHeaderItem(45)
        ___qtablewidgetitem89.setText(QCoreApplication.translate("MainWindow", u"#45_MI40_N", None));
        ___qtablewidgetitem90 = self.tableWidget_3.verticalHeaderItem(46)
        ___qtablewidgetitem90.setText(QCoreApplication.translate("MainWindow", u"#46_MI40_N", None));
        ___qtablewidgetitem91 = self.tableWidget_3.verticalHeaderItem(47)
        ___qtablewidgetitem91.setText(QCoreApplication.translate("MainWindow", u"#47_MI40_N", None));
        ___qtablewidgetitem92 = self.tableWidget_3.verticalHeaderItem(48)
        ___qtablewidgetitem92.setText(QCoreApplication.translate("MainWindow", u"#48_MI40_N", None));

        __sortingEnabled1 = self.tableWidget_3.isSortingEnabled()
        self.tableWidget_3.setSortingEnabled(False)
        ___qtablewidgetitem93 = self.tableWidget_3.item(0, 0)
        ___qtablewidgetitem93.setText(QCoreApplication.translate("MainWindow", u"-", None));
        ___qtablewidgetitem94 = self.tableWidget_3.item(0, 2)
        ___qtablewidgetitem94.setText(QCoreApplication.translate("MainWindow", u"-", None));
        ___qtablewidgetitem95 = self.tableWidget_3.item(0, 3)
        ___qtablewidgetitem95.setText(QCoreApplication.translate("MainWindow", u"-", None));
        ___qtablewidgetitem96 = self.tableWidget_3.item(0, 4)
        ___qtablewidgetitem96.setText(QCoreApplication.translate("MainWindow", u"-", None));
        ___qtablewidgetitem97 = self.tableWidget_3.item(0, 5)
        ___qtablewidgetitem97.setText(QCoreApplication.translate("MainWindow", u"-", None));
        ___qtablewidgetitem98 = self.tableWidget_3.item(0, 7)
        ___qtablewidgetitem98.setText(QCoreApplication.translate("MainWindow", u"T&R UPH", None));
        ___qtablewidgetitem99 = self.tableWidget_3.item(0, 8)
        ___qtablewidgetitem99.setText(QCoreApplication.translate("MainWindow", u"Q'ty", None));
        ___qtablewidgetitem100 = self.tableWidget_3.item(0, 9)
        ___qtablewidgetitem100.setText(QCoreApplication.translate("MainWindow", u"Q'ty", None));
        ___qtablewidgetitem101 = self.tableWidget_3.item(0, 10)
        ___qtablewidgetitem101.setText(QCoreApplication.translate("MainWindow", u"%", None));
        ___qtablewidgetitem102 = self.tableWidget_3.item(0, 11)
        ___qtablewidgetitem102.setText(QCoreApplication.translate("MainWindow", u"%", None));
        ___qtablewidgetitem103 = self.tableWidget_3.item(0, 12)
        ___qtablewidgetitem103.setText(QCoreApplication.translate("MainWindow", u"Q'ty", None));
        ___qtablewidgetitem104 = self.tableWidget_3.item(0, 13)
        ___qtablewidgetitem104.setText(QCoreApplication.translate("MainWindow", u"-", None));
        ___qtablewidgetitem105 = self.tableWidget_3.item(0, 14)
        ___qtablewidgetitem105.setText(QCoreApplication.translate("MainWindow", u"-", None));
        ___qtablewidgetitem106 = self.tableWidget_3.item(0, 15)
        ___qtablewidgetitem106.setText(QCoreApplication.translate("MainWindow", u"-", None));
        ___qtablewidgetitem107 = self.tableWidget_3.item(0, 16)
        ___qtablewidgetitem107.setText(QCoreApplication.translate("MainWindow", u"6/8/12 Inch", None));
        ___qtablewidgetitem108 = self.tableWidget_3.item(0, 17)
        ___qtablewidgetitem108.setText(QCoreApplication.translate("MainWindow", u"On/Off", None));
        ___qtablewidgetitem109 = self.tableWidget_3.item(0, 18)
        ___qtablewidgetitem109.setText(QCoreApplication.translate("MainWindow", u"On/Off", None));
        ___qtablewidgetitem110 = self.tableWidget_3.item(0, 19)
        ___qtablewidgetitem110.setText(QCoreApplication.translate("MainWindow", u"Open/Closed", None));
        self.tableWidget_3.setSortingEnabled(__sortingEnabled1)

        self.label.setText(QCoreApplication.translate("MainWindow", u"* Updating Frequency : 1min", None))
        ___qtablewidgetitem111 = self.tableWidget_4.horizontalHeaderItem(0)
        ___qtablewidgetitem111.setText(QCoreApplication.translate("MainWindow", u"Customer", None));
        ___qtablewidgetitem112 = self.tableWidget_4.horizontalHeaderItem(1)
        ___qtablewidgetitem112.setText(QCoreApplication.translate("MainWindow", u"Target Device", None));
        ___qtablewidgetitem113 = self.tableWidget_4.horizontalHeaderItem(2)
        ___qtablewidgetitem113.setText(QCoreApplication.translate("MainWindow", u"UPH", None));
        ___qtablewidgetitem114 = self.tableWidget_4.horizontalHeaderItem(3)
        ___qtablewidgetitem114.setText(QCoreApplication.translate("MainWindow", u"F / P", None));
        ___qtablewidgetitem115 = self.tableWidget_4.horizontalHeaderItem(4)
        ___qtablewidgetitem115.setText(QCoreApplication.translate("MainWindow", u"Auto", None));
        ___qtablewidgetitem116 = self.tableWidget_4.horizontalHeaderItem(5)
        ___qtablewidgetitem116.setText(QCoreApplication.translate("MainWindow", u"Bypass", None));
        ___qtablewidgetitem117 = self.tableWidget_4.horizontalHeaderItem(6)
        ___qtablewidgetitem117.setText(QCoreApplication.translate("MainWindow", u"Bypass", None));
        ___qtablewidgetitem118 = self.tableWidget_4.verticalHeaderItem(0)
        ___qtablewidgetitem118.setText(QCoreApplication.translate("MainWindow", u"\"\"", None));
        ___qtablewidgetitem119 = self.tableWidget_4.verticalHeaderItem(1)
        ___qtablewidgetitem119.setText(QCoreApplication.translate("MainWindow", u"#1", None));
        ___qtablewidgetitem120 = self.tableWidget_4.verticalHeaderItem(2)
        ___qtablewidgetitem120.setText(QCoreApplication.translate("MainWindow", u"#2", None));
        ___qtablewidgetitem121 = self.tableWidget_4.verticalHeaderItem(3)
        ___qtablewidgetitem121.setText(QCoreApplication.translate("MainWindow", u"#3", None));
        ___qtablewidgetitem122 = self.tableWidget_4.verticalHeaderItem(4)
        ___qtablewidgetitem122.setText(QCoreApplication.translate("MainWindow", u"#4", None));
        ___qtablewidgetitem123 = self.tableWidget_4.verticalHeaderItem(5)
        ___qtablewidgetitem123.setText(QCoreApplication.translate("MainWindow", u"#5", None));
        ___qtablewidgetitem124 = self.tableWidget_4.verticalHeaderItem(6)
        ___qtablewidgetitem124.setText(QCoreApplication.translate("MainWindow", u"#6", None));
        ___qtablewidgetitem125 = self.tableWidget_4.verticalHeaderItem(7)
        ___qtablewidgetitem125.setText(QCoreApplication.translate("MainWindow", u"#7", None));
        ___qtablewidgetitem126 = self.tableWidget_4.verticalHeaderItem(8)
        ___qtablewidgetitem126.setText(QCoreApplication.translate("MainWindow", u"#8", None));
        ___qtablewidgetitem127 = self.tableWidget_4.verticalHeaderItem(9)
        ___qtablewidgetitem127.setText(QCoreApplication.translate("MainWindow", u"#9", None));
        ___qtablewidgetitem128 = self.tableWidget_4.verticalHeaderItem(10)
        ___qtablewidgetitem128.setText(QCoreApplication.translate("MainWindow", u"#10", None));
        ___qtablewidgetitem129 = self.tableWidget_4.verticalHeaderItem(11)
        ___qtablewidgetitem129.setText(QCoreApplication.translate("MainWindow", u"#11", None));
        ___qtablewidgetitem130 = self.tableWidget_4.verticalHeaderItem(12)
        ___qtablewidgetitem130.setText(QCoreApplication.translate("MainWindow", u"#12", None));
        ___qtablewidgetitem131 = self.tableWidget_4.verticalHeaderItem(13)
        ___qtablewidgetitem131.setText(QCoreApplication.translate("MainWindow", u"#13", None));
        ___qtablewidgetitem132 = self.tableWidget_4.verticalHeaderItem(14)
        ___qtablewidgetitem132.setText(QCoreApplication.translate("MainWindow", u"#14", None));
        ___qtablewidgetitem133 = self.tableWidget_4.verticalHeaderItem(15)
        ___qtablewidgetitem133.setText(QCoreApplication.translate("MainWindow", u"#15", None));
        ___qtablewidgetitem134 = self.tableWidget_4.verticalHeaderItem(16)
        ___qtablewidgetitem134.setText(QCoreApplication.translate("MainWindow", u"#16", None));
        ___qtablewidgetitem135 = self.tableWidget_4.verticalHeaderItem(17)
        ___qtablewidgetitem135.setText(QCoreApplication.translate("MainWindow", u"#17", None));
        ___qtablewidgetitem136 = self.tableWidget_4.verticalHeaderItem(18)
        ___qtablewidgetitem136.setText(QCoreApplication.translate("MainWindow", u"#18", None));
        ___qtablewidgetitem137 = self.tableWidget_4.verticalHeaderItem(19)
        ___qtablewidgetitem137.setText(QCoreApplication.translate("MainWindow", u"#19", None));
        ___qtablewidgetitem138 = self.tableWidget_4.verticalHeaderItem(20)
        ___qtablewidgetitem138.setText(QCoreApplication.translate("MainWindow", u"#20", None));
        ___qtablewidgetitem139 = self.tableWidget_4.verticalHeaderItem(21)
        ___qtablewidgetitem139.setText(QCoreApplication.translate("MainWindow", u"#21", None));
        ___qtablewidgetitem140 = self.tableWidget_4.verticalHeaderItem(22)
        ___qtablewidgetitem140.setText(QCoreApplication.translate("MainWindow", u"#22", None));
        ___qtablewidgetitem141 = self.tableWidget_4.verticalHeaderItem(23)
        ___qtablewidgetitem141.setText(QCoreApplication.translate("MainWindow", u"#23", None));
        ___qtablewidgetitem142 = self.tableWidget_4.verticalHeaderItem(24)
        ___qtablewidgetitem142.setText(QCoreApplication.translate("MainWindow", u"#24", None));
        ___qtablewidgetitem143 = self.tableWidget_4.verticalHeaderItem(25)
        ___qtablewidgetitem143.setText(QCoreApplication.translate("MainWindow", u"#25", None));

        __sortingEnabled2 = self.tableWidget_4.isSortingEnabled()
        self.tableWidget_4.setSortingEnabled(False)
        ___qtablewidgetitem144 = self.tableWidget_4.item(0, 0)
        ___qtablewidgetitem144.setText(QCoreApplication.translate("MainWindow", u"-", None));
        ___qtablewidgetitem145 = self.tableWidget_4.item(0, 1)
        ___qtablewidgetitem145.setText(QCoreApplication.translate("MainWindow", u"-", None));
        ___qtablewidgetitem146 = self.tableWidget_4.item(0, 2)
        ___qtablewidgetitem146.setText(QCoreApplication.translate("MainWindow", u"T&R", None));
        ___qtablewidgetitem147 = self.tableWidget_4.item(0, 3)
        ___qtablewidgetitem147.setText(QCoreApplication.translate("MainWindow", u"Q'ty", None));
        ___qtablewidgetitem148 = self.tableWidget_4.item(0, 4)
        ___qtablewidgetitem148.setText(QCoreApplication.translate("MainWindow", u"Suction", None));
        ___qtablewidgetitem149 = self.tableWidget_4.item(0, 5)
        ___qtablewidgetitem149.setText(QCoreApplication.translate("MainWindow", u"Vision", None));
        ___qtablewidgetitem150 = self.tableWidget_4.item(0, 6)
        ___qtablewidgetitem150.setText(QCoreApplication.translate("MainWindow", u"Door", None));
        self.tableWidget_4.setSortingEnabled(__sortingEnabled2)

        ___qtablewidgetitem151 = self.tableWidget_5.horizontalHeaderItem(0)
        ___qtablewidgetitem151.setText(QCoreApplication.translate("MainWindow", u"Customer", None));
        ___qtablewidgetitem152 = self.tableWidget_5.horizontalHeaderItem(1)
        ___qtablewidgetitem152.setText(QCoreApplication.translate("MainWindow", u"Target Device", None));
        ___qtablewidgetitem153 = self.tableWidget_5.horizontalHeaderItem(2)
        ___qtablewidgetitem153.setText(QCoreApplication.translate("MainWindow", u"UPH", None));
        ___qtablewidgetitem154 = self.tableWidget_5.horizontalHeaderItem(3)
        ___qtablewidgetitem154.setText(QCoreApplication.translate("MainWindow", u"F / P", None));
        ___qtablewidgetitem155 = self.tableWidget_5.horizontalHeaderItem(4)
        ___qtablewidgetitem155.setText(QCoreApplication.translate("MainWindow", u"Auto", None));
        ___qtablewidgetitem156 = self.tableWidget_5.horizontalHeaderItem(5)
        ___qtablewidgetitem156.setText(QCoreApplication.translate("MainWindow", u"Bypass", None));
        ___qtablewidgetitem157 = self.tableWidget_5.horizontalHeaderItem(6)
        ___qtablewidgetitem157.setText(QCoreApplication.translate("MainWindow", u"Bypass", None));
        ___qtablewidgetitem158 = self.tableWidget_5.verticalHeaderItem(0)
        ___qtablewidgetitem158.setText(QCoreApplication.translate("MainWindow", u"\"\"", None));
        ___qtablewidgetitem159 = self.tableWidget_5.verticalHeaderItem(1)
        ___qtablewidgetitem159.setText(QCoreApplication.translate("MainWindow", u"#26", None));
        ___qtablewidgetitem160 = self.tableWidget_5.verticalHeaderItem(2)
        ___qtablewidgetitem160.setText(QCoreApplication.translate("MainWindow", u"#27", None));
        ___qtablewidgetitem161 = self.tableWidget_5.verticalHeaderItem(3)
        ___qtablewidgetitem161.setText(QCoreApplication.translate("MainWindow", u"#28", None));
        ___qtablewidgetitem162 = self.tableWidget_5.verticalHeaderItem(4)
        ___qtablewidgetitem162.setText(QCoreApplication.translate("MainWindow", u"#29", None));
        ___qtablewidgetitem163 = self.tableWidget_5.verticalHeaderItem(5)
        ___qtablewidgetitem163.setText(QCoreApplication.translate("MainWindow", u"#30", None));
        ___qtablewidgetitem164 = self.tableWidget_5.verticalHeaderItem(6)
        ___qtablewidgetitem164.setText(QCoreApplication.translate("MainWindow", u"#31", None));
        ___qtablewidgetitem165 = self.tableWidget_5.verticalHeaderItem(7)
        ___qtablewidgetitem165.setText(QCoreApplication.translate("MainWindow", u"#32", None));
        ___qtablewidgetitem166 = self.tableWidget_5.verticalHeaderItem(8)
        ___qtablewidgetitem166.setText(QCoreApplication.translate("MainWindow", u"#33", None));
        ___qtablewidgetitem167 = self.tableWidget_5.verticalHeaderItem(9)
        ___qtablewidgetitem167.setText(QCoreApplication.translate("MainWindow", u"#34", None));
        ___qtablewidgetitem168 = self.tableWidget_5.verticalHeaderItem(10)
        ___qtablewidgetitem168.setText(QCoreApplication.translate("MainWindow", u"#35", None));
        ___qtablewidgetitem169 = self.tableWidget_5.verticalHeaderItem(11)
        ___qtablewidgetitem169.setText(QCoreApplication.translate("MainWindow", u"#36", None));
        ___qtablewidgetitem170 = self.tableWidget_5.verticalHeaderItem(12)
        ___qtablewidgetitem170.setText(QCoreApplication.translate("MainWindow", u"#37", None));
        ___qtablewidgetitem171 = self.tableWidget_5.verticalHeaderItem(13)
        ___qtablewidgetitem171.setText(QCoreApplication.translate("MainWindow", u"#38", None));
        ___qtablewidgetitem172 = self.tableWidget_5.verticalHeaderItem(14)
        ___qtablewidgetitem172.setText(QCoreApplication.translate("MainWindow", u"#39", None));
        ___qtablewidgetitem173 = self.tableWidget_5.verticalHeaderItem(15)
        ___qtablewidgetitem173.setText(QCoreApplication.translate("MainWindow", u"#40", None));
        ___qtablewidgetitem174 = self.tableWidget_5.verticalHeaderItem(16)
        ___qtablewidgetitem174.setText(QCoreApplication.translate("MainWindow", u"#41", None));
        ___qtablewidgetitem175 = self.tableWidget_5.verticalHeaderItem(17)
        ___qtablewidgetitem175.setText(QCoreApplication.translate("MainWindow", u"#42", None));
        ___qtablewidgetitem176 = self.tableWidget_5.verticalHeaderItem(18)
        ___qtablewidgetitem176.setText(QCoreApplication.translate("MainWindow", u"#43", None));
        ___qtablewidgetitem177 = self.tableWidget_5.verticalHeaderItem(19)
        ___qtablewidgetitem177.setText(QCoreApplication.translate("MainWindow", u"#44", None));
        ___qtablewidgetitem178 = self.tableWidget_5.verticalHeaderItem(20)
        ___qtablewidgetitem178.setText(QCoreApplication.translate("MainWindow", u"#45", None));
        ___qtablewidgetitem179 = self.tableWidget_5.verticalHeaderItem(21)
        ___qtablewidgetitem179.setText(QCoreApplication.translate("MainWindow", u"#46", None));
        ___qtablewidgetitem180 = self.tableWidget_5.verticalHeaderItem(22)
        ___qtablewidgetitem180.setText(QCoreApplication.translate("MainWindow", u"#47", None));
        ___qtablewidgetitem181 = self.tableWidget_5.verticalHeaderItem(23)
        ___qtablewidgetitem181.setText(QCoreApplication.translate("MainWindow", u"#48", None));

        __sortingEnabled3 = self.tableWidget_5.isSortingEnabled()
        self.tableWidget_5.setSortingEnabled(False)
        ___qtablewidgetitem182 = self.tableWidget_5.item(0, 0)
        ___qtablewidgetitem182.setText(QCoreApplication.translate("MainWindow", u"-", None));
        ___qtablewidgetitem183 = self.tableWidget_5.item(0, 1)
        ___qtablewidgetitem183.setText(QCoreApplication.translate("MainWindow", u"-", None));
        ___qtablewidgetitem184 = self.tableWidget_5.item(0, 2)
        ___qtablewidgetitem184.setText(QCoreApplication.translate("MainWindow", u"T&R", None));
        ___qtablewidgetitem185 = self.tableWidget_5.item(0, 3)
        ___qtablewidgetitem185.setText(QCoreApplication.translate("MainWindow", u"Q'ty", None));
        ___qtablewidgetitem186 = self.tableWidget_5.item(0, 4)
        ___qtablewidgetitem186.setText(QCoreApplication.translate("MainWindow", u"Suction", None));
        ___qtablewidgetitem187 = self.tableWidget_5.item(0, 5)
        ___qtablewidgetitem187.setText(QCoreApplication.translate("MainWindow", u"Vision", None));
        ___qtablewidgetitem188 = self.tableWidget_5.item(0, 6)
        ___qtablewidgetitem188.setText(QCoreApplication.translate("MainWindow", u"Door", None));
        self.tableWidget_5.setSortingEnabled(__sortingEnabled3)

        self.label_2.setText(QCoreApplication.translate("MainWindow", u"* Updating Frequency : 1min", None))
        self.btn_message.setText(QCoreApplication.translate("MainWindow", u"Find big meaningful projects", None))
        self.btn_print.setText(QCoreApplication.translate("MainWindow", u"Keep sense of purpose", None))
        self.btn_logout.setText(QCoreApplication.translate("MainWindow", u"Let's face it", None))
        self.creditsLabel.setText(QCoreApplication.translate("MainWindow", u"By: Jeongsug Gwag & Sungkuk Song", None))
        self.version.setText(QCoreApplication.translate("MainWindow", u"v1.0.0", None))
    # retranslateUi

