MI30 = ''
MI40 = ''
STI = ''
bump_position = ''
pin1_frame = ''
target_pin1_carrier = ''


def process():
    global frame_orientation
    global map_orientation
    
    if machine == '':
        frame_orientation = ''
        map_orientation = ''

    elif machine == 'MI30':
        #MI30_Down일 경우
        if bump_position == 'Down' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Top Left':
            frame_orientation = '0'
            map_orientation = '180'
        elif bump_position == 'Down' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Top Left':
            frame_orientation = '90'
            map_orientation = '270/-90'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Top Left':
            frame_orientation = '180'
            map_orientation = '0'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Top Left':
            frame_orientation = '270'
            map_orientation = '90'

        elif bump_position == 'Down' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Top Right':
            frame_orientation = '0'
            map_orientation = '180'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Top Right':
            frame_orientation = '90'
            map_orientation = '270/-90'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Top Right':
            frame_orientation = '180'
            map_orientation = '0'
        elif bump_position == 'Down' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Top Right':
            frame_orientation = '270'
            map_orientation = '90'

        elif bump_position == 'Down' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '0'
            map_orientation = '180'
        elif bump_position == 'Down' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '90'
            map_orientation = '270/-90'
        elif bump_position == 'Down' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '180'
            map_orientation = '0'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '270'
            map_orientation = '90'

        elif bump_position == 'Down' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '0'
            map_orientation = '180'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '90'
            map_orientation = '270/-90'
        elif bump_position == 'Down' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '180'
            map_orientation = '0'
        elif bump_position == 'Down' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '270'
            map_orientation = '90'

        #MI30_Up일 경우
        elif bump_position == 'Up' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Top Left':
            frame_orientation = '270'
            map_orientation = '90'
        elif bump_position == 'Up' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Top Left':
            frame_orientation = '0'
            map_orientation = '180'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Top Left':
            frame_orientation = '90'
            map_orientation = '270/-90'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Top Left':
            frame_orientation = '180'
            map_orientation = '0'

        elif bump_position == 'Up' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Top Right':
            frame_orientation = '270'
            map_orientation = '90'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Top Right':
            frame_orientation = '0'
            map_orientation = '180'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Top Right':
            frame_orientation = '90'
            map_orientation = '270/-90'
        elif bump_position == 'Up' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Top Right':
            frame_orientation = '180'
            map_orientation = '0'

        elif bump_position == 'Up' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '270'
            map_orientation = '90'
        elif bump_position == 'Up' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '0'
            map_orientation = '180'
        elif bump_position == 'Up' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '90'
            map_orientation = '270/-90'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '180'
            map_orientation = '0'

        elif bump_position == 'Up' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '270'
            map_orientation = '90'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '0'
            map_orientation = '180'
        elif bump_position == 'Up' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '90'
            map_orientation = '270/-90'
        elif bump_position == 'Up' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '180'
            map_orientation = '0'

        elif bump_position == '' or pin1_frame == '' or target_pin1_carrier == '':
            frame_orientation = ''
            map_orientation = ''

    elif machine == 'MI40':

        #MI40_Down일 경우
        if bump_position == 'Down' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Top Left':
            frame_orientation = '180'
            map_orientation = '0'
        elif bump_position == 'Down' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Top Left':
            frame_orientation = '270'
            map_orientation = '90'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Top Left':
            frame_orientation = '0'
            map_orientation = '180'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Top Left':
            frame_orientation = '90'
            map_orientation = '270/-90'

        elif bump_position == 'Down' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Top Right':
            frame_orientation = '180'
            map_orientation = '0'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Top Right':
            frame_orientation = '270'
            map_orientation = '90'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Top Right':
            frame_orientation = '0'
            map_orientation = '180'
        elif bump_position == 'Down' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Top Right':
            frame_orientation = '90'
            map_orientation = '270/-90'

        elif bump_position == 'Down' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '180'
            map_orientation = '0'
        elif bump_position == 'Down' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '270'
            map_orientation = '90'
        elif bump_position == 'Down' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '0'
            map_orientation = '180'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '90'
            map_orientation = '270/-90'

        elif bump_position == 'Down' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '180'
            map_orientation = '0'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '270'
            map_orientation = '90'
        elif bump_position == 'Down' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '0'
            map_orientation = '180'
        elif bump_position == 'Down' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '90'
            map_orientation = '270/-90'

        #MI40_Up일 경우
        elif bump_position == 'Up' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Top Left':
            frame_orientation = '90'
            map_orientation = '270/-90'
        elif bump_position == 'Up' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Top Left':
            frame_orientation = '180'
            map_orientation = '0'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Top Left':
            frame_orientation = '270'
            map_orientation = '90'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Top Left':
            frame_orientation = '0'
            map_orientation = '180'

        elif bump_position == 'Up' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Top Right':
            frame_orientation = '90'
            map_orientation = '270/-90'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Top Right':
            frame_orientation = '180'
            map_orientation = '0'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Top Right':
            frame_orientation = '270'
            map_orientation = '90'
        elif bump_position == 'Up' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Top Right':
            frame_orientation = '0'
            map_orientation = '180'

        elif bump_position == 'Up' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '90'
            map_orientation = '270/-90'
        elif bump_position == 'Up' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '180'
            map_orientation = '0'
        elif bump_position == 'Up' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '270'
            map_orientation = '90'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '0'
            map_orientation = '180'

        elif bump_position == 'Up' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '90'
            map_orientation = '270/-90'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '180'
            map_orientation = '0'
        elif bump_position == 'Up' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '270'
            map_orientation = '90'
        elif bump_position == 'Up' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '0'
            map_orientation = '180'

        elif bump_position == '' or pin1_frame == '' or target_pin1_carrier == '':
            frame_orientation = ''
            map_orientation = ''
    
    elif machine == 'STI':
        #STI_Down일 경우
        if bump_position == 'Down' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Top Left':
            frame_orientation = '90'
            map_orientation = '180'
        elif bump_position == 'Down' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Top Left':
            frame_orientation = '180'
            map_orientation = '270/-90'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Top Left':
            frame_orientation = '270'
            map_orientation = '0'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Top Left':
            frame_orientation = '0'
            map_orientation = '90'

        elif bump_position == 'Down' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Top Right':
            frame_orientation = '90'
            map_orientation = '180'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Top Right':
            frame_orientation = '180'
            map_orientation = '270/-90'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Top Right':
            frame_orientation = '270'
            map_orientation = '0'
        elif bump_position == 'Down' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Top Right':
            frame_orientation = '0'
            map_orientation = '90'

        elif bump_position == 'Down' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '90'
            map_orientation = '180'
        elif bump_position == 'Down' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '180'
            map_orientation = '270/-90'
        elif bump_position == 'Down' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '270'
            map_orientation = '0'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '0'
            map_orientation = '90'

        elif bump_position == 'Down' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '90'
            map_orientation = '180'
        elif bump_position == 'Down' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '180'
            map_orientation = '270/-90'
        elif bump_position == 'Down' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '270'
            map_orientation = '0'
        elif bump_position == 'Down' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '0'
            map_orientation = '90'

        #STI_Up일 경우
        elif bump_position == 'Up' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Top Left':
            frame_orientation = '0'
            map_orientation = '90'
        elif bump_position == 'Up' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Top Left':
            frame_orientation = '90'
            map_orientation = '180'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Top Left':
            frame_orientation = '180'
            map_orientation = '270/-90'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Top Left':
            frame_orientation = '270'
            map_orientation = '0'

        elif bump_position == 'Up' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Top Right':
            frame_orientation = '0'
            map_orientation = '90'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Top Right':
            frame_orientation = '90'
            map_orientation = '180'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Top Right':
            frame_orientation = '180'
            map_orientation = '270/-90'
        elif bump_position == 'Up' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Top Right':
            frame_orientation = '270'
            map_orientation = '0'

        elif bump_position == 'Up' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '0'
            map_orientation = '90'
        elif bump_position == 'Up' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '90'
            map_orientation = '180'
        elif bump_position == 'Up' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '180'
            map_orientation = '270/-90'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Bottom Left':
            frame_orientation = '270'
            map_orientation = '0'

        elif bump_position == 'Up' and pin1_frame == 'Bottom Left' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '0'
            map_orientation = '90'
        elif bump_position == 'Up' and pin1_frame == 'Bottom Right' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '90'
            map_orientation = '180'
        elif bump_position == 'Up' and pin1_frame == 'Top Right' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '180'
            map_orientation = '270/-90'
        elif bump_position == 'Up' and pin1_frame == 'Top Left' and target_pin1_carrier == 'Bottom Right':
            frame_orientation = '270'
            map_orientation = '0'

        elif bump_position == '' or pin1_frame == '' or target_pin1_carrier == '':
            frame_orientation = ''
            map_orientation = ''
