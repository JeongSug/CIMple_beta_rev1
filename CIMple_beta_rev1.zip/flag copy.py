import threading
import time

off = 0
class Thread1(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.flag = threading.Event()

    def run(self):
        while not self.flag.is_set():
            print("Thread1 said : Thread %s alive\n"%self.ident)
            time.sleep(1)
        print("Thread1 said : Thread %s die\n"%self.ident)

class Thread2(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.flag = threading.Event()

    def run(self):
        global off
        for i in range(0,5):
            print("Thread2 said : %d left\n"%(5-i))
            time.sleep(1)
        off = 1 
        print("Thread2 said : Thread %s die\n"%self.ident)

def main():
    try:
        j1 = Thread1()
        j2 = Thread2()
        j1.start()
        j2.start()

        j2.join()
        if off == 1:
            j1.flag.set()
            j1.join()
    except Exception as e:
        print(e)

if __name__ == '__main__':
    main()