# global loaddata
import requests
from bs4 import BeautifulSoup
from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCore import (QCoreApplication, QPropertyAnimation, QDate, QDateTime, QMetaObject, QObject, QPoint, QRect, QSize, QTime, QUrl, Qt, QEvent)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor, QFont, QFontDatabase, QIcon, QKeySequence, QLinearGradient, QPalette, QPainter, QPixmap, QRadialGradient)
from PySide6.QtWidgets import *
# from PySide6.QtWidgets import QMainWindow, QApplication, QTableWidget

def loaddata(self):
    self.timer = QtCore.QTimer()
    self.timer.timeout.connect(self.updateTime_pnp_status)
    self.timer.timeout.connect(self.updateTime_flipper)
    self.timer.start(60000)
    # rowcount = self.ui.tableWidget_3.rowCount()
    # colcount = self.ui.tableWidget_3.colCount()

    global total_flipperqty
    global total_pickerqty
    global total_autosuction
    total_flipperqty = []
    total_pickerqty = []
    total_autosuction = []
    total_bypassdoor = []

    # for i in range(0, rowcount):
    #     for j in range(0, colcount):
    #         data = self.ui.tableWidget_3.item(i, j)
    #         if data is not None:
    #             print(data.text())
    #         else:
    #             print('black')

    # for i in range(rowcount, 6):
    #     data = self.ui.tableWidget_3.item(i, 6)
    #     if data is not None:
    #         print(data.text())
    #     else:
    #         print('blank')

    global machine_mi30
    def machine_mi30(mcn, x):
        response = requests.get(
            'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR={0}&Language=1'.format(mcn))
        soup = BeautifulSoup(response.content, 'html.parser')
        PnP1 = response.text
        PnP1_split = PnP1.split('\t')
        if PnP1_split != ['Comm State\x08Disabled']:
            count_workingFlipper = []
            count_workingPicker = []
            count_workingAutosuction = []
            by_pass_vision = []
            by_pass_door = []
            for i in range(len(PnP1_split)):
                e = "zero and index error"
                try:
                    if PnP1_split[i][0:3] == 'CDT': self.ui.tableWidget_3.setItem(x, 0, QtWidgets.QTableWidgetItem(PnP1_split[i][18:]))
                    if PnP1_split[i][0:15] == 'Track in Lots-P': 
                        self.ui.tableWidget_3.setItem(x, 1, QtWidgets.QTableWidgetItem(PnP1_split[i].split('')[4]))
                        if PnP1_split[i].split('')[4] == '852' or PnP1_split[i].split('')[4] == '856':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('HVM'))
                        elif PnP1_split[i].split('')[4] == '982' or PnP1_split[i].split('')[4] == '986':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('NPI'))
                        elif PnP1_split[i].split('')[4] == '575':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('HVM'))
                        elif PnP1_split[i].split('')[4] == '948':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('NPI'))
                        elif PnP1_split[i].split('')[4] == '379':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('HVM'))
                        elif PnP1_split[i].split('')[4] == '504':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('NPI')) 
                        elif PnP1_split[i].split('')[4] == '453':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('HVM'))
                        elif PnP1_split[i].split('')[4] == '734':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('NPI'))
                        elif PnP1_split[i].split('')[4] == '2386':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('HVM')) # ESI-PVT HVM
                        elif PnP1_split[i].split('')[4] == '2129':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('NPI')) # ESI-PVT NPI  
                    if PnP1_split[i][0:9] == 'Customer\b': self.ui.tableWidget_3.setItem(x, 2, QtWidgets.QTableWidgetItem(PnP1_split[i][9:]))
                    if PnP1_split[i][0:5] == 'Devic': self.ui.tableWidget_3.setItem(x, 3, QtWidgets.QTableWidgetItem(PnP1_split[i][7:]))
                    # if PnP1_split[i][0:6] == 'AO Lot': self.ui.tableWidget_3.setItem(x, 4, QtWidgets.QTableWidgetItem(PnP1_split[i][8:]))
                    if PnP1_split[i][0:15] == 'Track in Lots-P': 
                        self.ui.tableWidget_3.setItem(x, 4, QtWidgets.QTableWidgetItem(PnP1_split[i].split('')[10] + ' / ' +PnP1_split[i].split('')[11]))
                        # print(PnP1_split[i].split(''))
                        # self.ui.tableWidget_3.setItem(x, 4, QtWidgets.QTableWidgetItem(PnP1_split[i][22:25]))
                    if PnP1_split[i][0:16] == 'Track in Lots-SM': self.ui.tableWidget_3.setItem(x, 5, QtWidgets.QTableWidgetItem(PnP1_split[i][22:25]))
                    if PnP1_split[i][0:2] == 'UP': self.ui.tableWidget_3.setItem(x, 7, QtWidgets.QTableWidgetItem(PnP1_split[i][4:]))
                    if PnP1_split[i][0:11] == 'MachineYiel': self.ui.tableWidget_3.setItem(x, 10,QtWidgets.QTableWidgetItem(PnP1_split[i][13:]))
                    if PnP1_split[i][0:7] == 'LotYiel': self.ui.tableWidget_3.setItem(x, 11, QtWidgets.QTableWidgetItem(PnP1_split[i][9:]))
                    if PnP1_split[i][0:13] == 'LotlyRejectQt': self.ui.tableWidget_3.setItem(x, 12, QtWidgets.QTableWidgetItem(PnP1_split[i][15:]))
                    if PnP1_split[i][0:6] == 'WaferI': self.ui.tableWidget_3.setItem(x, 13, QtWidgets.QTableWidgetItem(PnP1_split[i][8:]))
                    if PnP1_split[i][0:9] == 'CurrentBi': self.ui.tableWidget_3.setItem(x, 14, QtWidgets.QTableWidgetItem(PnP1_split[i][11:]))
                    if PnP1_split[i][0:13] == 'TotalTapeCoun': self.ui.tableWidget_3.setItem(x, 15, QtWidgets.QTableWidgetItem(PnP1_split[i][15:]))
                    if PnP1_split[i][0:14] == 'FrameRecipeNam':
                        if PnP1_split[i][16:] == "1":
                            self.ui.tableWidget_3.setItem(x, 16, QtWidgets.QTableWidgetItem("8_Inch"))
                        if PnP1_split[i][16:] == "2":
                            self.ui.tableWidget_3.setItem(x, 16, QtWidgets.QTableWidgetItem("12_Inch"))
                    if PnP1_split[i][0:10] == 'AutoSuctio':
                        if PnP1_split[i][12:] == "1":
                            self.ui.tableWidget_3.setItem(x, 17, QtWidgets.QTableWidgetItem("On"))
                            count_workingAutosuction.append(int(PnP1_split[i][12:]))
                        if PnP1_split[i][12:] == "0":
                            self.ui.tableWidget_3.setItem(x, 17, QtWidgets.QTableWidgetItem("Off"))
                            self.ui.tableWidget_3.item(x, 17).setForeground(QBrush(Qt.red))
                            self.ui.tableWidget_3.item(x, 17).setBackground(QBrush(Qt.yellow))
                    if PnP1_split[i][0:16] == 'DPSIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                    elif PnP1_split[i][0:17] == 'DSW1IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    elif PnP1_split[i][0:17] == 'DSW2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    elif PnP1_split[i][0:17] == 'DSW3IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    elif PnP1_split[i][0:17] == 'DSW4IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    elif PnP1_split[i][0:17] == 'DTP2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    elif PnP1_split[i][0:16] == 'FLPIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                    elif PnP1_split[i][0:16] == 'IPKIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                    elif PnP1_split[i][0:17] == 'IPK2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    elif PnP1_split[i][0:16] == 'PKPIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                    elif PnP1_split[i][0:17] == 'PKP2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    elif PnP1_split[i][0:16] == 'NIRIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                    elif PnP1_split[i][0:16] == 'POSIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                    elif PnP1_split[i][0:17] == 'POS2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    elif PnP1_split[i][0:17] == 'PRT2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    if PnP1_split[i][0:11] == 'FlipperHead': 
                        if PnP1_split[i][13:] == "1" or PnP1_split[i][13:] == "175":
                            count_workingFlipper.append(i)
                    if PnP1_split[i][0:10] == 'PickupHead': 
                        if PnP1_split[i][12:] == "1" or PnP1_split[i][13:] == "1":
                            count_workingPicker.append(i)
                    if PnP1_split[i][0:10] == 'BypassDoor':
                        if PnP1_split[i][17:] == "1":
                            self.ui.tableWidget_3.setItem(x, 19, QtWidgets.QTableWidgetItem("Open"))
                            self.ui.tableWidget_3.item(x, 19).setForeground(QBrush(Qt.red))
                            self.ui.tableWidget_3.item(x, 19).setBackground(QBrush(Qt.yellow))
                            by_pass_door.append(i)
                        if PnP1_split[i][17:] == "0":
                            self.ui.tableWidget_3.setItem(x, 19, QtWidgets.QTableWidgetItem("Closed"))

                except (ZeroDivisionError, IndexError) as e:
                    print(e)
            # Autosuction_percentage = str(int(sum(total_autosuction)/48*100)) + '%' + ' (%d/%s)' % (sum(total_autosuction), 48)
            # flipper = str(len(count_workingFlipper)) + ' (%d/%s)' % (len(count_workingFlipper), 4)
            # picker = str(len(count_workingPicker)) + ' (%d/%s)' % (len(count_workingPicker), 16)
            flipper = '%d / %s' % (len(count_workingFlipper), 4)
            picker = '%d / %s' % (len(count_workingPicker), 16)
            # print(flipper)
            # print(picker)
            self.ui.tableWidget_3.setItem(x, 8, QtWidgets.QTableWidgetItem(flipper))
            total_flipperqty.append(int(len(count_workingFlipper)))
            self.ui.tableWidget_3.setItem(x, 9, QtWidgets.QTableWidgetItem(picker))
            total_pickerqty.append(int(len(count_workingPicker)))
            total_autosuction.append(int(len(count_workingAutosuction)))
            total_bypassdoor.append(int(len(by_pass_door)))
            if "1" in by_pass_vision or "False" in by_pass_vision: self.ui.tableWidget_3.setItem(x, 18, QtWidgets.QTableWidgetItem("On"))
            else: self.ui.tableWidget_3.setItem(x, 18, QtWidgets.QTableWidgetItem("Off"))
            if int(len(count_workingFlipper)) < 4:
                self.ui.tableWidget_3.item(x, 8).setForeground(QBrush(Qt.red))
                # self.ui.tableWidget_3.setItem(1, 6, QTableWidgetItem('123'))
                self.ui.tableWidget_3.item(x, 8).setBackground(QBrush(Qt.yellow))
            if int(len(count_workingPicker)) < 16:
                self.ui.tableWidget_3.item(x, 9).setForeground(QBrush(Qt.red))
                self.ui.tableWidget_3.item(x, 9).setBackground(QBrush(Qt.yellow))

    global machine_mi40
    def machine_mi40(mcn, x):
        response = requests.get(
            'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR={0}&Language=1'.format(mcn))
        soup = BeautifulSoup(response.content, 'html.parser')
        PnP1 = response.text
        PnP1_split = PnP1.split('\t')
        if PnP1_split != ['Comm State\x08Disabled']:
            count_workingFlipper = []
            count_workingPicker = []
            count_workingAutosuction = []
            by_pass_vision = []
            by_pass_door = []
            for i in range(len(PnP1_split)):
                e = "zero and index error"
                try:
                    if PnP1_split[i][0:3] == 'CDT': self.ui.tableWidget_3.setItem(x, 0, QtWidgets.QTableWidgetItem(PnP1_split[i][18:]))
                    if PnP1_split[i][0:15] == 'Track in Lots-P': 
                        self.ui.tableWidget_3.setItem(x, 1, QtWidgets.QTableWidgetItem(PnP1_split[i].split('')[4]))
                        if PnP1_split[i].split('')[4] == '852' or PnP1_split[i].split('')[4] == '856':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('HVM'))
                        elif PnP1_split[i].split('')[4] == '982' or PnP1_split[i].split('')[4] == '986':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('NPI'))
                        elif PnP1_split[i].split('')[4] == '575':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('HVM'))
                        elif PnP1_split[i].split('')[4] == '948':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('NPI'))
                        elif PnP1_split[i].split('')[4] == '379':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('HVM'))
                        elif PnP1_split[i].split('')[4] == '504':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('NPI')) 
                        elif PnP1_split[i].split('')[4] == '453':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('HVM'))
                        elif PnP1_split[i].split('')[4] == '734':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('NPI'))
                        elif PnP1_split[i].split('')[4] == '2386':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('HVM')) # ESI-PVT HVM
                        elif PnP1_split[i].split('')[4] == '2129':
                            self.ui.tableWidget_3.setItem(x, 6, QtWidgets.QTableWidgetItem('NPI')) # ESI-PVT NPI
                    if PnP1_split[i][0:9] == 'Customer\b': self.ui.tableWidget_3.setItem(x, 2, QtWidgets.QTableWidgetItem(PnP1_split[i][9:]))
                    if PnP1_split[i][0:5] == 'Devic': self.ui.tableWidget_3.setItem(x, 3, QtWidgets.QTableWidgetItem(PnP1_split[i][7:]))
                    # if PnP1_split[i][0:6] == 'AO Lot': self.ui.tableWidget_3.setItem(x, 4, QtWidgets.QTableWidgetItem(PnP1_split[i][8:]))
                    if PnP1_split[i][0:15] == 'Track in Lots-P': self.ui.tableWidget_3.setItem(x, 4, QtWidgets.QTableWidgetItem(PnP1_split[i].split('')[10] + ' / ' +PnP1_split[i].split('')[11]))
                    if PnP1_split[i][0:16] == 'Track in Lots-SM': self.ui.tableWidget_3.setItem(x, 5, QtWidgets.QTableWidgetItem(PnP1_split[i][22:25]))                
                    if PnP1_split[i][0:2] == 'UP': self.ui.tableWidget_3.setItem(x, 7, QtWidgets.QTableWidgetItem(PnP1_split[i][4:]))
                    if PnP1_split[i][0:11] == 'MachineYiel': self.ui.tableWidget_3.setItem(x, 10, QtWidgets.QTableWidgetItem(PnP1_split[i][13:]))
                    if PnP1_split[i][0:7] == 'LotYiel': self.ui.tableWidget_3.setItem(x, 11, QtWidgets.QTableWidgetItem(PnP1_split[i][9:]))
                    if PnP1_split[i][0:13] == 'LotlyRejectQt': self.ui.tableWidget_3.setItem(x, 12, QtWidgets.QTableWidgetItem(PnP1_split[i][15:]))
                    if PnP1_split[i][0:6] == 'WaferI': self.ui.tableWidget_3.setItem(x, 13, QtWidgets.QTableWidgetItem(PnP1_split[i][8:]))
                    if PnP1_split[i][0:9] == 'CurrentBi': self.ui.tableWidget_3.setItem(x, 14, QtWidgets.QTableWidgetItem(PnP1_split[i][11:]))
                    if PnP1_split[i][0:13] == 'TotalTapeCoun': self.ui.tableWidget_3.setItem(x, 15, QtWidgets.QTableWidgetItem(PnP1_split[i][15:]))
                    if PnP1_split[i][0:14] == 'FrameRecipeNam':
                        if PnP1_split[i][16:18] == "12":
                            self.ui.tableWidget_3.setItem(x, 16, QtWidgets.QTableWidgetItem("8_Inch"))
                        if PnP1_split[i][16:18] == "17":
                            self.ui.tableWidget_3.setItem(x, 16, QtWidgets.QTableWidgetItem("12_Inch"))
                    if PnP1_split[i][0:10] == 'AutoSuctio':
                        if PnP1_split[i][12:] == "1":
                            self.ui.tableWidget_3.setItem(x, 17, QtWidgets.QTableWidgetItem("On"))
                            count_workingAutosuction.append(int(PnP1_split[i][12:]))
                        if PnP1_split[i][12:] == "0":
                            self.ui.tableWidget_3.setItem(x, 17, QtWidgets.QTableWidgetItem("Off"))
                            self.ui.tableWidget_3.item(x, 17).setForeground(QBrush(Qt.red))
                            self.ui.tableWidget_3.item(x, 17).setBackground(QBrush(Qt.yellow))
                    if PnP1_split[i][0:16] == 'DPSIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                    elif PnP1_split[i][0:17] == 'DSW1IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    elif PnP1_split[i][0:17] == 'DSW2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    elif PnP1_split[i][0:17] == 'DSW3IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    elif PnP1_split[i][0:17] == 'DSW4IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    elif PnP1_split[i][0:17] == 'DTP2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    elif PnP1_split[i][0:16] == 'FLPIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                    elif PnP1_split[i][0:16] == 'IPKIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                    elif PnP1_split[i][0:17] == 'IPK2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    elif PnP1_split[i][0:16] == 'PKPIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                    elif PnP1_split[i][0:17] == 'PKP2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    elif PnP1_split[i][0:16] == 'NIRIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                    elif PnP1_split[i][0:16] == 'POSIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                    elif PnP1_split[i][0:17] == 'POS2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    elif PnP1_split[i][0:17] == 'PRT2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                    if PnP1_split[i][0:11] == 'FlipperHead': 
                        if PnP1_split[i][13:] == "1" or PnP1_split[i][13:] == "175":
                            count_workingFlipper.append(i)
                    if PnP1_split[i][0:10] == 'PickupHead': 
                        if PnP1_split[i][12:] == "1" or PnP1_split[i][13:] == "1":
                            count_workingPicker.append(i)
                    if PnP1_split[i][0:10] == 'BypassDoor':
                        if PnP1_split[i][17:] == "1":
                            self.ui.tableWidget_3.setItem(x, 19, QtWidgets.QTableWidgetItem("Open"))
                            self.ui.tableWidget_3.item(x, 19).setForeground(QBrush(Qt.red))
                            self.ui.tableWidget_3.item(x, 19).setBackground(QBrush(Qt.yellow))
                            by_pass_door.append(i)
                        if PnP1_split[i][17:] == "0":
                            self.ui.tableWidget_3.setItem(x, 19, QtWidgets.QTableWidgetItem("Closed"))

                except (ZeroDivisionError, IndexError) as e:
                    print(e)
            # Autosuction_percentage = str(int(sum(total_autosuction)/48*100)) + '%' + ' (%d/%s)' % (sum(total_autosuction), 48)
            # flipper = str(len(count_workingFlipper)) + ' (%d/%s)' % (len(count_workingFlipper), 4)
            # picker = str(len(count_workingPicker)) + ' (%d/%s)' % (len(count_workingPicker), 16)
            flipper = '%d / %s' % (len(count_workingFlipper), 8)
            picker = '%d / %s' % (len(count_workingPicker), 20)
            # print(flipper)
            # print(picker)
            self.ui.tableWidget_3.setItem(x, 8, QtWidgets.QTableWidgetItem(flipper))
            total_flipperqty.append(int(len(count_workingFlipper)))
            self.ui.tableWidget_3.setItem(x, 9, QtWidgets.QTableWidgetItem(picker))
            total_pickerqty.append(int(len(count_workingPicker)))
            total_autosuction.append(int(len(count_workingAutosuction)))
            total_bypassdoor.append(int(len(by_pass_door)))
            if "1" in by_pass_vision or "False" in by_pass_vision: self.ui.tableWidget_3.setItem(x, 18, QtWidgets.QTableWidgetItem("On"))
            else: self.ui.tableWidget_3.setItem(x, 18, QtWidgets.QTableWidgetItem("Off"))
            if int(len(count_workingFlipper)) < 8:
                self.ui.tableWidget_3.item(x, 8).setForeground(QBrush(Qt.red))
                # self.ui.tableWidget_3.setItem(1, 6, QTableWidgetItem('123'))
                self.ui.tableWidget_3.item(x, 8).setBackground(QBrush(Qt.yellow))
            if int(len(count_workingPicker)) < 20:
                self.ui.tableWidget_3.item(x, 9).setForeground(QBrush(Qt.red))
                self.ui.tableWidget_3.item(x, 9).setBackground(QBrush(Qt.yellow))

    global total_flipper
    def total_flipper():
        Mi30_flipper = 4
        Mi30_picker = 16
        Mi40_flipper = 8
        Mi40_picker = 20
        # print(total_flipperqty)
        Flipper_percentage = str(int(sum(total_flipperqty)/(34*Mi30_flipper + 14*Mi40_flipper)*100)) + '%' + ' (%d/%s)' % (sum(total_flipperqty), (34*Mi30_flipper + 14*Mi40_flipper))
        Picker_percentage = str(int(sum(total_pickerqty)/(34*Mi30_picker + 14*Mi40_picker)*100)) + '%' + ' (%d/%s)' % (sum(total_pickerqty), (34*Mi30_picker + 14*Mi40_picker))
        # Autosuction_percentage = str(int(sum(total_autosuction)/48)) + '%' + str(int(sum(total_autosuction))) + '/' + str(48)
        Autosuction_percentage = str(int(sum(total_autosuction)/48*100)) + '%' + ' (%d/%s)' % (sum(total_autosuction), 48)
        BypassDoor_percentage = str(int(sum(total_bypassdoor)))

        print(Flipper_percentage)
        print(Picker_percentage)
        print(Autosuction_percentage)
        print(BypassDoor_percentage)
        
        self.ui.tableWidget_3.setItem(0, 8, QtWidgets.QTableWidgetItem(Flipper_percentage))
        self.ui.tableWidget_3.setItem(0, 9, QtWidgets.QTableWidgetItem(Picker_percentage))
        self.ui.tableWidget_3.setItem(0, 17, QtWidgets.QTableWidgetItem(Autosuction_percentage))
        self.ui.tableWidget_3.setItem(0, 19, QtWidgets.QTableWidgetItem("Warning: " + BypassDoor_percentage + "EA"))
        total_flipperqty.clear()
        total_pickerqty.clear()
        total_autosuction.clear()
        total_bypassdoor.clear()