# global loaddata
import requests
from bs4 import BeautifulSoup
from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCore import (QCoreApplication, QPropertyAnimation, QDate, QDateTime, QMetaObject, QObject, QPoint, QRect, QSize, QTime, QUrl, Qt, QEvent)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor, QFont, QFontDatabase, QIcon, QKeySequence, QLinearGradient, QPalette, QPainter, QPixmap, QRadialGradient)
from PySide6.QtWidgets import *

global total_flipperqty
global total_pickerqty
global total_autosuction
total_flipperqty = []
total_pickerqty = []
total_autosuction = []
total_bypassdoor = []

global machine_mi30_left
def machine_mi30_left(self, mcn, x):
    response = requests.get(
        'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR={0}&Language=1'.format(mcn))
    soup = BeautifulSoup(response.content, 'html.parser')
    PnP1 = response.text
    PnP1_split = PnP1.split('\t')
    if PnP1_split != ['Comm State\x08Disabled']:
        count_workingFlipper = []
        count_workingPicker = []
        count_workingAutosuction = []
        by_pass_vision = []
        by_pass_door = []
        for i in range(len(PnP1_split)):
            e = "zero and index error"
            try:
                if PnP1_split[i][0:9] == 'Customer\b': self.ui.tableWidget_4.setItem(x, 0, QtWidgets.QTableWidgetItem(PnP1_split[i][9:])) # Customer
                if PnP1_split[i][0:5] == 'Devic':
                    if PnP1_split[i][7:9] == 'QM':
                        self.ui.tableWidget_4.setItem(x, 1, QtWidgets.QTableWidgetItem(PnP1_split[i][7:14])) # Target Device_QORVO
                        # print(str(mcn) + ' : ' + PnP1_split[i][7:])
                    elif PnP1_split[i][7:9] == 'TW':
                        self.ui.tableWidget_4.setItem(x, 1, QtWidgets.QTableWidgetItem(PnP1_split[i][7:14])) # Target Device_QORVO
                    elif PnP1_split[i][7:9] == 'PK':
                        self.ui.tableWidget_4.setItem(x, 1, QtWidgets.QTableWidgetItem(PnP1_split[i][7:13])) # Target Device_SKYWORKS
                    else:
                        self.ui.tableWidget_4.setItem(x, 1, QtWidgets.QTableWidgetItem(PnP1_split[i][7:])) # Target Device
                if PnP1_split[i][0:2] == 'UP': self.ui.tableWidget_4.setItem(x, 2, QtWidgets.QTableWidgetItem(PnP1_split[i][4:])) # T&R UPH
                if PnP1_split[i][0:10] == 'AutoSuctio': # Auto Suction
                    if PnP1_split[i][12:] == "1":
                        self.ui.tableWidget_4.setItem(x, 4, QtWidgets.QTableWidgetItem("On"))
                    if PnP1_split[i][12:] == "0":
                        self.ui.tableWidget_4.setItem(x, 4, QtWidgets.QTableWidgetItem("Off"))
                        self.ui.tableWidget_4.item(x, 4).setForeground(QBrush(Qt.red))
                        self.ui.tableWidget_4.item(x, 4).setBackground(QBrush(Qt.yellow))
                        count_workingAutosuction.append(int(PnP1_split[i][12:]))
                if PnP1_split[i][0:16] == 'DPSIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                elif PnP1_split[i][0:17] == 'DSW1IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                elif PnP1_split[i][0:17] == 'DSW2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                elif PnP1_split[i][0:17] == 'DSW3IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                elif PnP1_split[i][0:17] == 'DSW4IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                elif PnP1_split[i][0:17] == 'DTP2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                elif PnP1_split[i][0:16] == 'FLPIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                elif PnP1_split[i][0:16] == 'IPKIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                elif PnP1_split[i][0:17] == 'IPK2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                elif PnP1_split[i][0:16] == 'PKPIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                elif PnP1_split[i][0:17] == 'PKP2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                elif PnP1_split[i][0:16] == 'NIRIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                elif PnP1_split[i][0:16] == 'POSIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                elif PnP1_split[i][0:17] == 'POS2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                elif PnP1_split[i][0:17] == 'PRT2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                if PnP1_split[i][0:11] == 'FlipperHead':
                    if PnP1_split[i][13:] == "1" or PnP1_split[i][13:] == "175":
                        count_workingFlipper.append(i)
                if PnP1_split[i][0:10] == 'PickupHead':
                    if PnP1_split[i][12:] == "1" or PnP1_split[i][13:] == "1":
                        count_workingPicker.append(i)
                if PnP1_split[i][0:10] == 'BypassDoor': # Bypass Door
                    if PnP1_split[i][17:] == "1":
                        self.ui.tableWidget_4.setItem(x, 6, QtWidgets.QTableWidgetItem("Open"))
                        self.ui.tableWidget_4.item(x, 6).setForeground(QBrush(Qt.red))
                        self.ui.tableWidget_4.item(x, 6).setBackground(QBrush(Qt.yellow))
                        by_pass_door.append(i)
                    if PnP1_split[i][17:] == "0":
                        self.ui.tableWidget_4.setItem(x, 6, QtWidgets.QTableWidgetItem("Closed"))

            except (ZeroDivisionError, IndexError) as e:
                print(e)

        self.ui.tableWidget_4.setItem(x, 3, QtWidgets.QTableWidgetItem(str(len(count_workingFlipper))+' / '+str(len(count_workingPicker)))) # Flipper / Picker
        if "1" in by_pass_vision or "False" in by_pass_vision: self.ui.tableWidget_4.setItem(x, 5, QtWidgets.QTableWidgetItem("On")) # Bypass Vision
        else: self.ui.tableWidget_4.setItem(x, 5, QtWidgets.QTableWidgetItem("Off"))
        if int(len(count_workingFlipper)) < 4:
            self.ui.tableWidget_4.item(x, 3).setForeground(QBrush(Qt.red))
            self.ui.tableWidget_4.item(x, 3).setBackground(QBrush(Qt.yellow))
        if int(len(count_workingPicker)) < 16:
            self.ui.tableWidget_4.item(x, 3).setForeground(QBrush(Qt.red))
            self.ui.tableWidget_4.item(x, 3).setBackground(QBrush(Qt.yellow))
        total_flipperqty.append(int(len(count_workingFlipper)))
        total_pickerqty.append(int(len(count_workingPicker)))
        total_autosuction.append(int(len(count_workingAutosuction)))
        total_bypassdoor.append(int(len(by_pass_door)))


global machine_mi40_left
def machine_mi40_left(self, mcn, x):
    response = requests.get(
        'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR={0}&Language=1'.format(mcn))
    soup = BeautifulSoup(response.content, 'html.parser')
    PnP3 = response.text
    PnP3_split = PnP3.split('\t')
    if PnP3_split != ['Comm State\x08Disabled']:
        count_workingFlipper = []
        count_workingPicker = []
        count_workingAutosuction = []
        by_pass_vision = []
        by_pass_door = []
        for i in range(len(PnP3_split)):
            e = "zero and index error"
            try:
                if PnP3_split[i][0:9] == 'Customer\b': self.ui.tableWidget_4.setItem(x, 0, QtWidgets.QTableWidgetItem(PnP3_split[i][9:])) # Customer
                if PnP3_split[i][0:5] == 'Devic':
                    if PnP3_split[i][7:9] == 'QM':
                        self.ui.tableWidget_4.setItem(x, 1, QtWidgets.QTableWidgetItem(PnP3_split[i][7:14])) # Target Device_QORVO
                    elif PnP3_split[i][7:9] == 'TW':
                        self.ui.tableWidget_4.setItem(x, 1, QtWidgets.QTableWidgetItem(PnP3_split[i][7:14])) # Target Device_QORVO
                    elif PnP3_split[i][7:9] == 'PK':
                        self.ui.tableWidget_4.setItem(x, 1, QtWidgets.QTableWidgetItem(PnP3_split[i][7:13])) # Target Device_SKYWORKS
                    else:
                        self.ui.tableWidget_4.setItem(x, 1, QtWidgets.QTableWidgetItem(PnP3_split[i][7:])) # Target Device
                if PnP3_split[i][0:2] == 'UP': self.ui.tableWidget_4.setItem(x, 2, QtWidgets.QTableWidgetItem(PnP3_split[i][4:])) # T&R UPH
                if PnP3_split[i][0:10] == 'AutoSuctio': # Auto Suction
                    if PnP3_split[i][12:] == "1":
                        self.ui.tableWidget_4.setItem(x, 4, QtWidgets.QTableWidgetItem("On"))
                    if PnP3_split[i][12:] == "0":
                        self.ui.tableWidget_4.setItem(x, 4, QtWidgets.QTableWidgetItem("Off"))
                        self.ui.tableWidget_4.item(x, 4).setForeground(QBrush(Qt.red))
                        self.ui.tableWidget_4.item(x, 4).setBackground(QBrush(Qt.yellow))
                        count_workingAutosuction.append(int(PnP3_split[i][12:]))
                if PnP3_split[i][0:16] == 'DPSIsBypassVisio': by_pass_vision.append(PnP3_split[i][18:])
                elif PnP3_split[i][0:17] == 'DSW1IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                elif PnP3_split[i][0:17] == 'DSW2IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                elif PnP3_split[i][0:17] == 'DSW3IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                elif PnP3_split[i][0:17] == 'DSW4IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                elif PnP3_split[i][0:17] == 'DTP2IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                elif PnP3_split[i][0:16] == 'FLPIsBypassVisio': by_pass_vision.append(PnP3_split[i][18:])
                elif PnP3_split[i][0:16] == 'IPKIsBypassVisio': by_pass_vision.append(PnP3_split[i][18:])
                elif PnP3_split[i][0:17] == 'IPK2IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                elif PnP3_split[i][0:16] == 'PKPIsBypassVisio': by_pass_vision.append(PnP3_split[i][18:])
                elif PnP3_split[i][0:17] == 'PKP2IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                elif PnP3_split[i][0:16] == 'NIRIsBypassVisio': by_pass_vision.append(PnP3_split[i][18:])
                elif PnP3_split[i][0:16] == 'POSIsBypassVisio': by_pass_vision.append(PnP3_split[i][18:])
                elif PnP3_split[i][0:17] == 'POS2IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                elif PnP3_split[i][0:17] == 'PRT2IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                if PnP3_split[i][0:11] == 'FlipperHead':
                    if PnP3_split[i][13:] == "1" or PnP3_split[i][13:] == "175":
                        count_workingFlipper.append(i)
                if PnP3_split[i][0:10] == 'PickupHead':
                    if PnP3_split[i][12:] == "1" or PnP3_split[i][13:] == "1":
                        count_workingPicker.append(i)
                if PnP3_split[i][0:10] == 'BypassDoor': # Bypass Door
                    if PnP3_split[i][17:] == "1":
                        self.ui.tableWidget_4.setItem(x, 6, QtWidgets.QTableWidgetItem("Open"))
                        self.ui.tableWidget_4.item(x, 6).setForeground(QBrush(Qt.red))
                        self.ui.tableWidget_4.item(x, 6).setBackground(QBrush(Qt.yellow))
                        by_pass_door.append(i)
                    if PnP3_split[i][17:] == "0":
                        self.ui.tableWidget_4.setItem(x, 6, QtWidgets.QTableWidgetItem("Closed"))

            except (ZeroDivisionError, IndexError) as e:
                print(e)

        self.ui.tableWidget_4.setItem(x, 3, QtWidgets.QTableWidgetItem(str(len(count_workingFlipper))+' / '+str(len(count_workingPicker)))) # Flipper / Picker
        if "1" in by_pass_vision or "False" in by_pass_vision: self.ui.tableWidget_4.setItem(x, 5, QtWidgets.QTableWidgetItem("On")) # Bypass Vision
        else: self.ui.tableWidget_4.setItem(x, 5, QtWidgets.QTableWidgetItem("Off"))
        if int(len(count_workingFlipper)) < 8:
            self.ui.tableWidget_4.item(x, 3).setForeground(QBrush(Qt.red))
            self.ui.tableWidget_4.item(x, 3).setBackground(QBrush(Qt.yellow))
        if int(len(count_workingPicker)) < 20:
            self.ui.tableWidget_4.item(x, 3).setForeground(QBrush(Qt.red))
            self.ui.tableWidget_4.item(x, 3).setBackground(QBrush(Qt.yellow))
        total_flipperqty.append(int(len(count_workingFlipper)))
        total_pickerqty.append(int(len(count_workingPicker)))
        total_autosuction.append(int(len(count_workingAutosuction)))
        total_bypassdoor.append(int(len(by_pass_door)))

global machine_mi30_right
def machine_mi30_right(self, mcn, x):
    response = requests.get(
        'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR={0}&Language=1'.format(mcn))
    soup = BeautifulSoup(response.content, 'html.parser')
    PnP1 = response.text
    PnP1_split = PnP1.split('\t')
    if PnP1_split != ['Comm State\x08Disabled']:
        count_workingFlipper = []
        count_workingPicker = []
        count_workingAutosuction = []
        by_pass_vision = []
        by_pass_door = []
        for i in range(len(PnP1_split)):
            e = "zero and index error"
            try:
                if PnP1_split[i][0:9] == 'Customer\b': self.ui.tableWidget_5.setItem(x-25, 0, QtWidgets.QTableWidgetItem(PnP1_split[i][9:])) # Customer
                if PnP1_split[i][0:5] == 'Devic':
                    if PnP1_split[i][7:9] == 'QM':
                        self.ui.tableWidget_5.setItem(x-25, 1, QtWidgets.QTableWidgetItem(PnP1_split[i][7:14])) # Target Device_QORVO
                    elif PnP1_split[i][7:9] == 'TW':
                        self.ui.tableWidget_5.setItem(x-25, 1, QtWidgets.QTableWidgetItem(PnP1_split[i][7:14])) # Target Device_QORVO
                    elif PnP1_split[i][7:9] == 'PK':
                        self.ui.tableWidget_5.setItem(x-25, 1, QtWidgets.QTableWidgetItem(PnP1_split[i][7:13])) # Target Device_SKYWORKS
                    else:
                        self.ui.tableWidget_5.setItem(x-25, 1, QtWidgets.QTableWidgetItem(PnP1_split[i][7:])) # Target Device
                if PnP1_split[i][0:2] == 'UP': self.ui.tableWidget_5.setItem(x-25, 2, QtWidgets.QTableWidgetItem(PnP1_split[i][4:])) # T&R UPH
                if PnP1_split[i][0:10] == 'AutoSuctio': # Auto Suction
                    if PnP1_split[i][12:] == "1":
                        self.ui.tableWidget_5.setItem(x-25, 4, QtWidgets.QTableWidgetItem("On"))
                    if PnP1_split[i][12:] == "0":
                        self.ui.tableWidget_5.setItem(x-25, 4, QtWidgets.QTableWidgetItem("Off"))
                        self.ui.tableWidget_5.item(x-25, 4).setForeground(QBrush(Qt.red))
                        self.ui.tableWidget_5.item(x-25, 4).setBackground(QBrush(Qt.yellow))
                        count_workingAutosuction.append(int(PnP1_split[i][12:]))
                if PnP1_split[i][0:16] == 'DPSIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                elif PnP1_split[i][0:17] == 'DSW1IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                elif PnP1_split[i][0:17] == 'DSW2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                elif PnP1_split[i][0:17] == 'DSW3IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                elif PnP1_split[i][0:17] == 'DSW4IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                elif PnP1_split[i][0:17] == 'DTP2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                elif PnP1_split[i][0:16] == 'FLPIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                elif PnP1_split[i][0:16] == 'IPKIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                elif PnP1_split[i][0:17] == 'IPK2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                elif PnP1_split[i][0:16] == 'PKPIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                elif PnP1_split[i][0:17] == 'PKP2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                elif PnP1_split[i][0:16] == 'NIRIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                elif PnP1_split[i][0:16] == 'POSIsBypassVisio': by_pass_vision.append(PnP1_split[i][18:])
                elif PnP1_split[i][0:17] == 'POS2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                elif PnP1_split[i][0:17] == 'PRT2IsBypassVisio': by_pass_vision.append(PnP1_split[i][19:])
                if PnP1_split[i][0:11] == 'FlipperHead':
                    if PnP1_split[i][13:] == "1" or PnP1_split[i][13:] == "175":
                        count_workingFlipper.append(i)
                if PnP1_split[i][0:10] == 'PickupHead':
                    if PnP1_split[i][12:] == "1" or PnP1_split[i][13:] == "1":
                        count_workingPicker.append(i)
                if PnP1_split[i][0:10] == 'BypassDoor': # Bypass Door
                    if PnP1_split[i][17:] == "1":
                        self.ui.tableWidget_5.setItem(x-25, 6, QtWidgets.QTableWidgetItem("Open"))
                        self.ui.tableWidget_5.item(x-25, 6).setForeground(QBrush(Qt.red))
                        self.ui.tableWidget_5.item(x-25, 6).setBackground(QBrush(Qt.yellow))
                        by_pass_door.append(i)
                    if PnP1_split[i][17:] == "0":
                        self.ui.tableWidget_5.setItem(x-25, 6, QtWidgets.QTableWidgetItem("Closed"))

            except (ZeroDivisionError, IndexError) as e:
                print(e)

        self.ui.tableWidget_5.setItem(x-25, 3, QtWidgets.QTableWidgetItem(str(len(count_workingFlipper))+' / '+str(len(count_workingPicker)))) # Flipper / Picker
        if "1" in by_pass_vision or "False" in by_pass_vision: self.ui.tableWidget_5.setItem(x-25, 5, QtWidgets.QTableWidgetItem("On")) # Bypass Vision
        else: self.ui.tableWidget_5.setItem(x-25, 5, QtWidgets.QTableWidgetItem("Off"))
        if int(len(count_workingFlipper)) < 4:
            self.ui.tableWidget_5.item(x-25, 3).setForeground(QBrush(Qt.red))
            self.ui.tableWidget_5.item(x-25, 3).setBackground(QBrush(Qt.yellow))
        if int(len(count_workingPicker)) < 16:
            self.ui.tableWidget_5.item(x-25, 3).setForeground(QBrush(Qt.red))
            self.ui.tableWidget_5.item(x-25, 3).setBackground(QBrush(Qt.yellow))
        total_flipperqty.append(int(len(count_workingFlipper)))
        total_pickerqty.append(int(len(count_workingPicker)))
        total_autosuction.append(int(len(count_workingAutosuction)))
        total_bypassdoor.append(int(len(by_pass_door)))

global machine_mi40_right
def machine_mi40_right(self, mcn, x):
    response = requests.get(
        'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR={0}&Language=1'.format(mcn))
    soup = BeautifulSoup(response.content, 'html.parser')
    PnP3 = response.text
    PnP3_split = PnP3.split('\t')
    if PnP3_split != ['Comm State\x08Disabled']:
        count_workingFlipper = []
        count_workingPicker = []
        count_workingAutosuction = []
        by_pass_vision = []
        by_pass_door = []
        for i in range(len(PnP3_split)):
            e = "zero and index error"
            try:
                if PnP3_split[i][0:9] == 'Customer\b': self.ui.tableWidget_5.setItem(x-25, 0, QtWidgets.QTableWidgetItem(PnP3_split[i][9:])) # Customer
                if PnP3_split[i][0:5] == 'Devic':
                    if PnP3_split[i][7:9] == 'QM':
                        self.ui.tableWidget_5.setItem(x-25, 1, QtWidgets.QTableWidgetItem(PnP3_split[i][7:14])) # Target Device_QORVO
                    elif PnP3_split[i][7:9] == 'TW':
                        self.ui.tableWidget_5.setItem(x-25, 1, QtWidgets.QTableWidgetItem(PnP3_split[i][7:14])) # Target Device_QORVO
                    elif PnP3_split[i][7:9] == 'PK':
                        self.ui.tableWidget_5.setItem(x-25, 1, QtWidgets.QTableWidgetItem(PnP3_split[i][7:13])) # Target Device_SKYWORKS
                    else:
                        self.ui.tableWidget_5.setItem(x-25, 1, QtWidgets.QTableWidgetItem(PnP3_split[i][7:])) # Target Device
                if PnP3_split[i][0:2] == 'UP': self.ui.tableWidget_5.setItem(x-25, 2, QtWidgets.QTableWidgetItem(PnP3_split[i][4:])) # T&R UPH
                if PnP3_split[i][0:10] == 'AutoSuctio': # Auto Suction
                    if PnP3_split[i][12:] == "1":
                        self.ui.tableWidget_5.setItem(x-25, 4, QtWidgets.QTableWidgetItem("On"))
                    if PnP3_split[i][12:] == "0":
                        self.ui.tableWidget_5.setItem(x-25, 4, QtWidgets.QTableWidgetItem("Off"))
                        self.ui.tableWidget_5.item(x-25, 4).setForeground(QBrush(Qt.red))
                        self.ui.tableWidget_5.item(x-25, 4).setBackground(QBrush(Qt.yellow))
                        count_workingAutosuction.append(int(PnP3_split[i][12:]))
                if PnP3_split[i][0:16] == 'DPSIsBypassVisio': by_pass_vision.append(PnP3_split[i][18:])
                elif PnP3_split[i][0:17] == 'DSW1IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                elif PnP3_split[i][0:17] == 'DSW2IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                elif PnP3_split[i][0:17] == 'DSW3IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                elif PnP3_split[i][0:17] == 'DSW4IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                elif PnP3_split[i][0:17] == 'DTP2IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                elif PnP3_split[i][0:16] == 'FLPIsBypassVisio': by_pass_vision.append(PnP3_split[i][18:])
                elif PnP3_split[i][0:16] == 'IPKIsBypassVisio': by_pass_vision.append(PnP3_split[i][18:])
                elif PnP3_split[i][0:17] == 'IPK2IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                elif PnP3_split[i][0:16] == 'PKPIsBypassVisio': by_pass_vision.append(PnP3_split[i][18:])
                elif PnP3_split[i][0:17] == 'PKP2IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                elif PnP3_split[i][0:16] == 'NIRIsBypassVisio': by_pass_vision.append(PnP3_split[i][18:])
                elif PnP3_split[i][0:16] == 'POSIsBypassVisio': by_pass_vision.append(PnP3_split[i][18:])
                elif PnP3_split[i][0:17] == 'POS2IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                elif PnP3_split[i][0:17] == 'PRT2IsBypassVisio': by_pass_vision.append(PnP3_split[i][19:])
                if PnP3_split[i][0:11] == 'FlipperHead':
                    if PnP3_split[i][13:] == "1" or PnP3_split[i][13:] == "175":
                        count_workingFlipper.append(i)
                if PnP3_split[i][0:10] == 'PickupHead':
                    if PnP3_split[i][12:] == "1" or PnP3_split[i][13:] == "1":
                        count_workingPicker.append(i)
                if PnP3_split[i][0:10] == 'BypassDoor': # Bypass Door
                    if PnP3_split[i][17:] == "1":
                        self.ui.tableWidget_5.setItem(x-25, 6, QtWidgets.QTableWidgetItem("Open"))
                        self.ui.tableWidget_5.item(x-25, 6).setForeground(QBrush(Qt.red))
                        self.ui.tableWidget_5.item(x-25, 6).setBackground(QBrush(Qt.yellow))
                        by_pass_door.append(i)
                    if PnP3_split[i][17:] == "0":
                        self.ui.tableWidget_5.setItem(x-25, 6, QtWidgets.QTableWidgetItem("Closed"))

            except (ZeroDivisionError, IndexError) as e:
                print(e)

        self.ui.tableWidget_5.setItem(x-25, 3, QtWidgets.QTableWidgetItem(str(len(count_workingFlipper))+' / '+str(len(count_workingPicker)))) # Flipper / Picker
        if "1" in by_pass_vision or "False" in by_pass_vision: self.ui.tableWidget_5.setItem(x-25, 5, QtWidgets.QTableWidgetItem("On")) # Bypass Vision
        else: self.ui.tableWidget_5.setItem(x-25, 5, QtWidgets.QTableWidgetItem("Off"))
        if int(len(count_workingFlipper)) < 8:
            self.ui.tableWidget_5.item(x-25, 3).setForeground(QBrush(Qt.red))
            self.ui.tableWidget_5.item(x-25, 3).setBackground(QBrush(Qt.yellow))
        if int(len(count_workingPicker)) < 20:
            self.ui.tableWidget_5.item(x-25, 3).setForeground(QBrush(Qt.red))
            self.ui.tableWidget_5.item(x-25, 3).setBackground(QBrush(Qt.yellow))
        total_flipperqty.append(int(len(count_workingFlipper)))
        total_pickerqty.append(int(len(count_workingPicker)))
        total_autosuction.append(int(len(count_workingAutosuction)))
        total_bypassdoor.append(int(len(by_pass_door)))

global total_flipper_tv
def total_flipper_tv(self):
    Mi30_flipper = 4
    Mi30_picker = 16
    Mi40_flipper = 8
    Mi40_picker = 20
    # print(total_flipperqty)
    Flipper_percentage = str(int(sum(total_flipperqty)/(34*Mi30_flipper + 14*Mi40_flipper)*100)) + '%' + ' (%d/%s)' % (sum(total_flipperqty), (34*Mi30_flipper + 14*Mi40_flipper))
    Picker_percentage = str(int(sum(total_pickerqty)/(34*Mi30_picker + 14*Mi40_picker)*100)) + '%' + ' (%d/%s)' % (sum(total_pickerqty), (34*Mi30_picker + 14*Mi40_picker))
    # Autosuction_percentage = str(int(sum(total_autosuction)/48)) + '%' + str(int(sum(total_autosuction))) + '/' + str(48)
    Autosuction_percentage = str(int(sum(total_autosuction))) + ' EA'
    BypassDoor_percentage = str(int(sum(total_bypassdoor))) + ' EA'

    # print(Flipper_percentage)
    # print(Picker_percentage)
    # print(Autosuction_percentage)

    # self.ui.tableWidget_4.setItem(0, 3, QtWidgets.QTableWidgetItem(Flipper_percentage))
    # self.ui.tableWidget_4.setItem(0, 3, QtWidgets.QTableWidgetItem(Picker_percentage))
    self.ui.tableWidget_4.setItem(0, 4, QtWidgets.QTableWidgetItem(Autosuction_percentage))
    self.ui.tableWidget_4.setItem(0, 6, QtWidgets.QTableWidgetItem(BypassDoor_percentage))
    total_flipperqty.clear()
    total_pickerqty.clear()
    total_autosuction.clear()
    total_bypassdoor.clear()