# global loaddata
import requests
from bs4 import BeautifulSoup
from PySide2 import QtCore, QtGui, QtWidgets
from PySide2.QtCore import (QCoreApplication, QPropertyAnimation, QDate, QDateTime, QMetaObject, QObject, QPoint, QRect, QSize, QTime, QUrl, Qt, QEvent)
from PySide2.QtGui import (QBrush, QColor, QConicalGradient, QCursor, QFont, QFontDatabase, QIcon, QKeySequence, QLinearGradient, QPalette, QPainter, QPixmap, QRadialGradient)
from PySide2.QtWidgets import *
# from main import *
# from main import MainWindow

def loaddata(self):
    self.timer = QtCore.QTimer()
    self.timer.timeout.connect(self.updateTime_pusher)
    self.timer.start(10000)
    global machine_37
    def machine_37():
        response = requests.get(
            'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR=34601&Language=1')
        soup = BeautifulSoup(response.content, 'html.parser')
        PnP37 = response.text
        PnP37_split = PnP37.split('\t')
        if PnP37_split != ['Comm State\x08Disabled']:
            for i in range(len(PnP37_split)):
                try:
                    if PnP37_split[i][0:10] == 'Ejectpin H': self.ui.tableWidget_4.setItem(1, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][16:]))
                    if PnP37_split[i][0:5] == 'EGear': self.ui.tableWidget_4.setItem(2, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][18:]))
                    if PnP37_split[i][0:5] == 'UnitT': self.ui.tableWidget_4.setItem(3, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][14:]))
                    if PnP37_split[i][0:5] == 'Mylar': self.ui.tableWidget_4.setItem(4, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][19:]))
                    if PnP37_split[i][0:5] == 'FLPOv': self.ui.tableWidget_4.setItem(5, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][16:]))
                    if PnP37_split[i][0:5] == 'IPPOv': self.ui.tableWidget_4.setItem(6, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][16:]))
                    if PnP37_split[i][0:12] == 'TNRPPFurther': self.ui.tableWidget_4.setItem(7, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][24:]))
                    if PnP37_split[i][0:11] == 'TNRPPDevice': self.ui.tableWidget_4.setItem(8, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][21:]))
                    if PnP37_split[i][0:8] == 'TNRPPMin': self.ui.tableWidget_4.setItem(9, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][11:]))
                    if PnP37_split[i][0:9] == 'TNRPusher': self.ui.tableWidget_4.setItem(10, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][22:]))
                    if PnP37_split[i][0:13] == 'TNRPP2Further': self.ui.tableWidget_4.setItem(11, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][25:]))
                    if PnP37_split[i][0:12] == 'TNR2PPDevice': self.ui.tableWidget_4.setItem(12, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][22:]))
                    if PnP37_split[i][0:9] == 'TNRPP2Min': self.ui.tableWidget_4.setItem(13, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][12:]))
                    if PnP37_split[i][0:10] == 'TNRPP2Over': self.ui.tableWidget_4.setItem(14, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][19:]))
                    if PnP37_split[i][0:5] == 'CZPPO': self.ui.tableWidget_4.setItem(15, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][17:]))
                    if PnP37_split[i][0:5] == 'DTPPO': self.ui.tableWidget_4.setItem(16, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][17:]))
                    if PnP37_split[i][0:7] == 'BumpPPO': self.ui.tableWidget_4.setItem(17, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][19:]))
                    if PnP37_split[i][0:7] == 'BumpPPD': self.ui.tableWidget_4.setItem(18, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][18:]))
                    if PnP37_split[i][0:6] == 'LeftSW': self.ui.tableWidget_4.setItem(19, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][22:]))
                    if PnP37_split[i][0:8] == 'BottomSW': self.ui.tableWidget_4.setItem(20, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][23:]))
                    if PnP37_split[i][0:7] == 'RightSW': self.ui.tableWidget_4.setItem(21, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][22:]))
                    if PnP37_split[i][0:5] == 'TopSW': self.ui.tableWidget_4.setItem(22, 39, QtWidgets.QTableWidgetItem(PnP37_split[i][20:]))
                    
                except StopIterator:
                    pass

    global machine_38

    def machine_38():
        response = requests.get(
            'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR=35171&Language=1')
        soup = BeautifulSoup(response.content, 'html.parser')
        PnP38 = response.text
        PnP38_split = PnP38.split('\t')
        if PnP38_split != ['Comm State\x08Disabled']:
            for i in range(len(PnP38_split)):
                try:
                    if PnP38_split[i][0:10] == 'Ejectpin H': self.ui.tableWidget_4.setItem(1, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][16:]))
                    if PnP38_split[i][0:5] == 'EGear': self.ui.tableWidget_4.setItem(2, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][18:]))
                    if PnP38_split[i][0:5] == 'UnitT': self.ui.tableWidget_4.setItem(3, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][14:]))
                    if PnP38_split[i][0:5] == 'Mylar': self.ui.tableWidget_4.setItem(4, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][19:]))
                    if PnP38_split[i][0:5] == 'FLPOv': self.ui.tableWidget_4.setItem(5, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][16:]))
                    if PnP38_split[i][0:5] == 'IPPOv': self.ui.tableWidget_4.setItem(6, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][16:]))
                    if PnP38_split[i][0:12] == 'TNRPPFurther': self.ui.tableWidget_4.setItem(7, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][24:]))
                    if PnP38_split[i][0:11] == 'TNRPPDevice': self.ui.tableWidget_4.setItem(8, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][21:]))
                    if PnP38_split[i][0:8] == 'TNRPPMin': self.ui.tableWidget_4.setItem(9, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][11:]))
                    if PnP38_split[i][0:9] == 'TNRPusher': self.ui.tableWidget_4.setItem(10, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][22:]))
                    if PnP38_split[i][0:13] == 'TNRPP2Further': self.ui.tableWidget_4.setItem(11, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][25:]))
                    if PnP38_split[i][0:12] == 'TNR2PPDevice': self.ui.tableWidget_4.setItem(12, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][22:]))
                    if PnP38_split[i][0:9] == 'TNRPP2Min': self.ui.tableWidget_4.setItem(13, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][12:]))
                    if PnP38_split[i][0:10] == 'TNRPP2Over': self.ui.tableWidget_4.setItem(14, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][19:]))
                    if PnP38_split[i][0:5] == 'CZPPO': self.ui.tableWidget_4.setItem(15, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][17:]))
                    if PnP38_split[i][0:5] == 'DTPPO': self.ui.tableWidget_4.setItem(16, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][17:]))
                    if PnP38_split[i][0:7] == 'BumpPPO': self.ui.tableWidget_4.setItem(17, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][19:]))
                    if PnP38_split[i][0:7] == 'BumpPPD': self.ui.tableWidget_4.setItem(18, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][18:]))
                    if PnP38_split[i][0:6] == 'LeftSW': self.ui.tableWidget_4.setItem(19, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][22:]))
                    if PnP38_split[i][0:8] == 'BottomSW': self.ui.tableWidget_4.setItem(20, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][23:]))
                    if PnP38_split[i][0:7] == 'RightSW': self.ui.tableWidget_4.setItem(21, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][22:]))
                    if PnP38_split[i][0:5] == 'TopSW': self.ui.tableWidget_4.setItem(22, 40, QtWidgets.QTableWidgetItem(PnP38_split[i][20:]))

                except StopIterator:
                    pass


    global machine_39

    def machine_39():
        response = requests.get(
            'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR=35172&Language=1')
        soup = BeautifulSoup(response.content, 'html.parser')
        PnP39 = response.text
        PnP39_split = PnP39.split('\t')
        if PnP39_split != ['Comm State\x08Disabled']:
            for i in range(len(PnP39_split)):
                try:
                    if PnP39_split[i][0:10] == 'Ejectpin H': self.ui.tableWidget_4.setItem(1, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][16:]))
                    if PnP39_split[i][0:5] == 'EGear': self.ui.tableWidget_4.setItem(2, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][18:]))
                    if PnP39_split[i][0:5] == 'UnitT': self.ui.tableWidget_4.setItem(3, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][14:]))
                    if PnP39_split[i][0:5] == 'Mylar': self.ui.tableWidget_4.setItem(4, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][19:]))
                    if PnP39_split[i][0:5] == 'FLPOv': self.ui.tableWidget_4.setItem(5, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][16:]))
                    if PnP39_split[i][0:5] == 'IPPOv': self.ui.tableWidget_4.setItem(6, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][16:]))
                    if PnP39_split[i][0:12] == 'TNRPPFurther': self.ui.tableWidget_4.setItem(7, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][24:]))
                    if PnP39_split[i][0:11] == 'TNRPPDevice': self.ui.tableWidget_4.setItem(8, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][21:]))
                    if PnP39_split[i][0:8] == 'TNRPPMin': self.ui.tableWidget_4.setItem(9, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][11:]))
                    if PnP39_split[i][0:9] == 'TNRPusher': self.ui.tableWidget_4.setItem(10, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][22:]))
                    if PnP39_split[i][0:13] == 'TNRPP2Further': self.ui.tableWidget_4.setItem(11, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][25:]))
                    if PnP39_split[i][0:12] == 'TNR2PPDevice': self.ui.tableWidget_4.setItem(12, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][22:]))
                    if PnP39_split[i][0:9] == 'TNRPP2Min': self.ui.tableWidget_4.setItem(13, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][12:]))
                    if PnP39_split[i][0:10] == 'TNRPP2Over': self.ui.tableWidget_4.setItem(14, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][19:]))
                    if PnP39_split[i][0:5] == 'CZPPO': self.ui.tableWidget_4.setItem(15, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][17:]))
                    if PnP39_split[i][0:5] == 'DTPPO': self.ui.tableWidget_4.setItem(16, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][17:]))
                    if PnP39_split[i][0:7] == 'BumpPPO': self.ui.tableWidget_4.setItem(17, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][19:]))
                    if PnP39_split[i][0:7] == 'BumpPPD': self.ui.tableWidget_4.setItem(18, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][18:]))
                    if PnP39_split[i][0:6] == 'LeftSW': self.ui.tableWidget_4.setItem(19, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][22:]))
                    if PnP39_split[i][0:8] == 'BottomSW': self.ui.tableWidget_4.setItem(20, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][23:]))
                    if PnP39_split[i][0:7] == 'RightSW': self.ui.tableWidget_4.setItem(21, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][22:]))
                    if PnP39_split[i][0:5] == 'TopSW': self.ui.tableWidget_4.setItem(22, 41, QtWidgets.QTableWidgetItem(PnP39_split[i][20:]))

                except StopIterator:
                    pass


    global machine_40

    def machine_40():
        response = requests.get(
            'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR=35272&Language=1')
        soup = BeautifulSoup(response.content, 'html.parser')
        PnP40 = response.text
        PnP40_split = PnP40.split('\t')
        if PnP40_split != ['Comm State\x08Disabled']:
            for i in range(len(PnP40_split)):
                try:
                    if PnP40_split[i][0:10] == 'Ejectpin H': self.ui.tableWidget_4.setItem(1, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][16:]))
                    if PnP40_split[i][0:5] == 'EGear': self.ui.tableWidget_4.setItem(2, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][18:]))
                    if PnP40_split[i][0:5] == 'UnitT': self.ui.tableWidget_4.setItem(3, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][14:]))
                    if PnP40_split[i][0:5] == 'Mylar': self.ui.tableWidget_4.setItem(4, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][19:]))
                    if PnP40_split[i][0:5] == 'FLPOv': self.ui.tableWidget_4.setItem(5, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][16:]))
                    if PnP40_split[i][0:5] == 'IPPOv': self.ui.tableWidget_4.setItem(6, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][16:]))
                    if PnP40_split[i][0:12] == 'TNRPPFurther': self.ui.tableWidget_4.setItem(7, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][24:]))
                    if PnP40_split[i][0:11] == 'TNRPPDevice': self.ui.tableWidget_4.setItem(8, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][21:]))
                    if PnP40_split[i][0:8] == 'TNRPPMin': self.ui.tableWidget_4.setItem(9, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][11:]))
                    if PnP40_split[i][0:9] == 'TNRPusher': self.ui.tableWidget_4.setItem(10, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][22:]))
                    if PnP40_split[i][0:13] == 'TNRPP2Further': self.ui.tableWidget_4.setItem(11, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][25:]))
                    if PnP40_split[i][0:12] == 'TNR2PPDevice': self.ui.tableWidget_4.setItem(12, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][22:]))
                    if PnP40_split[i][0:9] == 'TNRPP2Min': self.ui.tableWidget_4.setItem(13, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][12:]))
                    if PnP40_split[i][0:10] == 'TNRPP2Over': self.ui.tableWidget_4.setItem(14, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][19:]))
                    if PnP40_split[i][0:5] == 'CZPPO': self.ui.tableWidget_4.setItem(15, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][17:]))
                    if PnP40_split[i][0:5] == 'DTPPO': self.ui.tableWidget_4.setItem(16, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][17:]))
                    if PnP40_split[i][0:7] == 'BumpPPO': self.ui.tableWidget_4.setItem(17, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][19:]))
                    if PnP40_split[i][0:7] == 'BumpPPD': self.ui.tableWidget_4.setItem(18, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][18:]))
                    if PnP40_split[i][0:6] == 'LeftSW': self.ui.tableWidget_4.setItem(19, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][22:]))
                    if PnP40_split[i][0:8] == 'BottomSW': self.ui.tableWidget_4.setItem(20, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][23:]))
                    if PnP40_split[i][0:7] == 'RightSW': self.ui.tableWidget_4.setItem(21, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][22:]))
                    if PnP40_split[i][0:5] == 'TopSW': self.ui.tableWidget_4.setItem(22, 42, QtWidgets.QTableWidgetItem(PnP40_split[i][20:]))

                except StopIterator:
                    pass


    global machine_41

    def machine_41():
        response = requests.get(
            'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR=35273&Language=1')
        soup = BeautifulSoup(response.content, 'html.parser')
        PnP41 = response.text
        PnP41_split = PnP41.split('\t')
        if PnP41_split != ['Comm State\x08Disabled']:
            for i in range(len(PnP41_split)):
                try:
                    if PnP41_split[i][0:10] == 'Ejectpin H': self.ui.tableWidget_4.setItem(1, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][16:]))
                    if PnP41_split[i][0:5] == 'EGear': self.ui.tableWidget_4.setItem(2, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][18:]))
                    if PnP41_split[i][0:5] == 'UnitT': self.ui.tableWidget_4.setItem(3, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][14:]))
                    if PnP41_split[i][0:5] == 'Mylar': self.ui.tableWidget_4.setItem(4, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][19:]))
                    if PnP41_split[i][0:5] == 'FLPOv': self.ui.tableWidget_4.setItem(5, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][16:]))
                    if PnP41_split[i][0:5] == 'IPPOv': self.ui.tableWidget_4.setItem(6, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][16:]))
                    if PnP41_split[i][0:12] == 'TNRPPFurther': self.ui.tableWidget_4.setItem(7, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][24:]))
                    if PnP41_split[i][0:11] == 'TNRPPDevice': self.ui.tableWidget_4.setItem(8, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][21:]))
                    if PnP41_split[i][0:8] == 'TNRPPMin': self.ui.tableWidget_4.setItem(9, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][11:]))
                    if PnP41_split[i][0:9] == 'TNRPusher': self.ui.tableWidget_4.setItem(10, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][22:]))
                    if PnP41_split[i][0:13] == 'TNRPP2Further': self.ui.tableWidget_4.setItem(11, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][25:]))
                    if PnP41_split[i][0:12] == 'TNR2PPDevice': self.ui.tableWidget_4.setItem(12, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][22:]))
                    if PnP41_split[i][0:9] == 'TNRPP2Min': self.ui.tableWidget_4.setItem(13, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][12:]))
                    if PnP41_split[i][0:10] == 'TNRPP2Over': self.ui.tableWidget_4.setItem(14, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][19:]))
                    if PnP41_split[i][0:5] == 'CZPPO': self.ui.tableWidget_4.setItem(15, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][17:]))
                    if PnP41_split[i][0:5] == 'DTPPO': self.ui.tableWidget_4.setItem(16, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][17:]))
                    if PnP41_split[i][0:7] == 'BumpPPO': self.ui.tableWidget_4.setItem(17, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][19:]))
                    if PnP41_split[i][0:7] == 'BumpPPD': self.ui.tableWidget_4.setItem(18, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][18:]))
                    if PnP41_split[i][0:6] == 'LeftSW': self.ui.tableWidget_4.setItem(19, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][22:]))
                    if PnP41_split[i][0:8] == 'BottomSW': self.ui.tableWidget_4.setItem(20, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][23:]))
                    if PnP41_split[i][0:7] == 'RightSW': self.ui.tableWidget_4.setItem(21, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][22:]))
                    if PnP41_split[i][0:5] == 'TopSW': self.ui.tableWidget_4.setItem(22, 43, QtWidgets.QTableWidgetItem(PnP41_split[i][20:]))

                except StopIterator:
                    pass


    global machine_42

    def machine_42():
        response = requests.get(
            'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR=35274&Language=1')
        soup = BeautifulSoup(response.content, 'html.parser')
        PnP42 = response.text
        PnP42_split = PnP42.split('\t')
        if PnP42_split != ['Comm State\x08Disabled']:
            for i in range(len(PnP42_split)):
                try:
                    if PnP42_split[i][0:10] == 'Ejectpin H': self.ui.tableWidget_4.setItem(1, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][16:]))
                    if PnP42_split[i][0:5] == 'EGear': self.ui.tableWidget_4.setItem(2, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][18:]))
                    if PnP42_split[i][0:5] == 'UnitT': self.ui.tableWidget_4.setItem(3, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][14:]))
                    if PnP42_split[i][0:5] == 'Mylar': self.ui.tableWidget_4.setItem(4, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][19:]))
                    if PnP42_split[i][0:5] == 'FLPOv': self.ui.tableWidget_4.setItem(5, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][16:]))
                    if PnP42_split[i][0:5] == 'IPPOv': self.ui.tableWidget_4.setItem(6, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][16:]))
                    if PnP42_split[i][0:12] == 'TNRPPFurther': self.ui.tableWidget_4.setItem(7, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][24:]))
                    if PnP42_split[i][0:11] == 'TNRPPDevice': self.ui.tableWidget_4.setItem(8, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][21:]))
                    if PnP42_split[i][0:8] == 'TNRPPMin': self.ui.tableWidget_4.setItem(9, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][11:]))
                    if PnP42_split[i][0:9] == 'TNRPusher': self.ui.tableWidget_4.setItem(10, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][22:]))
                    if PnP42_split[i][0:13] == 'TNRPP2Further': self.ui.tableWidget_4.setItem(11, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][25:]))
                    if PnP42_split[i][0:12] == 'TNR2PPDevice': self.ui.tableWidget_4.setItem(12, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][22:]))
                    if PnP42_split[i][0:9] == 'TNRPP2Min': self.ui.tableWidget_4.setItem(13, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][12:]))
                    if PnP42_split[i][0:10] == 'TNRPP2Over': self.ui.tableWidget_4.setItem(14, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][19:]))
                    if PnP42_split[i][0:5] == 'CZPPO': self.ui.tableWidget_4.setItem(15, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][17:]))
                    if PnP42_split[i][0:5] == 'DTPPO': self.ui.tableWidget_4.setItem(16, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][17:]))
                    if PnP42_split[i][0:7] == 'BumpPPO': self.ui.tableWidget_4.setItem(17, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][19:]))
                    if PnP42_split[i][0:7] == 'BumpPPD': self.ui.tableWidget_4.setItem(18, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][18:]))
                    if PnP42_split[i][0:6] == 'LeftSW': self.ui.tableWidget_4.setItem(19, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][22:]))
                    if PnP42_split[i][0:8] == 'BottomSW': self.ui.tableWidget_4.setItem(20, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][23:]))
                    if PnP42_split[i][0:7] == 'RightSW': self.ui.tableWidget_4.setItem(21, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][22:]))
                    if PnP42_split[i][0:5] == 'TopSW': self.ui.tableWidget_4.setItem(22, 44, QtWidgets.QTableWidgetItem(PnP42_split[i][20:]))

                except StopIterator:
                    pass


    global machine_43

    def machine_43():
        response = requests.get(
            'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR=35338&Language=1')
        soup = BeautifulSoup(response.content, 'html.parser')
        PnP43 = response.text
        PnP43_split = PnP43.split('\t')
        if PnP43_split != ['Comm State\x08Disabled']:
            for i in range(len(PnP43_split)):
                try:
                    if PnP43_split[i][0:10] == 'Ejectpin H': self.ui.tableWidget_4.setItem(1, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][16:]))
                    if PnP43_split[i][0:5] == 'EGear': self.ui.tableWidget_4.setItem(2, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][18:]))
                    if PnP43_split[i][0:5] == 'UnitT': self.ui.tableWidget_4.setItem(3, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][14:]))
                    if PnP43_split[i][0:5] == 'Mylar': self.ui.tableWidget_4.setItem(4, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][19:]))
                    if PnP43_split[i][0:5] == 'FLPOv': self.ui.tableWidget_4.setItem(5, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][16:]))
                    if PnP43_split[i][0:5] == 'IPPOv': self.ui.tableWidget_4.setItem(6, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][16:]))
                    if PnP43_split[i][0:12] == 'TNRPPFurther': self.ui.tableWidget_4.setItem(7, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][24:]))
                    if PnP43_split[i][0:11] == 'TNRPPDevice': self.ui.tableWidget_4.setItem(8, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][21:]))
                    if PnP43_split[i][0:8] == 'TNRPPMin': self.ui.tableWidget_4.setItem(9, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][11:]))
                    if PnP43_split[i][0:9] == 'TNRPusher': self.ui.tableWidget_4.setItem(10, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][22:]))
                    if PnP43_split[i][0:13] == 'TNRPP2Further': self.ui.tableWidget_4.setItem(11, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][25:]))
                    if PnP43_split[i][0:12] == 'TNR2PPDevice': self.ui.tableWidget_4.setItem(12, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][22:]))
                    if PnP43_split[i][0:9] == 'TNRPP2Min': self.ui.tableWidget_4.setItem(13, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][12:]))
                    if PnP43_split[i][0:10] == 'TNRPP2Over': self.ui.tableWidget_4.setItem(14, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][19:]))
                    if PnP43_split[i][0:5] == 'CZPPO': self.ui.tableWidget_4.setItem(15, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][17:]))
                    if PnP43_split[i][0:5] == 'DTPPO': self.ui.tableWidget_4.setItem(16, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][17:]))
                    if PnP43_split[i][0:7] == 'BumpPPO': self.ui.tableWidget_4.setItem(17, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][19:]))
                    if PnP43_split[i][0:7] == 'BumpPPD': self.ui.tableWidget_4.setItem(18, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][18:]))
                    if PnP43_split[i][0:6] == 'LeftSW': self.ui.tableWidget_4.setItem(19, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][22:]))
                    if PnP43_split[i][0:8] == 'BottomSW': self.ui.tableWidget_4.setItem(20, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][23:]))
                    if PnP43_split[i][0:7] == 'RightSW': self.ui.tableWidget_4.setItem(21, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][22:]))
                    if PnP43_split[i][0:5] == 'TopSW': self.ui.tableWidget_4.setItem(22, 45, QtWidgets.QTableWidgetItem(PnP43_split[i][20:]))

                except StopIterator:
                    pass


    global machine_44

    def machine_44():
        response = requests.get(
            'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR=35339&Language=1')
        soup = BeautifulSoup(response.content, 'html.parser')
        PnP44 = response.text
        PnP44_split = PnP44.split('\t')
        if PnP44_split != ['Comm State\x08Disabled']:
            for i in range(len(PnP44_split)):
                try:
                    if PnP44_split[i][0:10] == 'Ejectpin H': self.ui.tableWidget_4.setItem(1, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][16:]))
                    if PnP44_split[i][0:5] == 'EGear': self.ui.tableWidget_4.setItem(2, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][18:]))
                    if PnP44_split[i][0:5] == 'UnitT': self.ui.tableWidget_4.setItem(3, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][14:]))
                    if PnP44_split[i][0:5] == 'Mylar': self.ui.tableWidget_4.setItem(4, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][19:]))
                    if PnP44_split[i][0:5] == 'FLPOv': self.ui.tableWidget_4.setItem(5, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][16:]))
                    if PnP44_split[i][0:5] == 'IPPOv': self.ui.tableWidget_4.setItem(6, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][16:]))
                    if PnP44_split[i][0:12] == 'TNRPPFurther': self.ui.tableWidget_4.setItem(7, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][24:]))
                    if PnP44_split[i][0:11] == 'TNRPPDevice': self.ui.tableWidget_4.setItem(8, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][21:]))
                    if PnP44_split[i][0:8] == 'TNRPPMin': self.ui.tableWidget_4.setItem(9, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][11:]))
                    if PnP44_split[i][0:9] == 'TNRPusher': self.ui.tableWidget_4.setItem(10, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][22:]))
                    if PnP44_split[i][0:13] == 'TNRPP2Further': self.ui.tableWidget_4.setItem(11, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][25:]))
                    if PnP44_split[i][0:12] == 'TNR2PPDevice': self.ui.tableWidget_4.setItem(12, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][22:]))
                    if PnP44_split[i][0:9] == 'TNRPP2Min': self.ui.tableWidget_4.setItem(13, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][12:]))
                    if PnP44_split[i][0:10] == 'TNRPP2Over': self.ui.tableWidget_4.setItem(14, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][19:]))
                    if PnP44_split[i][0:5] == 'CZPPO': self.ui.tableWidget_4.setItem(15, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][17:]))
                    if PnP44_split[i][0:5] == 'DTPPO': self.ui.tableWidget_4.setItem(16, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][17:]))
                    if PnP44_split[i][0:7] == 'BumpPPO': self.ui.tableWidget_4.setItem(17, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][19:]))
                    if PnP44_split[i][0:7] == 'BumpPPD': self.ui.tableWidget_4.setItem(18, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][18:]))
                    if PnP44_split[i][0:6] == 'LeftSW': self.ui.tableWidget_4.setItem(19, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][22:]))
                    if PnP44_split[i][0:8] == 'BottomSW': self.ui.tableWidget_4.setItem(20, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][23:]))
                    if PnP44_split[i][0:7] == 'RightSW': self.ui.tableWidget_4.setItem(21, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][22:]))
                    if PnP44_split[i][0:5] == 'TopSW': self.ui.tableWidget_4.setItem(22, 46, QtWidgets.QTableWidgetItem(PnP44_split[i][20:]))

                except StopIterator:
                    pass


    global machine_45

    def machine_45():
        response = requests.get(
            'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR=35375&Language=1')
        soup = BeautifulSoup(response.content, 'html.parser')
        PnP45 = response.text
        PnP45_split = PnP45.split('\t')
        if PnP45_split != ['Comm State\x08Disabled']:
            for i in range(len(PnP45_split)):
                try:
                    if PnP45_split[i][0:10] == 'Ejectpin H': self.ui.tableWidget_4.setItem(1, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][16:]))
                    if PnP45_split[i][0:5] == 'EGear': self.ui.tableWidget_4.setItem(2, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][18:]))
                    if PnP45_split[i][0:5] == 'UnitT': self.ui.tableWidget_4.setItem(3, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][14:]))
                    if PnP45_split[i][0:5] == 'Mylar': self.ui.tableWidget_4.setItem(4, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][19:]))
                    if PnP45_split[i][0:5] == 'FLPOv': self.ui.tableWidget_4.setItem(5, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][16:]))
                    if PnP45_split[i][0:5] == 'IPPOv': self.ui.tableWidget_4.setItem(6, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][16:]))
                    if PnP45_split[i][0:12] == 'TNRPPFurther': self.ui.tableWidget_4.setItem(7, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][24:]))
                    if PnP45_split[i][0:11] == 'TNRPPDevice': self.ui.tableWidget_4.setItem(8, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][21:]))
                    if PnP45_split[i][0:8] == 'TNRPPMin': self.ui.tableWidget_4.setItem(9, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][11:]))
                    if PnP45_split[i][0:9] == 'TNRPusher': self.ui.tableWidget_4.setItem(10, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][22:]))
                    if PnP45_split[i][0:13] == 'TNRPP2Further': self.ui.tableWidget_4.setItem(11, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][25:]))
                    if PnP45_split[i][0:12] == 'TNR2PPDevice': self.ui.tableWidget_4.setItem(12, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][22:]))
                    if PnP45_split[i][0:9] == 'TNRPP2Min': self.ui.tableWidget_4.setItem(13, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][12:]))
                    if PnP45_split[i][0:10] == 'TNRPP2Over': self.ui.tableWidget_4.setItem(14, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][19:]))
                    if PnP45_split[i][0:5] == 'CZPPO': self.ui.tableWidget_4.setItem(15, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][17:]))
                    if PnP45_split[i][0:5] == 'DTPPO': self.ui.tableWidget_4.setItem(16, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][17:]))
                    if PnP45_split[i][0:7] == 'BumpPPO': self.ui.tableWidget_4.setItem(17, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][19:]))
                    if PnP45_split[i][0:7] == 'BumpPPD': self.ui.tableWidget_4.setItem(18, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][18:]))
                    if PnP45_split[i][0:6] == 'LeftSW': self.ui.tableWidget_4.setItem(19, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][22:]))
                    if PnP45_split[i][0:8] == 'BottomSW': self.ui.tableWidget_4.setItem(20, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][23:]))
                    if PnP45_split[i][0:7] == 'RightSW': self.ui.tableWidget_4.setItem(21, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][22:]))
                    if PnP45_split[i][0:5] == 'TopSW': self.ui.tableWidget_4.setItem(22, 47, QtWidgets.QTableWidgetItem(PnP45_split[i][20:]))

                except StopIterator:
                    pass


    global machine_46

    def machine_46():
        response = requests.get(
            'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR=35376&Language=1')
        soup = BeautifulSoup(response.content, 'html.parser')
        PnP46 = response.text
        PnP46_split = PnP46.split('\t')
        if PnP46_split != ['Comm State\x08Disabled']:
            for i in range(len(PnP46_split)):
                try:
                    if PnP46_split[i][0:10] == 'Ejectpin H': self.ui.tableWidget_4.setItem(1, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][16:]))
                    if PnP46_split[i][0:5] == 'EGear': self.ui.tableWidget_4.setItem(2, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][18:]))
                    if PnP46_split[i][0:5] == 'UnitT': self.ui.tableWidget_4.setItem(3, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][14:]))
                    if PnP46_split[i][0:5] == 'Mylar': self.ui.tableWidget_4.setItem(4, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][19:]))
                    if PnP46_split[i][0:5] == 'FLPOv': self.ui.tableWidget_4.setItem(5, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][16:]))
                    if PnP46_split[i][0:5] == 'IPPOv': self.ui.tableWidget_4.setItem(6, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][16:]))
                    if PnP46_split[i][0:12] == 'TNRPPFurther': self.ui.tableWidget_4.setItem(7, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][24:]))
                    if PnP46_split[i][0:11] == 'TNRPPDevice': self.ui.tableWidget_4.setItem(8, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][21:]))
                    if PnP46_split[i][0:8] == 'TNRPPMin': self.ui.tableWidget_4.setItem(9, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][11:]))
                    if PnP46_split[i][0:9] == 'TNRPusher': self.ui.tableWidget_4.setItem(10, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][22:]))
                    if PnP46_split[i][0:13] == 'TNRPP2Further': self.ui.tableWidget_4.setItem(11, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][25:]))
                    if PnP46_split[i][0:12] == 'TNR2PPDevice': self.ui.tableWidget_4.setItem(12, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][22:]))
                    if PnP46_split[i][0:9] == 'TNRPP2Min': self.ui.tableWidget_4.setItem(13, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][12:]))
                    if PnP46_split[i][0:10] == 'TNRPP2Over': self.ui.tableWidget_4.setItem(14, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][19:]))
                    if PnP46_split[i][0:5] == 'CZPPO': self.ui.tableWidget_4.setItem(15, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][17:]))
                    if PnP46_split[i][0:5] == 'DTPPO': self.ui.tableWidget_4.setItem(16, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][17:]))
                    if PnP46_split[i][0:7] == 'BumpPPO': self.ui.tableWidget_4.setItem(17, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][19:]))
                    if PnP46_split[i][0:7] == 'BumpPPD': self.ui.tableWidget_4.setItem(18, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][18:]))
                    if PnP46_split[i][0:6] == 'LeftSW': self.ui.tableWidget_4.setItem(19, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][22:]))
                    if PnP46_split[i][0:8] == 'BottomSW': self.ui.tableWidget_4.setItem(20, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][23:]))
                    if PnP46_split[i][0:7] == 'RightSW': self.ui.tableWidget_4.setItem(21, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][22:]))
                    if PnP46_split[i][0:5] == 'TopSW': self.ui.tableWidget_4.setItem(22, 48, QtWidgets.QTableWidgetItem(PnP46_split[i][20:]))

                except StopIterator:
                    pass


    global machine_47

    def machine_47():
        response = requests.get(
            'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR=35457&Language=1')
        soup = BeautifulSoup(response.content, 'html.parser')
        PnP47 = response.text
        PnP47_split = PnP47.split('\t')
        if PnP47_split != ['Comm State\x08Disabled']:
            for i in range(len(PnP47_split)):
                try:
                    if PnP47_split[i][0:10] == 'Ejectpin H': self.ui.tableWidget_4.setItem(1, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][16:]))
                    if PnP47_split[i][0:5] == 'EGear': self.ui.tableWidget_4.setItem(2, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][18:]))
                    if PnP47_split[i][0:5] == 'UnitT': self.ui.tableWidget_4.setItem(3, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][14:]))
                    if PnP47_split[i][0:5] == 'Mylar': self.ui.tableWidget_4.setItem(4, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][19:]))
                    if PnP47_split[i][0:5] == 'FLPOv': self.ui.tableWidget_4.setItem(5, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][16:]))
                    if PnP47_split[i][0:5] == 'IPPOv': self.ui.tableWidget_4.setItem(6, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][16:]))
                    if PnP47_split[i][0:12] == 'TNRPPFurther': self.ui.tableWidget_4.setItem(7, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][24:]))
                    if PnP47_split[i][0:11] == 'TNRPPDevice': self.ui.tableWidget_4.setItem(8, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][21:]))
                    if PnP47_split[i][0:8] == 'TNRPPMin': self.ui.tableWidget_4.setItem(9, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][11:]))
                    if PnP47_split[i][0:9] == 'TNRPusher': self.ui.tableWidget_4.setItem(10, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][22:]))
                    if PnP47_split[i][0:13] == 'TNRPP2Further': self.ui.tableWidget_4.setItem(11, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][25:]))
                    if PnP47_split[i][0:12] == 'TNR2PPDevice': self.ui.tableWidget_4.setItem(12, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][22:]))
                    if PnP47_split[i][0:9] == 'TNRPP2Min': self.ui.tableWidget_4.setItem(13, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][12:]))
                    if PnP47_split[i][0:10] == 'TNRPP2Over': self.ui.tableWidget_4.setItem(14, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][19:]))
                    if PnP47_split[i][0:5] == 'CZPPO': self.ui.tableWidget_4.setItem(15, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][17:]))
                    if PnP47_split[i][0:5] == 'DTPPO': self.ui.tableWidget_4.setItem(16, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][17:]))
                    if PnP47_split[i][0:7] == 'BumpPPO': self.ui.tableWidget_4.setItem(17, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][19:]))
                    if PnP47_split[i][0:7] == 'BumpPPD': self.ui.tableWidget_4.setItem(18, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][18:]))
                    if PnP47_split[i][0:6] == 'LeftSW': self.ui.tableWidget_4.setItem(19, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][22:]))
                    if PnP47_split[i][0:8] == 'BottomSW': self.ui.tableWidget_4.setItem(20, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][23:]))
                    if PnP47_split[i][0:7] == 'RightSW': self.ui.tableWidget_4.setItem(21, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][22:]))
                    if PnP47_split[i][0:5] == 'TopSW': self.ui.tableWidget_4.setItem(22, 49, QtWidgets.QTableWidgetItem(PnP47_split[i][20:]))

                except StopIterator:
                    pass


    global machine_48

    def machine_48():
        response = requests.get(
            'http://cim_service.amkor.co.kr:8080/ysj/conn/get_all_equip_parameter?MNBR=35458&Language=1')
        soup = BeautifulSoup(response.content, 'html.parser')
        PnP48 = response.text
        PnP48_split = PnP48.split('\t')
        if PnP48_split != ['Comm State\x08Disabled']:
            for i in range(len(PnP48_split)):
                try:
                    if PnP48_split[i][0:10] == 'Ejectpin H': self.ui.tableWidget_4.setItem(1, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][16:]))
                    if PnP48_split[i][0:5] == 'EGear': self.ui.tableWidget_4.setItem(2, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][18:]))
                    if PnP48_split[i][0:5] == 'UnitT': self.ui.tableWidget_4.setItem(3, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][14:]))
                    if PnP48_split[i][0:5] == 'Mylar': self.ui.tableWidget_4.setItem(4, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][19:]))
                    if PnP48_split[i][0:5] == 'FLPOv': self.ui.tableWidget_4.setItem(5, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][16:]))
                    if PnP48_split[i][0:5] == 'IPPOv': self.ui.tableWidget_4.setItem(6, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][16:]))
                    if PnP48_split[i][0:12] == 'TNRPPFurther': self.ui.tableWidget_4.setItem(7, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][24:]))
                    if PnP48_split[i][0:11] == 'TNRPPDevice': self.ui.tableWidget_4.setItem(8, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][21:]))
                    if PnP48_split[i][0:8] == 'TNRPPMin': self.ui.tableWidget_4.setItem(9, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][11:]))
                    if PnP48_split[i][0:9] == 'TNRPusher': self.ui.tableWidget_4.setItem(10, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][22:]))
                    if PnP48_split[i][0:13] == 'TNRPP2Further': self.ui.tableWidget_4.setItem(11, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][25:]))
                    if PnP48_split[i][0:12] == 'TNR2PPDevice': self.ui.tableWidget_4.setItem(12, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][22:]))
                    if PnP48_split[i][0:9] == 'TNRPP2Min': self.ui.tableWidget_4.setItem(13, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][12:]))
                    if PnP48_split[i][0:10] == 'TNRPP2Over': self.ui.tableWidget_4.setItem(14, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][19:]))
                    if PnP48_split[i][0:5] == 'CZPPO': self.ui.tableWidget_4.setItem(15, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][17:]))
                    if PnP48_split[i][0:5] == 'DTPPO': self.ui.tableWidget_4.setItem(16, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][17:]))
                    if PnP48_split[i][0:7] == 'BumpPPO': self.ui.tableWidget_4.setItem(17, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][19:]))
                    if PnP48_split[i][0:7] == 'BumpPPD': self.ui.tableWidget_4.setItem(18, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][18:]))
                    if PnP48_split[i][0:6] == 'LeftSW': self.ui.tableWidget_4.setItem(19, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][22:]))
                    if PnP48_split[i][0:8] == 'BottomSW': self.ui.tableWidget_4.setItem(20, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][23:]))
                    if PnP48_split[i][0:7] == 'RightSW': self.ui.tableWidget_4.setItem(21, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][22:]))
                    if PnP48_split[i][0:5] == 'TopSW': self.ui.tableWidget_4.setItem(22, 50, QtWidgets.QTableWidgetItem(PnP48_split[i][20:]))

                except StopIterator:
                    pass
