import sys
import os
from cx_freeze import setup, Executable

# ADD FILES
files = ['icon_Amkor1.ico']

# TARGET
target = Executable(
    script="CIMple.py",
    base="Win32GUI",
    icon="icon_Amkor1.ico"
)

# SETUP CX FREEZE
setup(
    name = "CIMple",
    version = "1.0",
    description = "CIMple - Computer Integrated Manufacturing + Line Eagleview",
    author = "Jeongsug Gwag",
    options = {'build_exe' : {'include_files' : files}},
    executables = [target]
)
