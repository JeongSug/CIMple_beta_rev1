import sys
import platform
import process_pin1 as pp
import process_MIE as pm
import process_MIE_first as pmf
import process_Pusher as ppusher
import process_TV as pt
import process_TV_first as ptf
import random

# IMPORT / GUI AND MODULES AND WIDGETS
# ///////////////////////////////////////////////////////////////
from modules import *
from widgets import *
from bs4 import BeautifulSoup

# SET AS GLOBAL WIDGETS
# ///////////////////////////////////////////////////////////////
widgets = None

# GLOBALS
counter = 0

class SplashScreen(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.ui = Ui_SplashScreen()
        self.ui.setupUi(self)

        # REMOVE TITLE BAR
        self.setWindowFlag(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        # IMPORT CIRCULAR PROGRESS
        self.progress = CircularProgress()
        self.progress.width = 270
        self.progress.height = 270
        self.progress.value = 0
        self.progress.setFixedSize(self.progress.width, self.progress.height)
        self.progress.move(15, 15)
        self.progress.font_size = 40
        self.progress.add_shadow(True)
        self.progress.progress_width = 15
        self.progress.bg_color = QColor(68, 71, 90, 140)
        self.progress.setParent(self.ui.centralwidget)
        self.progress.show()

        # ADD DROP SHADOW
        self.shadow = QGraphicsDropShadowEffect(self)
        self.shadow.setBlurRadius(15)
        self.shadow.setXOffset(0)
        self.shadow.setYOffset(0)
        self.shadow.setColor(QColor(0, 0, 0, 80))
        self.setGraphicsEffect(self.shadow)

        # QTIMER 
        self.timer = QTimer()
        self.timer.timeout.connect(self.update)
        self.timer.start(35)

        self.show()

    # UPDATE PROGRESS BAR
    def update(self):
        global counter

        # SET VALUE TO PROGRESS BAR
        self.progress.set_value(counter)

        # CLOSE SPLASH SCREEN AND OPEN MAIN APP
        if counter >= 100:
            # STOP TIMER
            self.timer.stop()

            # SHOW MAIN WINDOW
            self.main = MainWindow()
            self.main.show()

            # CLOSE SPLASH SCREEN
            self.close()

        # INCREASE COUNTER
        counter += 1

class MainWindow(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)

        # SET AS GLOBAL WIDGETS
        # ///////////////////////////////////////////////////////////////
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        global widgets
        widgets = self.ui

        # USE CUSTOM TITLE BAR | USE AS "False" FOR MAC OR LINUX
        # ///////////////////////////////////////////////////////////////
        Settings.ENABLE_CUSTOM_TITLE_BAR = True

        # APP NAME
        # ///////////////////////////////////////////////////////////////
        title = "CIMple - K5DPS Control Tower"
        description = "CIMple - Computer Integrated Manufacturing + Line Eagleview"
        # APPLY TEXTS
        self.setWindowTitle(title)
        widgets.titleRightInfo.setText(description)

        # TOGGLE MENU
        # ///////////////////////////////////////////////////////////////
        widgets.toggleButton.clicked.connect(lambda: UIFunctions.toggleMenu(self, True))

        # SET UI DEFINITIONS
        # ///////////////////////////////////////////////////////////////
        UIFunctions.uiDefinitions(self)

        # QTableWidget PARAMETERS
        # ///////////////////////////////////////////////////////////////
        widgets.tableWidget.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        # BUTTONS CLICK
        # ///////////////////////////////////////////////////////////////

        # LEFT MENUS
        widgets.btn_home.clicked.connect(self.buttonClick)
        widgets.btn_widgets.clicked.connect(self.buttonClick)
        widgets.btn_new.clicked.connect(self.buttonClick)
        widgets.btn_share.clicked.connect(self.buttonClick)
        widgets.btn_save.clicked.connect(self.buttonClick)

        # EXTRA LEFT BOX
        def openCloseLeftBox():
            UIFunctions.toggleLeftBox(self, True)
        widgets.toggleLeftBox.clicked.connect(openCloseLeftBox)
        widgets.extraCloseColumnBtn.clicked.connect(openCloseLeftBox)

        # EXTRA RIGHT BOX
        def openCloseRightBox():
            UIFunctions.toggleRightBox(self, True)
        widgets.settingsTopBtn.clicked.connect(openCloseRightBox)

        # SHOW APP
        # ///////////////////////////////////////////////////////////////
        self.show()

        # SET CUSTOM THEME
        # ///////////////////////////////////////////////////////////////
        useCustomTheme = False
        themeFile = "themes\py_dracula_light.qss"

        # SET THEME AND HACKS
        if useCustomTheme:
            # LOAD AND APPLY STYLE
            UIFunctions.theme(self, themeFile, True)

            # SET HACKS
            AppFunctions.setThemeHack(self)

        # SET HOME PAGE AND SELECT MENU
        # ///////////////////////////////////////////////////////////////
        widgets.stackedWidget.setCurrentWidget(widgets.home)
        widgets.btn_home.setStyleSheet(UIFunctions.selectMenu(widgets.btn_home.styleSheet()))


    # BUTTONS CLICK
    # Post here your functions for clicked buttons
    # ///////////////////////////////////////////////////////////////


    def buttonClick(self):
        # GET BUTTON CLICKED
        btn = self.sender()
        btnName = btn.objectName()
        # SHOW HOME PAGE
        if btnName == "btn_home":
            # pm.loaddata(self, False)
            widgets.stackedWidget.setCurrentWidget(widgets.home)
            UIFunctions.resetStyle(self, btnName)
            btn.setStyleSheet(UIFunctions.selectMenu(btn.styleSheet()))

        # SHOW WIDGETS PAGE
        if btnName == "btn_widgets":
            widgets.stackedWidget.setCurrentWidget(widgets.widgets)
            UIFunctions.resetStyle(self, btnName)
            btn.setStyleSheet(UIFunctions.selectMenu(btn.styleSheet()))

        # SHOW NEW PAGE
        if btnName == "btn_new":
            widgets.stackedWidget.setCurrentWidget(widgets.new_page) # SET PAGE
            UIFunctions.resetStyle(self, btnName) # RESET ANOTHERS BUTTONS SELECTED
            btn.setStyleSheet(UIFunctions.selectMenu(btn.styleSheet())) # SELECT MENU

            self.ui.tableWidget_3.verticalHeader().setVisible(True)
            self.ui.tableWidget_3.horizontalHeader().setVisible(True)
            self.ui.tableWidget_3.verticalHeader().setFixedWidth(100)
            self.ui.tableWidget_3.setColumnWidth(0, 120) # Status
            self.ui.tableWidget_3.setColumnWidth(1, 60) # Code
            self.ui.tableWidget_3.setColumnWidth(2, 130) # Customer
            self.ui.tableWidget_3.setColumnWidth(3, 180) # Target Device
            self.ui.tableWidget_3.setColumnWidth(4, 180) # Lot
            self.ui.tableWidget_3.setColumnWidth(5, 60) # SM
            self.ui.tableWidget_3.setColumnWidth(6, 100) # NPI / HVM
            self.ui.tableWidget_3.setColumnWidth(7, 100) # UPH
            self.ui.tableWidget_3.setColumnWidth(8, 123) # Flipper
            self.ui.tableWidget_3.setColumnWidth(9, 123) # Picker
            self.ui.tableWidget_3.setColumnWidth(10, 120) # Wafer yield
            self.ui.tableWidget_3.setColumnWidth(11, 100) # Lot yield
            self.ui.tableWidget_3.setColumnWidth(12, 100) # Reject q'ty
            self.ui.tableWidget_3.setColumnWidth(13, 130) # Wafer ID
            self.ui.tableWidget_3.setColumnWidth(14, 100) # Current Bin Code
            self.ui.tableWidget_3.setColumnWidth(15, 100) # Tape q'ty
            self.ui.tableWidget_3.setColumnWidth(16, 120) # Current Frame Setting
            self.ui.tableWidget_3.setColumnWidth(17, 120) # Auto Suction
            self.ui.tableWidget_3.setColumnWidth(18, 120) # Bypass Vision
            self.ui.tableWidget_3.setColumnWidth(19, 120) # Bypass Door

            pmf.machine_mi30(self, 33381, 1)
            pmf.machine_mi30(self, 31401, 2)
            pmf.machine_mi40(self, 35532, 3)
            pmf.machine_mi30(self, 33557, 4)
            pmf.machine_mi30(self, 31873, 5)
            pmf.machine_mi30(self, 31870, 6)
            pmf.machine_mi30(self, 32121, 7)
            pmf.machine_mi30(self, 32122, 8)
            pmf.machine_mi30(self, 32123, 9)
            pmf.machine_mi40(self, 36936, 10)
            pmf.machine_mi30(self, 32153, 11)
            pmf.machine_mi30(self, 33383, 12)
            pmf.machine_mi30(self, 32195, 13)
            pmf.machine_mi30(self, 32196, 14)
            pmf.machine_mi30(self, 32208, 15)
            pmf.machine_mi30(self, 32212, 16)
            pmf.machine_mi30(self, 32211, 17)
            pmf.machine_mi30(self, 32226, 18)
            pmf.machine_mi30(self, 32228, 19)
            pmf.machine_mi30(self, 32247, 20)
            pmf.machine_mi30(self, 32248, 21)
            pmf.machine_mi30(self, 32346, 22)
            pmf.machine_mi30(self, 32433, 23)
            pmf.machine_mi30(self, 32434, 24)
            pmf.machine_mi30(self, 32530, 25)
            pmf.machine_mi30(self, 32531, 26)
            pmf.machine_mi30(self, 32575, 27)
            pmf.machine_mi30(self, 32607, 28)
            pmf.machine_mi30(self, 32614, 29)
            pmf.machine_mi30(self, 33558, 30)
            pmf.machine_mi30(self, 32615, 31)
            pmf.machine_mi30(self, 32640, 32)
            pmf.machine_mi30(self, 32641, 33)
            pmf.machine_mi30(self, 33384, 34)
            pmf.machine_mi30(self, 33385, 35)
            pmf.machine_mi30(self, 33386, 36)
            pmf.machine_mi40(self, 34601, 37)
            pmf.machine_mi40(self, 35171, 38)
            pmf.machine_mi40(self, 35172, 39)
            pmf.machine_mi40(self, 35272, 40)
            pmf.machine_mi40(self, 35273, 41)
            pmf.machine_mi40(self, 35274, 42)
            pmf.machine_mi40(self, 35338, 43)
            pmf.machine_mi40(self, 35339, 44)
            pmf.machine_mi40(self, 35375, 45)
            pmf.machine_mi40(self, 35376, 46)
            pmf.machine_mi40(self, 35457, 47)
            pmf.machine_mi40(self, 35458, 48)   
            pmf.total_flipper(self)
            pm.loaddata(self)

            # for x in range(1, 49):
            #     if ui.tableWidget_3.item(x,7) < 20:
            #         self.ui.tableWidget_3.item(x,7).setForeground(QBrush(Qt.yellow))
            # x = random.randint(1,3)
            # myitem = self.ui.tableWidget_3.item(0,0)
            # if x == 1 :
            #     myitem.setForeground(QBrush(Qt.red))

        # SHOW NEW PAGE
        if btnName == "btn_share":
            widgets.stackedWidget.setCurrentWidget(widgets.new_TV) # SET PAGE
            UIFunctions.resetStyle(self, btnName) # RESET ANOTHERS BUTTONS SELECTED
            btn.setStyleSheet(UIFunctions.selectMenu(btn.styleSheet())) # SELECT MENU

            self.ui.tableWidget_4.verticalHeader().setVisible(True)
            self.ui.tableWidget_4.horizontalHeader().setVisible(True)
            self.ui.tableWidget_4.verticalHeader().setFixedWidth(50)
            self.ui.tableWidget_4.setColumnWidth(0, 170) # Customer
            self.ui.tableWidget_4.setColumnWidth(1, 210) # Target Device
            self.ui.tableWidget_4.setColumnWidth(2, 80) # T&R UPH
            self.ui.tableWidget_4.setColumnWidth(3, 80) # F/P
            self.ui.tableWidget_4.setColumnWidth(4, 100) # Auto Suction
            self.ui.tableWidget_4.setColumnWidth(5, 100) # Bypass Vision
            self.ui.tableWidget_4.setColumnWidth(6, 100) # Bypass Door

            self.ui.tableWidget_5.verticalHeader().setVisible(True)
            self.ui.tableWidget_5.horizontalHeader().setVisible(True)
            self.ui.tableWidget_5.verticalHeader().setFixedWidth(50)
            self.ui.tableWidget_5.setColumnWidth(0, 170) # Customer
            self.ui.tableWidget_5.setColumnWidth(1, 210) # Target Device
            self.ui.tableWidget_5.setColumnWidth(2, 80) # T&R UPH
            self.ui.tableWidget_5.setColumnWidth(3, 80) # F/P
            self.ui.tableWidget_5.setColumnWidth(4, 100) # Auto Suction
            self.ui.tableWidget_5.setColumnWidth(5, 100) # Bypass Vision
            self.ui.tableWidget_5.setColumnWidth(6, 100) # Bypass Door

            ptf.machine_mi30_left(self, 33381, 1)
            ptf.machine_mi30_left(self, 31401, 2)
            ptf.machine_mi40_left(self, 35532, 3)
            ptf.machine_mi30_left(self, 33557, 4)
            ptf.machine_mi30_left(self, 31873, 5)
            ptf.machine_mi30_left(self, 31870, 6)
            ptf.machine_mi30_left(self, 32121, 7)
            ptf.machine_mi30_left(self, 32122, 8)
            ptf.machine_mi30_left(self, 32123, 9)
            ptf.machine_mi40_left(self, 36936, 10)
            ptf.machine_mi30_left(self, 32153, 11)
            ptf.machine_mi30_left(self, 33383, 12)
            ptf.machine_mi30_left(self, 32195, 13)
            ptf.machine_mi30_left(self, 32196, 14)
            ptf.machine_mi30_left(self, 32208, 15)
            ptf.machine_mi30_left(self, 32212, 16)
            ptf.machine_mi30_left(self, 32211, 17)
            ptf.machine_mi30_left(self, 32226, 18)
            ptf.machine_mi30_left(self, 32228, 19)
            ptf.machine_mi30_left(self, 32247, 20)
            ptf.machine_mi30_left(self, 32248, 21)
            ptf.machine_mi30_left(self, 32346, 22)
            ptf.machine_mi30_left(self, 32433, 23)
            ptf.machine_mi30_left(self, 32434, 24)
            ptf.machine_mi30_left(self, 32530, 25)
            ptf.machine_mi30_right(self, 32531, 26)
            ptf.machine_mi30_right(self, 32575, 27)
            ptf.machine_mi30_right(self, 32607, 28)
            ptf.machine_mi30_right(self, 32614, 29)
            ptf.machine_mi30_right(self, 33558, 30)
            ptf.machine_mi30_right(self, 32615, 31)
            ptf.machine_mi30_right(self, 32640, 32)
            ptf.machine_mi30_right(self, 32641, 33)
            ptf.machine_mi30_right(self, 33384, 34)
            ptf.machine_mi30_right(self, 33385, 35)
            ptf.machine_mi30_right(self, 33386, 36)
            ptf.machine_mi40_right(self, 34601, 37)
            ptf.machine_mi40_right(self, 35171, 38)
            ptf.machine_mi40_right(self, 35172, 39)
            ptf.machine_mi40_right(self, 35272, 40)
            ptf.machine_mi40_right(self, 35273, 41)
            ptf.machine_mi40_right(self, 35274, 42)
            ptf.machine_mi40_right(self, 35338, 43)
            ptf.machine_mi40_right(self, 35339, 44)
            ptf.machine_mi40_right(self, 35375, 45)
            ptf.machine_mi40_right(self, 35376, 46)
            ptf.machine_mi40_right(self, 35457, 47)
            ptf.machine_mi40_right(self, 35458, 48)
            ptf.total_flipper_tv(self)
            pt.loaddata_TV(self)
            

        if btnName == "btn_save":
            print("Save BTN clicked!")

        # PRINT BTN NAME
        print(f'Button "{btnName}" pressed!')

    # RESIZE EVENTS
    # ///////////////////////////////////////////////////////////////
    def resizeEvent(self, event):
        # Update Size Grips
        UIFunctions.resize_grips(self)

    # MOUSE CLICK EVENTS
    # ///////////////////////////////////////////////////////////////
    def mousePressEvent(self, event):
        # SET DRAG POS WINDOW
        self.dragPos = event.globalPos()

        # PRINT MOUSE EVENTS
        if event.buttons() == Qt.LeftButton:
            print('Mouse click: LEFT CLICK')
        if event.buttons() == Qt.RightButton:
            print('Mouse click: RIGHT CLICK')

    def updateTime_tv(self):
        time = QTime.currentTime().toString()
        pt.machine_mi30_left(33381, 1)
        pt.machine_mi30_left(31401, 2)
        pt.machine_mi40_left(35532, 3)
        pt.machine_mi30_left(33557, 4)
        pt.machine_mi30_left(31873, 5)
        pt.machine_mi30_left(31870, 6)
        pt.machine_mi30_left(32121, 7)
        pt.machine_mi30_left(32122, 8)
        pt.machine_mi30_left(32123, 9)
        pt.machine_mi40_left(36936, 10)
        pt.machine_mi30_left(32153, 11)
        pt.machine_mi30_left(33383, 12)
        pt.machine_mi30_left(32195, 13)
        pt.machine_mi30_left(32196, 14)
        pt.machine_mi30_left(32208, 15)
        pt.machine_mi30_left(32212, 16)
        pt.machine_mi30_left(32211, 17)
        pt.machine_mi30_left(32226, 18)
        pt.machine_mi30_left(32228, 19)
        pt.machine_mi30_left(32247, 20)
        pt.machine_mi30_left(32248, 21)
        pt.machine_mi30_left(32346, 22)
        pt.machine_mi30_left(32433, 23)
        pt.machine_mi30_left(32434, 24)
        pt.machine_mi30_left(32530, 25)
        pt.machine_mi30_right(32531, 26)
        pt.machine_mi30_right(32575, 27)
        pt.machine_mi30_right(32607, 28)
        pt.machine_mi30_right(32614, 29)
        pt.machine_mi30_right(33558, 30)
        pt.machine_mi30_right(32615, 31)
        pt.machine_mi30_right(32640, 32)
        pt.machine_mi30_right(32641, 33)
        pt.machine_mi30_right(33384, 34)
        pt.machine_mi30_right(33385, 35)
        pt.machine_mi30_right(33386, 36)
        pt.machine_mi40_right(34601, 37)
        pt.machine_mi40_right(35171, 38)
        pt.machine_mi40_right(35172, 39)
        pt.machine_mi40_right(35272, 40)
        pt.machine_mi40_right(35273, 41)
        pt.machine_mi40_right(35274, 42)
        pt.machine_mi40_right(35338, 43)
        pt.machine_mi40_right(35339, 44)
        pt.machine_mi40_right(35375, 45)
        pt.machine_mi40_right(35376, 46)
        pt.machine_mi40_right(35457, 47)
        pt.machine_mi40_right(35458, 48)  

    def updateTime_flipper_tv(self):
        time = QTime.currentTime().toString()
        pm.total_flipper_tv()

    def updateTime_pnp_status(self):
        time = QTime.currentTime().toString()
        pm.machine_mi30(33381, 1)
        pm.machine_mi30(31401, 2)
        pm.machine_mi40(35532, 3)
        pm.machine_mi30(33557, 4)
        pm.machine_mi30(31873, 5)
        pm.machine_mi30(31870, 6)
        pm.machine_mi30(32121, 7)
        pm.machine_mi30(32122, 8)
        pm.machine_mi30(32123, 9)
        pm.machine_mi40(36936, 10)
        pm.machine_mi30(32153, 11)
        pm.machine_mi30(33383, 12)
        pm.machine_mi30(32195, 13)
        pm.machine_mi30(32196, 14)
        pm.machine_mi30(32208, 15)
        pm.machine_mi30(32212, 16)
        pm.machine_mi30(32211, 17)
        pm.machine_mi30(32226, 18)
        pm.machine_mi30(32228, 19)
        pm.machine_mi30(32247, 20)
        pm.machine_mi30(32248, 21)
        pm.machine_mi30(32346, 22)
        pm.machine_mi30(32433, 23)
        pm.machine_mi30(32434, 24)
        pm.machine_mi30(32530, 25)
        pm.machine_mi30(32531, 26)
        pm.machine_mi30(32575, 27)
        pm.machine_mi30(32607, 28)
        pm.machine_mi30(32614, 29)
        pm.machine_mi30(33558, 30)
        pm.machine_mi30(32615, 31)
        pm.machine_mi30(32640, 32)
        pm.machine_mi30(32641, 33)
        pm.machine_mi30(33384, 34)
        pm.machine_mi30(33385, 35)
        pm.machine_mi30(33386, 36)
        pm.machine_mi40(34601, 37)
        pm.machine_mi40(35171, 38)
        pm.machine_mi40(35172, 39)
        pm.machine_mi40(35272, 40)
        pm.machine_mi40(35273, 41)
        pm.machine_mi40(35274, 42)
        pm.machine_mi40(35338, 43)
        pm.machine_mi40(35339, 44)
        pm.machine_mi40(35375, 45)
        pm.machine_mi40(35376, 46)
        pm.machine_mi40(35457, 47)
        pm.machine_mi40(35458, 48)       

    def updateTime_flipper(self):
        time = QTime.currentTime().toString()
        pm.total_flipper()

    def updateTime_pusher(self):
        time = QTime.currentTime().toString()
        ppusher.machine_37()
        ppusher.machine_38()
        ppusher.machine_39()
        ppusher.machine_40()
        ppusher.machine_41()
        ppusher.machine_42()
        ppusher.machine_43()
        ppusher.machine_44()
        ppusher.machine_45()
        ppusher.machine_46()
        ppusher.machine_47()
        ppusher.machine_48()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon("icon.ico"))
    window = SplashScreen()
    sys.exit(app.exec_())
