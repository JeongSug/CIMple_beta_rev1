for i in range(1, 49):
    # print(i)
    print(i)